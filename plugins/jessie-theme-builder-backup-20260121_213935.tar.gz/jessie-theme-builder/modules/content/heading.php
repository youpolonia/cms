<?php
/**
 * Heading Module
 * Heading text with multiple levels
 *
 * @package JessieThemeBuilder
 */

namespace JessieThemeBuilder;

defined('CMS_ROOT') or die('Direct access not allowed');

class JTB_Module_Heading extends JTB_Element
{
    public string $icon = 'heading';
    public string $category = 'content';

    public bool $use_typography = true;
    public bool $use_background = true;
    public bool $use_spacing = true;
    public bool $use_border = true;
    public bool $use_box_shadow = true;
    public bool $use_animation = true;
    public bool $use_transform = true;
    public bool $use_position = false;
    public bool $use_filters = false;

    public function getSlug(): string
    {
        return 'heading';
    }

    public function getName(): string
    {
        return 'Heading';
    }

    public function getFields(): array
    {
        return [
            'text' => [
                'label' => 'Heading Text',
                'type' => 'text',
                'default' => 'Your Heading Here'
            ],
            'level' => [
                'label' => 'Heading Level',
                'type' => 'select',
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6'
                ],
                'default' => 'h2'
            ],
            'link_url' => [
                'label' => 'Link URL',
                'type' => 'url',
                'description' => 'Optional link for the heading'
            ],
            'link_target' => [
                'label' => 'Open in New Tab',
                'type' => 'toggle',
                'default' => false,
                'show_if_not' => ['link_url' => '']
            ]
        ];
    }

    public function render(array $attrs, string $content = ''): string
    {
        $text = $attrs['text'] ?? 'Your Heading Here';
        $level = $attrs['level'] ?? 'h2';
        $linkUrl = $attrs['link_url'] ?? '';
        $linkTarget = !empty($attrs['link_target']) ? ' target="_blank" rel="noopener noreferrer"' : '';

        // Validate heading level
        $validLevels = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
        if (!in_array($level, $validLevels)) {
            $level = 'h2';
        }

        // Build heading content
        $headingContent = $this->esc($text);

        if (!empty($linkUrl)) {
            $headingContent = '<a href="' . $this->esc($linkUrl) . '"' . $linkTarget . ' class="jtb-heading-link">' . $headingContent . '</a>';
        }

        $innerHtml = '<' . $level . ' class="jtb-heading-text">' . $headingContent . '</' . $level . '>';

        return $this->renderWrapper($innerHtml, $attrs);
    }

    public function generateCss(array $attrs, string $selector): string
    {
        $css = '';

        // Apply typography to heading element
        $level = $attrs['level'] ?? 'h2';
        $headingSelector = $selector . ' .jtb-heading-text';

        // Reset default heading margins
        $css .= $headingSelector . ' { margin: 0; }' . "\n";

        // Link styling
        if (!empty($attrs['link_url'])) {
            $css .= $selector . ' .jtb-heading-link { text-decoration: none; color: inherit; }' . "\n";
            $css .= $selector . ' .jtb-heading-link:hover { text-decoration: underline; }' . "\n";
        }

        // Parent CSS
        $css .= parent::generateCss($attrs, $selector);

        return $css;
    }
}

// Register module
JTB_Registry::register('heading', JTB_Module_Heading::class);
