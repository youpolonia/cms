<?php
/**
 * Accordion Item Module (Child)
 * Single accordion panel
 *
 * @package JessieThemeBuilder
 */

namespace JessieThemeBuilder;

defined('CMS_ROOT') or die('Direct access not allowed');

class JTB_Module_AccordionItem extends JTB_Element
{
    public string $icon = 'accordion-item';
    public string $category = 'interactive';
    public bool $is_child = true;

    public bool $use_typography = true;
    public bool $use_background = true;
    public bool $use_spacing = true;
    public bool $use_border = false;
    public bool $use_box_shadow = false;
    public bool $use_animation = false;
    public bool $use_transform = false;
    public bool $use_position = false;
    public bool $use_filters = false;

    public function getSlug(): string
    {
        return 'accordion_item';
    }

    public function getName(): string
    {
        return 'Accordion Item';
    }

    public function getFields(): array
    {
        return [
            'title' => [
                'label' => 'Title',
                'type' => 'text',
                'default' => 'Accordion Title'
            ],
            'content' => [
                'label' => 'Content',
                'type' => 'richtext',
                'default' => '<p>Your accordion content goes here.</p>'
            ],
            'open' => [
                'label' => 'Open by Default',
                'type' => 'toggle',
                'default' => false
            ]
        ];
    }

    public function render(array $attrs, string $content = ''): string
    {
        $title = $this->esc($attrs['title'] ?? 'Accordion Title');
        $bodyContent = $attrs['content'] ?? '<p>Your accordion content goes here.</p>';
        $isOpen = !empty($attrs['open']);

        $itemClass = 'jtb-accordion-item' . ($isOpen ? ' jtb-open' : '');

        $html = '<div class="' . $itemClass . '">';
        $html .= '<div class="jtb-accordion-header" role="button" tabindex="0">';
        $html .= '<h5 class="jtb-accordion-title">' . $title . '</h5>';
        $html .= '<span class="jtb-accordion-icon">▼</span>';
        $html .= '</div>';
        $html .= '<div class="jtb-accordion-content">' . $bodyContent . '</div>';
        $html .= '</div>';

        return $html;
    }

    public function generateCss(array $attrs, string $selector): string
    {
        // Child items inherit most styling from parent
        return parent::generateCss($attrs, $selector);
    }
}

JTB_Registry::register('accordion_item', JTB_Module_AccordionItem::class);
