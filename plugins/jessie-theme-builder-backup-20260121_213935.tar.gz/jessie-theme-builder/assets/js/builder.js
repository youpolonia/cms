/**
 * JTB Builder JavaScript
 * Main builder functionality
 */

(function() {
    'use strict';

    // Global JTB object
    window.JTB = window.JTB || {};

    // ========================================
    // Configuration
    // ========================================

    JTB.config = {
        apiUrl: '/api/jtb',
        postId: null,
        csrfToken: null,
        modules: {},
        breakpoints: {
            desktop: 1200,
            tablet: 980,
            phone: 767
        }
    };

    // ========================================
    // State
    // ========================================

    JTB.state = {
        content: null,
        selectedModule: null,
        selectedType: null,
        selectedIndexes: null,
        isDirty: false,
        currentDevice: 'desktop',
        history: [],
        historyIndex: -1
    };

    // ========================================
    // Initialization
    // ========================================

    JTB.init = function(options) {
        // Merge options
        Object.assign(JTB.config, options);

        // Initialize
        JTB.loadModules()
            .then(() => JTB.loadContent())
            .then(() => {
                JTB.renderCanvas();
                JTB.bindEvents();
                JTB.saveHistory();
            })
            .catch(error => {
                console.error('JTB Init Error:', error);
                JTB.showNotification('Failed to initialize builder', 'error');
            });
    };

    // ========================================
    // API Methods
    // ========================================

    JTB.api = {
        get: function(endpoint) {
            return fetch(JTB.config.apiUrl + endpoint, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json'
                }
            }).then(response => response.json());
        },

        post: function(endpoint, data) {
            const formData = new FormData();

            for (const key in data) {
                if (data.hasOwnProperty(key)) {
                    formData.append(key, data[key]);
                }
            }

            formData.append('csrf_token', JTB.config.csrfToken);

            return fetch(JTB.config.apiUrl + endpoint, {
                method: 'POST',
                body: formData
            }).then(response => response.json());
        }
    };

    // ========================================
    // Data Loading
    // ========================================

    JTB.loadModules = function() {
        return JTB.api.get('/modules').then(response => {
            if (response.success) {
                JTB.config.modules = response.data.modules;
                JTB.config.categories = response.data.categories;
            } else {
                throw new Error(response.error || 'Failed to load modules');
            }
        });
    };

    JTB.loadContent = function() {
        return JTB.api.get('/load/' + JTB.config.postId).then(response => {
            if (response.success) {
                JTB.state.content = response.data.content;
            } else {
                throw new Error(response.error || 'Failed to load content');
            }
        });
    };

    JTB.saveContent = function() {
        const contentJson = JSON.stringify(JTB.state.content);

        return JTB.api.post('/save', {
            post_id: JTB.config.postId,
            content: contentJson
        }).then(response => {
            if (response.success) {
                JTB.state.isDirty = false;
                JTB.showNotification('Content saved successfully', 'success');
            } else {
                throw new Error(response.error || 'Failed to save content');
            }
        }).catch(error => {
            JTB.showNotification('Failed to save: ' + error.message, 'error');
        });
    };

    // ========================================
    // Content Structure Helpers
    // ========================================

    JTB.getEmptyContent = function() {
        return {
            version: '1.0',
            content: []
        };
    };

    JTB.generateId = function(prefix) {
        return prefix + '_' + Math.random().toString(36).substr(2, 9);
    };

    JTB.createSection = function() {
        return {
            type: 'section',
            id: JTB.generateId('section'),
            attrs: {
                fullwidth: false,
                inner_width: 1200
            },
            children: [JTB.createRow('1')]
        };
    };

    JTB.createRow = function(columns) {
        const row = {
            type: 'row',
            id: JTB.generateId('row'),
            attrs: {
                columns: columns || '1',
                column_gap: 30,
                equal_heights: true
            },
            children: []
        };

        // Create columns based on structure
        const colCount = (columns || '1').split(',').length;
        for (let i = 0; i < colCount; i++) {
            row.children.push(JTB.createColumn());
        }

        return row;
    };

    JTB.createColumn = function() {
        return {
            type: 'column',
            id: JTB.generateId('column'),
            attrs: {},
            children: []
        };
    };

    JTB.createModule = function(type) {
        const moduleConfig = JTB.config.modules[type];
        if (!moduleConfig) return null;

        const attrs = {};

        // Set default values from field definitions
        if (moduleConfig.fields && moduleConfig.fields.content) {
            for (const fieldName in moduleConfig.fields.content) {
                const field = moduleConfig.fields.content[fieldName];
                if (field.default !== undefined) {
                    attrs[fieldName] = field.default;
                }
            }
        }

        return {
            type: type,
            id: JTB.generateId(type),
            attrs: attrs,
            children: []
        };
    };

    // ========================================
    // Canvas Rendering
    // ========================================

    JTB.renderCanvas = function() {
        const canvas = document.querySelector('.jtb-canvas-inner');
        if (!canvas) return;

        canvas.innerHTML = '';

        const sections = JTB.state.content.content || [];

        if (sections.length === 0) {
            canvas.innerHTML = JTB.renderEmptyState();
        } else {
            sections.forEach((section, index) => {
                canvas.appendChild(JTB.renderSectionEditor(section, index));
            });
        }

        // Add section button
        canvas.appendChild(JTB.createAddSectionButton());
    };

    JTB.renderEmptyState = function() {
        return `
            <div class="jtb-empty-state">
                <div class="jtb-empty-state-icon">📄</div>
                <div class="jtb-empty-state-title">Start Building Your Page</div>
                <div class="jtb-empty-state-text">Click the button below to add your first section</div>
            </div>
        `;
    };

    JTB.renderSectionEditor = function(section, sectionIndex) {
        const div = document.createElement('div');
        div.className = 'jtb-section-editor';
        div.dataset.id = section.id;
        div.dataset.index = sectionIndex;

        // Toolbar
        const toolbar = document.createElement('div');
        toolbar.className = 'jtb-section-toolbar';
        toolbar.innerHTML = `
            <span class="jtb-module-icon">📦</span>
            <span class="jtb-module-name">Section</span>
            <div class="jtb-toolbar-actions">
                <button class="jtb-toolbar-btn" data-action="settings" title="Settings">⚙️</button>
                <button class="jtb-toolbar-btn" data-action="duplicate" title="Duplicate">📋</button>
                <button class="jtb-toolbar-btn" data-action="delete" title="Delete">🗑️</button>
            </div>
        `;
        div.appendChild(toolbar);

        // Rows
        const rows = section.children || [];
        rows.forEach((row, rowIndex) => {
            div.appendChild(JTB.renderRowEditor(row, sectionIndex, rowIndex));
        });

        // Add row button
        const addRowBtn = document.createElement('button');
        addRowBtn.className = 'jtb-add-row-btn';
        addRowBtn.innerHTML = '+ Add Row';
        addRowBtn.onclick = () => JTB.openColumnPicker({ sectionIndex });
        div.appendChild(addRowBtn);

        // Bind toolbar events
        JTB.bindToolbarEvents(toolbar, 'section', { sectionIndex });

        return div;
    };

    JTB.renderRowEditor = function(row, sectionIndex, rowIndex) {
        const div = document.createElement('div');
        div.className = 'jtb-row-editor';
        div.dataset.id = row.id;
        div.dataset.sectionIndex = sectionIndex;
        div.dataset.rowIndex = rowIndex;

        // Toolbar
        const toolbar = document.createElement('div');
        toolbar.className = 'jtb-row-toolbar';
        toolbar.innerHTML = `
            <span class="jtb-module-icon">▤</span>
            <span class="jtb-module-name">Row</span>
            <div class="jtb-toolbar-actions">
                <button class="jtb-toolbar-btn" data-action="columns" title="Change Columns">⊞</button>
                <button class="jtb-toolbar-btn" data-action="settings" title="Settings">⚙️</button>
                <button class="jtb-toolbar-btn" data-action="duplicate" title="Duplicate">📋</button>
                <button class="jtb-toolbar-btn" data-action="delete" title="Delete">🗑️</button>
            </div>
        `;
        div.appendChild(toolbar);

        // Columns container
        const columnsContainer = document.createElement('div');
        columnsContainer.className = 'jtb-columns-container';
        columnsContainer.style.display = 'flex';
        columnsContainer.style.gap = '15px';

        const columns = row.children || [];
        columns.forEach((column, columnIndex) => {
            columnsContainer.appendChild(JTB.renderColumnEditor(column, { sectionIndex, rowIndex, columnIndex }));
        });

        div.appendChild(columnsContainer);

        // Bind toolbar events
        JTB.bindToolbarEvents(toolbar, 'row', { sectionIndex, rowIndex });

        return div;
    };

    JTB.renderColumnEditor = function(column, indexes) {
        const div = document.createElement('div');
        div.className = 'jtb-column-editor';
        div.dataset.id = column.id;
        div.style.flex = '1';

        // Modules
        const modules = column.children || [];
        modules.forEach((module, moduleIndex) => {
            div.appendChild(JTB.renderModuleEditor(module, { ...indexes, moduleIndex }));
        });

        // Add module button
        const addModuleBtn = document.createElement('button');
        addModuleBtn.className = 'jtb-add-module-btn';
        addModuleBtn.innerHTML = '+ Add Module';
        addModuleBtn.onclick = () => JTB.openModulePicker(indexes);
        div.appendChild(addModuleBtn);

        // Drag and drop
        div.addEventListener('dragover', (e) => {
            e.preventDefault();
            div.classList.add('drag-over');
        });

        div.addEventListener('dragleave', () => {
            div.classList.remove('drag-over');
        });

        div.addEventListener('drop', (e) => {
            e.preventDefault();
            div.classList.remove('drag-over');
            JTB.handleModuleDrop(e, indexes);
        });

        return div;
    };

    JTB.renderModuleEditor = function(module, indexes) {
        const moduleConfig = JTB.config.modules[module.type];
        const moduleName = moduleConfig ? moduleConfig.name : module.type;
        const moduleIcon = moduleConfig ? moduleConfig.icon : '📦';

        const div = document.createElement('div');
        div.className = 'jtb-module-editor';
        div.dataset.id = module.id;
        div.dataset.type = module.type;
        div.draggable = true;

        // Toolbar
        const toolbar = document.createElement('div');
        toolbar.className = 'jtb-module-toolbar';
        toolbar.innerHTML = `
            <span class="jtb-module-icon">${JTB.getModuleIcon(module.type)}</span>
            <span class="jtb-module-name">${moduleName}</span>
            <div class="jtb-toolbar-actions">
                <button class="jtb-toolbar-btn" data-action="move" title="Move">↕️</button>
                <button class="jtb-toolbar-btn" data-action="settings" title="Settings">⚙️</button>
                <button class="jtb-toolbar-btn" data-action="duplicate" title="Duplicate">📋</button>
                <button class="jtb-toolbar-btn" data-action="delete" title="Delete">🗑️</button>
            </div>
        `;
        div.appendChild(toolbar);

        // Preview
        const preview = document.createElement('div');
        preview.className = 'jtb-module-preview';
        preview.innerHTML = JTB.getModulePreview(module);
        div.appendChild(preview);

        // Bind events
        JTB.bindToolbarEvents(toolbar, 'module', indexes);

        // Drag events
        div.addEventListener('dragstart', (e) => {
            e.dataTransfer.setData('text/plain', JSON.stringify({
                type: 'move',
                indexes: indexes
            }));
            div.style.opacity = '0.5';
        });

        div.addEventListener('dragend', () => {
            div.style.opacity = '1';
        });

        return div;
    };

    JTB.getModuleIcon = function(type) {
        const icons = {
            section: '📦',
            row: '▤',
            column: '▥',
            text: '📝',
            heading: '🔤',
            image: '🖼️',
            button: '🔘'
        };
        return icons[type] || '📦';
    };

    JTB.getModulePreview = function(module) {
        const type = module.type;
        const attrs = module.attrs || {};

        switch (type) {
            case 'text':
                return `<div class="jtb-preview-text">${attrs.content || 'Enter your text here...'}</div>`;

            case 'heading':
                const level = attrs.level || 'h2';
                const text = attrs.text || 'Your Heading Here';
                return `<${level} class="jtb-preview-heading">${JTB.escapeHtml(text)}</${level}>`;

            case 'image':
                if (attrs.src) {
                    return `<img src="${JTB.escapeHtml(attrs.src)}" alt="${JTB.escapeHtml(attrs.alt || '')}" style="max-width: 100%; height: auto;">`;
                }
                return '<div class="jtb-preview-placeholder">No image selected</div>';

            case 'button':
                const btnText = attrs.text || 'Click Here';
                const btnStyle = attrs.button_style || 'solid';
                return `<div style="text-align: ${attrs.align || 'left'}"><span class="jtb-preview-button jtb-button-${btnStyle}">${JTB.escapeHtml(btnText)}</span></div>`;

            default:
                return `<div class="jtb-preview-placeholder">${type} module</div>`;
        }
    };

    // ========================================
    // Content Manipulation
    // ========================================

    JTB.addSection = function() {
        const section = JTB.createSection();
        JTB.state.content.content.push(section);
        JTB.markDirty();
        JTB.renderCanvas();
    };

    JTB.duplicateSection = function(sectionIndex) {
        const section = JTB.state.content.content[sectionIndex];
        const duplicate = JSON.parse(JSON.stringify(section));
        JTB.regenerateIds(duplicate);
        JTB.state.content.content.splice(sectionIndex + 1, 0, duplicate);
        JTB.markDirty();
        JTB.renderCanvas();
    };

    JTB.deleteSection = function(sectionIndex) {
        if (confirm('Are you sure you want to delete this section?')) {
            JTB.state.content.content.splice(sectionIndex, 1);
            JTB.markDirty();
            JTB.renderCanvas();
            JTB.Settings.close();
        }
    };

    JTB.addRow = function(sectionIndex, columns) {
        const row = JTB.createRow(columns);
        JTB.state.content.content[sectionIndex].children.push(row);
        JTB.markDirty();
        JTB.renderCanvas();
    };

    JTB.duplicateRow = function(sectionIndex, rowIndex) {
        const row = JTB.state.content.content[sectionIndex].children[rowIndex];
        const duplicate = JSON.parse(JSON.stringify(row));
        JTB.regenerateIds(duplicate);
        JTB.state.content.content[sectionIndex].children.splice(rowIndex + 1, 0, duplicate);
        JTB.markDirty();
        JTB.renderCanvas();
    };

    JTB.deleteRow = function(sectionIndex, rowIndex) {
        if (confirm('Are you sure you want to delete this row?')) {
            JTB.state.content.content[sectionIndex].children.splice(rowIndex, 1);
            JTB.markDirty();
            JTB.renderCanvas();
            JTB.Settings.close();
        }
    };

    JTB.addModule = function(indexes, type) {
        const module = JTB.createModule(type);
        if (!module) return;

        const column = JTB.state.content.content[indexes.sectionIndex]
            .children[indexes.rowIndex]
            .children[indexes.columnIndex];

        column.children.push(module);
        JTB.markDirty();
        JTB.renderCanvas();
        JTB.closeModal();
    };

    JTB.duplicateModule = function(indexes) {
        const column = JTB.state.content.content[indexes.sectionIndex]
            .children[indexes.rowIndex]
            .children[indexes.columnIndex];

        const module = column.children[indexes.moduleIndex];
        const duplicate = JSON.parse(JSON.stringify(module));
        JTB.regenerateIds(duplicate);
        column.children.splice(indexes.moduleIndex + 1, 0, duplicate);
        JTB.markDirty();
        JTB.renderCanvas();
    };

    JTB.deleteModule = function(indexes) {
        if (confirm('Are you sure you want to delete this module?')) {
            const column = JTB.state.content.content[indexes.sectionIndex]
                .children[indexes.rowIndex]
                .children[indexes.columnIndex];

            column.children.splice(indexes.moduleIndex, 1);
            JTB.markDirty();
            JTB.renderCanvas();
            JTB.Settings.close();
        }
    };

    JTB.regenerateIds = function(element) {
        if (element.id) {
            element.id = JTB.generateId(element.type || 'element');
        }
        if (element.children && Array.isArray(element.children)) {
            element.children.forEach(child => JTB.regenerateIds(child));
        }
    };

    JTB.changeRowColumns = function(indexes, columns) {
        const row = JTB.state.content.content[indexes.sectionIndex].children[indexes.rowIndex];
        const oldColumns = row.children || [];
        const newColCount = columns.split(',').length;

        row.attrs.columns = columns;

        // Adjust columns
        while (row.children.length < newColCount) {
            row.children.push(JTB.createColumn());
        }

        // Move modules from removed columns to last column
        while (row.children.length > newColCount) {
            const removed = row.children.pop();
            if (removed.children && removed.children.length > 0) {
                const lastCol = row.children[row.children.length - 1];
                lastCol.children = lastCol.children.concat(removed.children);
            }
        }

        JTB.markDirty();
        JTB.renderCanvas();
        JTB.closeModal();
    };

    // ========================================
    // History
    // ========================================

    JTB.saveHistory = function() {
        const state = JSON.stringify(JTB.state.content);

        // Remove future states if we're not at the end
        if (JTB.state.historyIndex < JTB.state.history.length - 1) {
            JTB.state.history = JTB.state.history.slice(0, JTB.state.historyIndex + 1);
        }

        JTB.state.history.push(state);
        JTB.state.historyIndex = JTB.state.history.length - 1;

        // Limit history
        if (JTB.state.history.length > 50) {
            JTB.state.history.shift();
            JTB.state.historyIndex--;
        }
    };

    JTB.undo = function() {
        if (JTB.state.historyIndex > 0) {
            JTB.state.historyIndex--;
            JTB.state.content = JSON.parse(JTB.state.history[JTB.state.historyIndex]);
            JTB.renderCanvas();
            JTB.Settings.close();
        }
    };

    JTB.redo = function() {
        if (JTB.state.historyIndex < JTB.state.history.length - 1) {
            JTB.state.historyIndex++;
            JTB.state.content = JSON.parse(JTB.state.history[JTB.state.historyIndex]);
            JTB.renderCanvas();
            JTB.Settings.close();
        }
    };

    JTB.markDirty = function() {
        JTB.state.isDirty = true;
        JTB.saveHistory();
    };

    // ========================================
    // UI Helpers
    // ========================================

    JTB.createAddSectionButton = function() {
        const btn = document.createElement('button');
        btn.className = 'jtb-add-section-btn';
        btn.innerHTML = '+ Add Section';
        btn.onclick = () => JTB.addSection();
        return btn;
    };

    JTB.showNotification = function(message, type) {
        const container = document.querySelector('.jtb-notifications');
        if (!container) return;

        const notification = document.createElement('div');
        notification.className = 'jtb-notification ' + (type || 'info');
        notification.textContent = message;

        container.appendChild(notification);

        // Trigger animation
        setTimeout(() => notification.classList.add('show'), 10);

        // Auto remove
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    };

    // ========================================
    // Event Bindings
    // ========================================

    JTB.bindEvents = function() {
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey || e.metaKey) {
                if (e.key === 's') {
                    e.preventDefault();
                    JTB.saveContent();
                } else if (e.key === 'z') {
                    e.preventDefault();
                    if (e.shiftKey) {
                        JTB.redo();
                    } else {
                        JTB.undo();
                    }
                } else if (e.key === 'y') {
                    e.preventDefault();
                    JTB.redo();
                }
            }
        });

        // Beforeunload warning
        window.addEventListener('beforeunload', (e) => {
            if (JTB.state.isDirty) {
                e.preventDefault();
                e.returnValue = '';
            }
        });

        // Header buttons
        document.querySelectorAll('.jtb-device-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const device = btn.dataset.device;
                JTB.setPreviewDevice(device);
            });
        });

        const saveBtn = document.querySelector('[data-action="save"]');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => JTB.saveContent());
        }

        const undoBtn = document.querySelector('[data-action="undo"]');
        if (undoBtn) {
            undoBtn.addEventListener('click', () => JTB.undo());
        }

        const redoBtn = document.querySelector('[data-action="redo"]');
        if (redoBtn) {
            redoBtn.addEventListener('click', () => JTB.redo());
        }
    };

    JTB.bindToolbarEvents = function(toolbar, type, indexes) {
        toolbar.querySelectorAll('.jtb-toolbar-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const action = btn.dataset.action;

                switch (action) {
                    case 'settings':
                        JTB.openSettings(type, indexes);
                        break;
                    case 'duplicate':
                        if (type === 'section') JTB.duplicateSection(indexes.sectionIndex);
                        else if (type === 'row') JTB.duplicateRow(indexes.sectionIndex, indexes.rowIndex);
                        else if (type === 'module') JTB.duplicateModule(indexes);
                        break;
                    case 'delete':
                        if (type === 'section') JTB.deleteSection(indexes.sectionIndex);
                        else if (type === 'row') JTB.deleteRow(indexes.sectionIndex, indexes.rowIndex);
                        else if (type === 'module') JTB.deleteModule(indexes);
                        break;
                    case 'columns':
                        JTB.openColumnPicker(indexes);
                        break;
                }
            });
        });
    };

    JTB.setPreviewDevice = function(device) {
        JTB.state.currentDevice = device;

        const canvas = document.querySelector('.jtb-canvas');
        canvas.className = 'jtb-canvas jtb-preview-' + device;

        document.querySelectorAll('.jtb-device-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.device === device);
        });
    };

    // ========================================
    // Pickers (Modals)
    // ========================================

    JTB.openModulePicker = function(indexes) {
        const modules = JTB.config.modules;
        const categories = JTB.config.categories || {};

        let html = '<div class="jtb-modal-header"><span class="jtb-modal-title">Add Module</span><button class="jtb-modal-close">&times;</button></div>';
        html += '<div class="jtb-modal-body">';

        // Category tabs
        html += '<div class="jtb-category-tabs">';
        html += '<button class="jtb-category-tab active" data-category="all">All</button>';
        for (const catKey in categories) {
            html += `<button class="jtb-category-tab" data-category="${catKey}">${categories[catKey].label}</button>`;
        }
        html += '</div>';

        // Module grid
        html += '<div class="jtb-module-grid">';
        for (const slug in modules) {
            const module = modules[slug];
            if (['section', 'row', 'column'].includes(slug)) continue;

            html += `
                <div class="jtb-module-item" data-type="${slug}" data-category="${module.category}">
                    <span class="jtb-module-item-icon">${JTB.getModuleIcon(slug)}</span>
                    <span class="jtb-module-item-name">${module.name}</span>
                </div>
            `;
        }
        html += '</div>';
        html += '</div>';

        JTB.showModal(html);

        // Bind events
        document.querySelectorAll('.jtb-module-item').forEach(item => {
            item.addEventListener('click', () => {
                JTB.addModule(indexes, item.dataset.type);
            });
        });

        document.querySelectorAll('.jtb-category-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const category = tab.dataset.category;

                document.querySelectorAll('.jtb-category-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');

                document.querySelectorAll('.jtb-module-item').forEach(item => {
                    if (category === 'all' || item.dataset.category === category) {
                        item.style.display = '';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });
    };

    JTB.openColumnPicker = function(indexes) {
        const columns = [
            { value: '1', label: '1 Column', cols: [1] },
            { value: '1_2,1_2', label: '2 Equal', cols: [1, 1] },
            { value: '1_3,1_3,1_3', label: '3 Equal', cols: [1, 1, 1] },
            { value: '1_4,1_4,1_4,1_4', label: '4 Equal', cols: [1, 1, 1, 1] },
            { value: '2_3,1_3', label: '2/3 + 1/3', cols: [2, 1] },
            { value: '1_3,2_3', label: '1/3 + 2/3', cols: [1, 2] },
            { value: '1_4,3_4', label: '1/4 + 3/4', cols: [1, 3] },
            { value: '3_4,1_4', label: '3/4 + 1/4', cols: [3, 1] },
            { value: '1_4,1_2,1_4', label: '1/4 + 1/2 + 1/4', cols: [1, 2, 1] }
        ];

        let html = '<div class="jtb-modal-header"><span class="jtb-modal-title">Choose Column Structure</span><button class="jtb-modal-close">&times;</button></div>';
        html += '<div class="jtb-modal-body">';
        html += '<div class="jtb-column-picker">';

        columns.forEach(col => {
            html += `<div class="jtb-column-option" data-columns="${col.value}" title="${col.label}">`;
            html += '<div class="jtb-column-preview">';
            col.cols.forEach(size => {
                html += `<div class="jtb-column-preview-col" style="flex: ${size}"></div>`;
            });
            html += '</div></div>';
        });

        html += '</div></div>';

        JTB.showModal(html);

        // Bind events
        document.querySelectorAll('.jtb-column-option').forEach(option => {
            option.addEventListener('click', () => {
                const columnsValue = option.dataset.columns;
                if (indexes.rowIndex !== undefined) {
                    JTB.changeRowColumns(indexes, columnsValue);
                } else {
                    JTB.addRow(indexes.sectionIndex, columnsValue);
                    JTB.closeModal();
                }
            });
        });
    };

    JTB.showModal = function(content) {
        // Remove existing modal
        JTB.closeModal();

        const overlay = document.createElement('div');
        overlay.className = 'jtb-modal-overlay';
        overlay.innerHTML = `<div class="jtb-modal">${content}</div>`;

        document.body.appendChild(overlay);

        // Close on overlay click
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                JTB.closeModal();
            }
        });

        // Close button
        const closeBtn = overlay.querySelector('.jtb-modal-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => JTB.closeModal());
        }
    };

    JTB.closeModal = function() {
        const overlay = document.querySelector('.jtb-modal-overlay');
        if (overlay) {
            overlay.remove();
        }
    };

    // ========================================
    // Settings
    // ========================================

    JTB.openSettings = function(type, indexes) {
        let element, moduleConfig;

        if (type === 'section') {
            element = JTB.state.content.content[indexes.sectionIndex];
            moduleConfig = JTB.config.modules.section;
        } else if (type === 'row') {
            element = JTB.state.content.content[indexes.sectionIndex].children[indexes.rowIndex];
            moduleConfig = JTB.config.modules.row;
        } else if (type === 'module') {
            element = JTB.state.content.content[indexes.sectionIndex]
                .children[indexes.rowIndex]
                .children[indexes.columnIndex]
                .children[indexes.moduleIndex];
            moduleConfig = JTB.config.modules[element.type];
        }

        if (!element || !moduleConfig) return;

        JTB.state.selectedModule = element;
        JTB.state.selectedType = type;
        JTB.state.selectedIndexes = indexes;

        JTB.Settings.render(moduleConfig, element);
    };

    // ========================================
    // Drag & Drop
    // ========================================

    JTB.handleModuleDrop = function(e, targetIndexes) {
        const data = e.dataTransfer.getData('text/plain');
        if (!data) return;

        try {
            const dragData = JSON.parse(data);

            if (dragData.type === 'move') {
                const sourceIndexes = dragData.indexes;

                // Get module
                const sourceColumn = JTB.state.content.content[sourceIndexes.sectionIndex]
                    .children[sourceIndexes.rowIndex]
                    .children[sourceIndexes.columnIndex];

                const module = sourceColumn.children.splice(sourceIndexes.moduleIndex, 1)[0];

                // Insert into target
                const targetColumn = JTB.state.content.content[targetIndexes.sectionIndex]
                    .children[targetIndexes.rowIndex]
                    .children[targetIndexes.columnIndex];

                targetColumn.children.push(module);

                JTB.markDirty();
                JTB.renderCanvas();
            }
        } catch (err) {
            console.error('Drop error:', err);
        }
    };

    // ========================================
    // Utilities
    // ========================================

    JTB.escapeHtml = function(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    };

})();
