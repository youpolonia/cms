/**
 * JTB Settings Panel JavaScript
 * Settings panel handler
 */

(function() {
    'use strict';

    window.JTB = window.JTB || {};

    // ========================================
    // Settings Namespace
    // ========================================

    JTB.Settings = {
        currentModule: null,
        currentConfig: null,
        currentTab: 'content'
    };

    // ========================================
    // Render Methods
    // ========================================

    JTB.Settings.render = function(moduleConfig, moduleData) {
        const panel = document.querySelector('.jtb-settings-panel');
        if (!panel) return;

        JTB.Settings.currentModule = moduleData;
        JTB.Settings.currentConfig = moduleConfig;
        JTB.Settings.currentTab = 'content';

        let html = '';

        // Header
        html += JTB.Settings.getHeaderHtml(moduleConfig);

        // Tabs
        html += JTB.Settings.getTabsHtml();

        // Tab contents
        html += '<div class="jtb-settings-body">';

        // Content tab
        html += '<div class="jtb-tab-content active" data-tab="content">';
        html += JTB.Settings.getTabContentHtml('content', moduleConfig.fields.content || {});
        html += '</div>';

        // Design tab
        html += '<div class="jtb-tab-content" data-tab="design">';
        html += JTB.Settings.getTabContentHtml('design', moduleConfig.fields.design || {});
        html += '</div>';

        // Advanced tab
        html += '<div class="jtb-tab-content" data-tab="advanced">';
        html += JTB.Settings.getTabContentHtml('advanced', moduleConfig.fields.advanced || {});
        html += '</div>';

        html += '</div>';

        panel.innerHTML = html;

        JTB.Settings.bindPanelEvents(panel);
    };

    JTB.Settings.getHeaderHtml = function(config) {
        return `
            <div class="jtb-settings-header">
                <span class="jtb-settings-icon">${JTB.getModuleIcon(config.slug)}</span>
                <span class="jtb-settings-title">${config.name} Settings</span>
                <button class="jtb-settings-close">&times;</button>
            </div>
        `;
    };

    JTB.Settings.getTabsHtml = function() {
        return `
            <div class="jtb-settings-tabs">
                <button class="jtb-tab active" data-tab="content">Content</button>
                <button class="jtb-tab" data-tab="design">Design</button>
                <button class="jtb-tab" data-tab="advanced">Advanced</button>
            </div>
        `;
    };

    JTB.Settings.getTabContentHtml = function(tabName, fields) {
        let html = '';

        for (const fieldName in fields) {
            const field = fields[fieldName];

            // Check conditions
            if (!JTB.Settings.checkConditions(field)) {
                continue;
            }

            const type = field.type || 'text';

            if (type === 'group' && field.toggle) {
                html += JTB.Settings.renderGroup(fieldName, field);
            } else if (type === 'group') {
                html += '<div class="jtb-field-group">';
                if (field.label) {
                    html += `<div class="jtb-group-label">${JTB.Settings.esc(field.label)}</div>`;
                }
                html += JTB.Settings.renderGroupFields(field.fields || {});
                html += '</div>';
            } else {
                html += JTB.Settings.renderField(fieldName, field);
            }
        }

        return html;
    };

    // ========================================
    // Group and Field Rendering
    // ========================================

    JTB.Settings.renderGroup = function(name, group) {
        let html = `<div class="jtb-toggle-group" data-group="${JTB.Settings.esc(name)}">`;

        html += `
            <div class="jtb-toggle-header">
                <span class="jtb-toggle-icon"></span>
                <span class="jtb-toggle-label">${JTB.Settings.esc(group.label || name)}</span>
            </div>
        `;

        html += '<div class="jtb-toggle-content">';
        html += JTB.Settings.renderGroupFields(group.fields || {});
        html += '</div>';

        html += '</div>';

        return html;
    };

    JTB.Settings.renderGroupFields = function(fields) {
        let html = '';

        for (const fieldName in fields) {
            const field = fields[fieldName];

            if (!JTB.Settings.checkConditions(field)) {
                continue;
            }

            html += JTB.Settings.renderField(fieldName, field);
        }

        return html;
    };

    JTB.Settings.renderField = function(name, field) {
        const label = field.label || name.replace(/_/g, ' ');
        const description = field.description || '';
        const responsive = field.responsive || false;
        const hover = field.hover || false;
        const value = JTB.Settings.getValue(name, field.default);

        let conditionAttrs = '';
        if (field.show_if) {
            conditionAttrs += ` data-show-if='${JSON.stringify(field.show_if)}'`;
        }
        if (field.show_if_not) {
            conditionAttrs += ` data-show-if-not='${JSON.stringify(field.show_if_not)}'`;
        }

        let html = `<div class="jtb-field" data-field-name="${JTB.Settings.esc(name)}"${conditionAttrs}>`;

        // Header
        html += '<div class="jtb-field-header">';
        html += `<label class="jtb-field-label">${JTB.Settings.esc(label)}</label>`;

        // Toggles
        if (responsive || hover) {
            html += JTB.Settings.getFieldToggles(responsive, hover);
        }

        html += '</div>';

        // Input
        html += '<div class="jtb-field-input">';
        html += JTB.Fields.render(field.type || 'text', name, field, value);
        html += '</div>';

        // Description
        if (description) {
            html += `<div class="jtb-field-description">${JTB.Settings.esc(description)}</div>`;
        }

        html += '</div>';

        return html;
    };

    JTB.Settings.getFieldToggles = function(responsive, hover) {
        let html = '<div class="jtb-field-toggles">';

        if (responsive) {
            html += '<button type="button" class="jtb-responsive-toggle active" data-device="desktop" title="Desktop">🖥️</button>';
            html += '<button type="button" class="jtb-responsive-toggle" data-device="tablet" title="Tablet">📱</button>';
            html += '<button type="button" class="jtb-responsive-toggle" data-device="phone" title="Phone">📲</button>';
        }

        if (hover) {
            html += '<button type="button" class="jtb-hover-toggle" data-state="normal" title="Hover State">👁️</button>';
        }

        html += '</div>';

        return html;
    };

    // ========================================
    // Value Management
    // ========================================

    JTB.Settings.getValue = function(name, defaultValue) {
        if (!JTB.Settings.currentModule || !JTB.Settings.currentModule.attrs) {
            return defaultValue;
        }

        const value = JTB.Settings.currentModule.attrs[name];
        return value !== undefined ? value : defaultValue;
    };

    JTB.Settings.setValue = function(name, value) {
        if (!JTB.Settings.currentModule) return;

        if (!JTB.Settings.currentModule.attrs) {
            JTB.Settings.currentModule.attrs = {};
        }

        JTB.Settings.currentModule.attrs[name] = value;
        JTB.markDirty();
        JTB.renderCanvas();
    };

    JTB.Settings.checkConditions = function(field) {
        if (!field) return true;

        const attrs = JTB.Settings.currentModule ? JTB.Settings.currentModule.attrs || {} : {};

        // Check show_if
        if (field.show_if) {
            for (const condField in field.show_if) {
                const condValue = field.show_if[condField];
                const actualValue = attrs[condField] || '';

                if (Array.isArray(condValue)) {
                    if (!condValue.includes(actualValue)) return false;
                } else {
                    if (actualValue != condValue) return false;
                }
            }
        }

        // Check show_if_not
        if (field.show_if_not) {
            for (const condField in field.show_if_not) {
                const condValue = field.show_if_not[condField];
                const actualValue = attrs[condField] || '';

                if (Array.isArray(condValue)) {
                    if (condValue.includes(actualValue)) return false;
                } else {
                    if (actualValue == condValue) return false;
                }
            }
        }

        return true;
    };

    // ========================================
    // Event Bindings
    // ========================================

    JTB.Settings.bindPanelEvents = function(panel) {
        // Close button
        const closeBtn = panel.querySelector('.jtb-settings-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => JTB.Settings.close());
        }

        // Tab switching
        panel.querySelectorAll('.jtb-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                JTB.Settings.setActiveTab(tab.dataset.tab);
            });
        });

        // Toggle groups
        panel.querySelectorAll('.jtb-toggle-header').forEach(header => {
            header.addEventListener('click', () => {
                header.parentElement.classList.toggle('open');
            });
        });

        // Responsive toggles
        panel.querySelectorAll('.jtb-responsive-toggle').forEach(btn => {
            btn.addEventListener('click', () => {
                const fieldEl = btn.closest('.jtb-field');
                const device = btn.dataset.device;

                fieldEl.querySelectorAll('.jtb-responsive-toggle').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                JTB.Settings.switchDeviceInput(fieldEl, device);
            });
        });

        // Hover toggles
        panel.querySelectorAll('.jtb-hover-toggle').forEach(btn => {
            btn.addEventListener('click', () => {
                const isHover = btn.dataset.state === 'normal';
                btn.dataset.state = isHover ? 'hover' : 'normal';
                btn.classList.toggle('active', isHover);

                const fieldEl = btn.closest('.jtb-field');
                JTB.Settings.toggleHoverInput(fieldEl, isHover);
            });
        });

        // Bind field events
        JTB.Settings.bindFieldEvents(panel);
    };

    JTB.Settings.bindFieldEvents = function(container) {
        // Text inputs
        container.querySelectorAll('.jtb-input-text, .jtb-input-url').forEach(input => {
            input.addEventListener('input', () => {
                const name = input.name || input.dataset.field;
                JTB.Settings.setValue(name, input.value);
            });
        });

        // Textareas
        container.querySelectorAll('.jtb-input-textarea').forEach(textarea => {
            textarea.addEventListener('input', () => {
                const name = textarea.name || textarea.dataset.field;
                JTB.Settings.setValue(name, textarea.value);
            });
        });

        // Selects
        container.querySelectorAll('.jtb-input-select').forEach(select => {
            select.addEventListener('change', () => {
                const name = select.name || select.dataset.field;
                JTB.Settings.setValue(name, select.value);
                JTB.Settings.refreshConditions();
            });
        });

        // Toggles
        container.querySelectorAll('.jtb-toggle-switch input').forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                const name = checkbox.name || checkbox.dataset.field;
                JTB.Settings.setValue(name, checkbox.checked);
                JTB.Settings.refreshConditions();
            });
        });

        // Range sliders
        container.querySelectorAll('.jtb-input-range').forEach(range => {
            const wrapper = range.closest('.jtb-range-wrapper');
            const numberInput = wrapper.querySelector('.jtb-input-number');
            const name = numberInput.name || numberInput.dataset.field;

            range.addEventListener('input', () => {
                numberInput.value = range.value;
                JTB.Settings.setValue(name, parseFloat(range.value));
            });

            numberInput.addEventListener('input', () => {
                range.value = numberInput.value;
                JTB.Settings.setValue(name, parseFloat(numberInput.value));
            });
        });

        // Color pickers
        container.querySelectorAll('.jtb-color-wrapper').forEach(wrapper => {
            const textInput = wrapper.querySelector('.jtb-input-color-text');
            const colorInput = wrapper.querySelector('.jtb-input-color');
            const preview = wrapper.querySelector('.jtb-color-preview');
            const name = textInput.name || textInput.dataset.field;

            textInput.addEventListener('input', () => {
                const value = textInput.value;
                preview.style.backgroundColor = value;
                JTB.Settings.setValue(name, value);
            });

            colorInput.addEventListener('input', () => {
                textInput.value = colorInput.value;
                preview.style.backgroundColor = colorInput.value;
                JTB.Settings.setValue(name, colorInput.value);
            });
        });

        // Spacing inputs
        container.querySelectorAll('.jtb-spacing-wrapper').forEach(wrapper => {
            const name = wrapper.dataset.field;
            const inputs = wrapper.querySelectorAll('.jtb-spacing-input input');
            const linkBtn = wrapper.querySelector('.jtb-spacing-link');
            let linked = false;

            linkBtn.addEventListener('click', () => {
                linked = !linked;
                linkBtn.classList.toggle('linked', linked);
            });

            inputs.forEach(input => {
                input.addEventListener('input', () => {
                    if (linked) {
                        inputs.forEach(i => i.value = input.value);
                    }

                    const value = {};
                    inputs.forEach(i => {
                        value[i.dataset.side] = parseFloat(i.value) || 0;
                    });

                    JTB.Settings.setValue(name, value);
                });
            });
        });

        // Upload fields
        container.querySelectorAll('.jtb-upload-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const wrapper = btn.closest('.jtb-upload-wrapper');
                JTB.Settings.openMediaLibrary(wrapper);
            });
        });

        container.querySelectorAll('.jtb-upload-remove').forEach(btn => {
            btn.addEventListener('click', () => {
                const wrapper = btn.closest('.jtb-upload-wrapper');
                const input = wrapper.querySelector('input[type="hidden"]');
                const preview = wrapper.querySelector('.jtb-upload-preview');
                const name = wrapper.dataset.field;

                input.value = '';
                preview.innerHTML = '<div class="jtb-upload-placeholder">No image selected</div>';
                btn.remove();

                JTB.Settings.setValue(name, '');
            });
        });

        // Richtext
        container.querySelectorAll('.jtb-richtext-content').forEach(editor => {
            const wrapper = editor.closest('.jtb-richtext-wrapper');
            const hiddenInput = wrapper.querySelector('input[type="hidden"]');
            const name = wrapper.dataset.field;

            editor.addEventListener('input', () => {
                hiddenInput.value = editor.innerHTML;
                JTB.Settings.setValue(name, editor.innerHTML);
            });

            // Toolbar buttons
            wrapper.querySelectorAll('.jtb-richtext-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const command = btn.dataset.command;

                    if (command === 'createLink') {
                        const url = prompt('Enter URL:');
                        if (url) {
                            document.execCommand(command, false, url);
                        }
                    } else {
                        document.execCommand(command, false, null);
                    }

                    hiddenInput.value = editor.innerHTML;
                    JTB.Settings.setValue(name, editor.innerHTML);
                });
            });
        });

        // Code fields
        container.querySelectorAll('.jtb-code-wrapper').forEach(wrapper => {
            const textarea = wrapper.querySelector('.jtb-input-code');
            const name = wrapper.dataset.field;
            const fullscreenBtn = wrapper.querySelector('.jtb-code-fullscreen');

            textarea.addEventListener('input', () => {
                JTB.Settings.setValue(name, textarea.value);
            });

            if (fullscreenBtn) {
                fullscreenBtn.addEventListener('click', () => {
                    wrapper.classList.toggle('jtb-code-fullscreen-mode');
                });
            }
        });

        // Date/Datetime fields
        container.querySelectorAll('.jtb-input-date, .jtb-input-datetime').forEach(input => {
            input.addEventListener('change', () => {
                const name = input.name || input.dataset.field;
                JTB.Settings.setValue(name, input.value);
            });
        });

        // Number fields (standalone)
        container.querySelectorAll('.jtb-input-number-field').forEach(input => {
            input.addEventListener('input', () => {
                const name = input.name || input.dataset.field;
                JTB.Settings.setValue(name, parseFloat(input.value) || 0);
            });
        });

        // Gallery fields
        container.querySelectorAll('.jtb-gallery-wrapper').forEach(wrapper => {
            const name = wrapper.dataset.field;
            const hiddenInput = wrapper.querySelector('input[type="hidden"]');
            const itemsContainer = wrapper.querySelector('.jtb-gallery-items');
            const addBtn = wrapper.querySelector('.jtb-gallery-add');

            // Add images
            if (addBtn) {
                addBtn.addEventListener('click', () => {
                    JTB.Settings.openGalleryPicker(wrapper);
                });
            }

            // Remove image
            wrapper.querySelectorAll('.jtb-gallery-remove').forEach(btn => {
                btn.addEventListener('click', () => {
                    const item = btn.closest('.jtb-gallery-item');
                    item.remove();
                    JTB.Settings.updateGalleryValue(wrapper);
                });
            });
        });

        // Repeater fields
        container.querySelectorAll('.jtb-repeater-wrapper').forEach(wrapper => {
            const name = wrapper.dataset.field;
            const addBtn = wrapper.querySelector('.jtb-repeater-add');
            const itemsContainer = wrapper.querySelector('.jtb-repeater-items');

            // Add item
            if (addBtn) {
                addBtn.addEventListener('click', () => {
                    const index = itemsContainer.children.length;
                    const config = JTB.Settings.getRepeaterConfig(name);
                    const itemHtml = JTB.Fields.renderRepeaterItem(name, config.fields || {}, {}, index);
                    itemsContainer.insertAdjacentHTML('beforeend', itemHtml);

                    // Bind events for new item
                    const newItem = itemsContainer.lastElementChild;
                    JTB.Settings.bindRepeaterItemEvents(newItem, wrapper);
                });
            }

            // Bind existing items
            wrapper.querySelectorAll('.jtb-repeater-item').forEach(item => {
                JTB.Settings.bindRepeaterItemEvents(item, wrapper);
            });
        });

        // Checkbox fields
        container.querySelectorAll('.jtb-input-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                const name = checkbox.name || checkbox.dataset.field;
                JTB.Settings.setValue(name, checkbox.checked);
            });
        });

        // Radio fields
        container.querySelectorAll('.jtb-radio-wrapper input[type="radio"]').forEach(radio => {
            radio.addEventListener('change', () => {
                const name = radio.name || radio.dataset.field;
                JTB.Settings.setValue(name, radio.value);
            });
        });

        // Button group fields
        container.querySelectorAll('.jtb-button-group-wrapper').forEach(wrapper => {
            const name = wrapper.dataset.field;
            const hiddenInput = wrapper.querySelector('input[type="hidden"]');

            wrapper.querySelectorAll('.jtb-button-group-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    wrapper.querySelectorAll('.jtb-button-group-btn').forEach(b => b.classList.remove('jtb-active'));
                    btn.classList.add('jtb-active');
                    hiddenInput.value = btn.dataset.value;
                    JTB.Settings.setValue(name, btn.dataset.value);
                });
            });
        });

        // Align fields
        container.querySelectorAll('.jtb-align-wrapper').forEach(wrapper => {
            const name = wrapper.dataset.field;
            const hiddenInput = wrapper.querySelector('input[type="hidden"]');

            wrapper.querySelectorAll('.jtb-align-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    wrapper.querySelectorAll('.jtb-align-btn').forEach(b => b.classList.remove('jtb-active'));
                    btn.classList.add('jtb-active');
                    hiddenInput.value = btn.dataset.value;
                    JTB.Settings.setValue(name, btn.dataset.value);
                });
            });
        });

        // Multi-select fields
        container.querySelectorAll('.jtb-multiselect-wrapper').forEach(wrapper => {
            const name = wrapper.dataset.field;
            const hiddenInput = wrapper.querySelector('input[type="hidden"]');

            wrapper.querySelectorAll('.jtb-multiselect-checkbox').forEach(checkbox => {
                checkbox.addEventListener('change', () => {
                    const selected = [];
                    wrapper.querySelectorAll('.jtb-multiselect-checkbox:checked').forEach(cb => {
                        selected.push(cb.value);
                    });
                    hiddenInput.value = JSON.stringify(selected);
                    JTB.Settings.setValue(name, selected);
                });
            });
        });

        // Gradient fields
        container.querySelectorAll('.jtb-gradient-wrapper').forEach(wrapper => {
            const name = wrapper.dataset.field;
            JTB.Settings.bindGradientEvents(wrapper, name);
        });

        // Box shadow fields
        container.querySelectorAll('.jtb-box-shadow-wrapper').forEach(wrapper => {
            const name = wrapper.dataset.field;
            JTB.Settings.bindBoxShadowEvents(wrapper, name);
        });

        // Border fields
        container.querySelectorAll('.jtb-border-wrapper').forEach(wrapper => {
            const name = wrapper.dataset.field;
            JTB.Settings.bindBorderEvents(wrapper, name);
        });

        // Font fields
        container.querySelectorAll('.jtb-font-wrapper').forEach(wrapper => {
            const name = wrapper.dataset.field;
            JTB.Settings.bindFontEvents(wrapper, name);
        });

        // Icon fields
        container.querySelectorAll('.jtb-icon-choose').forEach(btn => {
            btn.addEventListener('click', () => {
                const wrapper = btn.closest('.jtb-icon-wrapper');
                JTB.Settings.openIconPicker(wrapper);
            });
        });
    };

    // ========================================
    // Complex Field Event Handlers
    // ========================================

    JTB.Settings.bindRepeaterItemEvents = function(item, wrapper) {
        const toggleBtn = item.querySelector('.jtb-repeater-toggle');
        const removeBtn = item.querySelector('.jtb-repeater-remove');
        const content = item.querySelector('.jtb-repeater-item-content');

        if (toggleBtn) {
            toggleBtn.addEventListener('click', () => {
                item.classList.toggle('collapsed');
            });
        }

        if (removeBtn) {
            removeBtn.addEventListener('click', () => {
                item.remove();
                JTB.Settings.updateRepeaterValue(wrapper);
            });
        }

        // Bind field events in repeater item
        JTB.Settings.bindFieldEvents(content);
    };

    JTB.Settings.updateRepeaterValue = function(wrapper) {
        const name = wrapper.dataset.field;
        const items = [];

        wrapper.querySelectorAll('.jtb-repeater-item').forEach((item, index) => {
            const itemData = {};
            item.querySelectorAll('[name]').forEach(input => {
                const fieldMatch = input.name.match(/\[(\d+)\]\[(\w+)\]/);
                if (fieldMatch) {
                    const fieldName = fieldMatch[2];
                    itemData[fieldName] = input.type === 'checkbox' ? input.checked : input.value;
                }
            });
            items.push(itemData);
        });

        JTB.Settings.setValue(name, items);
    };

    JTB.Settings.getRepeaterConfig = function(name) {
        if (!JTB.Settings.currentConfig) return { fields: {} };

        // Search in all tabs for the field config
        const tabs = ['content', 'design', 'advanced'];
        for (const tab of tabs) {
            const fields = JTB.Settings.currentConfig.fields[tab] || {};
            if (fields[name]) {
                return fields[name];
            }
        }
        return { fields: {} };
    };

    JTB.Settings.updateGalleryValue = function(wrapper) {
        const name = wrapper.dataset.field;
        const hiddenInput = wrapper.querySelector('input[type="hidden"]');
        const images = [];

        wrapper.querySelectorAll('.jtb-gallery-item img').forEach(img => {
            images.push(img.src);
        });

        hiddenInput.value = JSON.stringify(images);
        JTB.Settings.setValue(name, images);
    };

    JTB.Settings.openGalleryPicker = function(wrapper) {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.multiple = true;

        input.onchange = (e) => {
            const files = Array.from(e.target.files);
            if (!files.length) return;

            // Upload each file
            files.forEach(file => {
                const formData = new FormData();
                formData.append('file', file);
                formData.append('csrf_token', JTB.config.csrfToken);

                fetch(JTB.config.apiUrl + '/upload', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const itemsContainer = wrapper.querySelector('.jtb-gallery-items');
                        const index = itemsContainer.children.length;

                        const itemHtml = `
                            <div class="jtb-gallery-item" data-index="${index}">
                                <img src="${data.data.url}" alt="">
                                <button type="button" class="jtb-gallery-remove" title="Remove">×</button>
                            </div>
                        `;
                        itemsContainer.insertAdjacentHTML('beforeend', itemHtml);

                        // Bind remove event
                        const newItem = itemsContainer.lastElementChild;
                        newItem.querySelector('.jtb-gallery-remove').addEventListener('click', () => {
                            newItem.remove();
                            JTB.Settings.updateGalleryValue(wrapper);
                        });

                        JTB.Settings.updateGalleryValue(wrapper);
                    }
                });
            });
        };

        input.click();
    };

    JTB.Settings.bindGradientEvents = function(wrapper, name) {
        const hiddenInput = wrapper.querySelector('input[type="hidden"]');
        const preview = wrapper.querySelector('.jtb-gradient-preview');
        const typeSelect = wrapper.querySelector('.jtb-gradient-type');
        const angleInput = wrapper.querySelector('.jtb-gradient-angle');
        const angleValue = wrapper.querySelector('.jtb-gradient-angle-value');
        const stopsContainer = wrapper.querySelector('.jtb-gradient-stops');
        const addStopBtn = wrapper.querySelector('.jtb-gradient-add-stop');

        const updateGradient = () => {
            const type = typeSelect.value;
            const angle = angleInput.value;
            const stops = [];

            stopsContainer.querySelectorAll('.jtb-gradient-stop').forEach(stop => {
                const color = stop.querySelector('input[type="color"]').value;
                const position = stop.dataset.position;
                stops.push(`${color} ${position}%`);
            });

            let gradient;
            if (type === 'radial') {
                gradient = `radial-gradient(circle, ${stops.join(', ')})`;
            } else {
                gradient = `linear-gradient(${angle}deg, ${stops.join(', ')})`;
            }

            preview.style.background = gradient;
            hiddenInput.value = gradient;
            JTB.Settings.setValue(name, gradient);
        };

        typeSelect.addEventListener('change', updateGradient);

        angleInput.addEventListener('input', () => {
            angleValue.textContent = angleInput.value + '°';
            updateGradient();
        });

        stopsContainer.querySelectorAll('.jtb-gradient-stop input[type="color"]').forEach(input => {
            input.addEventListener('input', updateGradient);
        });

        if (addStopBtn) {
            addStopBtn.addEventListener('click', () => {
                const position = 50; // Default middle position
                const stopHtml = `
                    <div class="jtb-gradient-stop" data-position="${position}">
                        <input type="color" value="#888888">
                        <span>${position}%</span>
                        <button type="button" class="jtb-gradient-stop-remove">×</button>
                    </div>
                `;
                stopsContainer.insertAdjacentHTML('beforeend', stopHtml);

                const newStop = stopsContainer.lastElementChild;
                newStop.querySelector('input[type="color"]').addEventListener('input', updateGradient);
                newStop.querySelector('.jtb-gradient-stop-remove').addEventListener('click', () => {
                    newStop.remove();
                    updateGradient();
                });

                updateGradient();
            });
        }
    };

    JTB.Settings.bindBoxShadowEvents = function(wrapper, name) {
        const hiddenInput = wrapper.querySelector('input[type="hidden"]');
        const preview = wrapper.querySelector('.jtb-shadow-box');
        const controls = {
            h: wrapper.querySelector('.jtb-shadow-h'),
            v: wrapper.querySelector('.jtb-shadow-v'),
            blur: wrapper.querySelector('.jtb-shadow-blur'),
            spread: wrapper.querySelector('.jtb-shadow-spread'),
            color: wrapper.querySelector('.jtb-shadow-color'),
            inset: wrapper.querySelector('.jtb-shadow-inset')
        };

        const updateShadow = () => {
            const values = {
                horizontal: parseInt(controls.h.value),
                vertical: parseInt(controls.v.value),
                blur: parseInt(controls.blur.value),
                spread: parseInt(controls.spread.value),
                color: controls.color.value,
                inset: controls.inset.checked
            };

            const shadow = `${values.inset ? 'inset ' : ''}${values.horizontal}px ${values.vertical}px ${values.blur}px ${values.spread}px ${values.color}`;
            preview.style.boxShadow = shadow;

            // Update value displays
            wrapper.querySelectorAll('.jtb-shadow-value').forEach((span, index) => {
                const input = span.previousElementSibling;
                span.textContent = input.value + 'px';
            });

            hiddenInput.value = JSON.stringify(values);
            JTB.Settings.setValue(name, values);
        };

        Object.values(controls).forEach(control => {
            if (control) {
                control.addEventListener('input', updateShadow);
                control.addEventListener('change', updateShadow);
            }
        });
    };

    JTB.Settings.bindBorderEvents = function(wrapper, name) {
        const hiddenInput = wrapper.querySelector('input[type="hidden"]');
        const preview = wrapper.querySelector('.jtb-border-preview');
        const controls = {
            width: wrapper.querySelector('.jtb-border-width'),
            style: wrapper.querySelector('.jtb-border-style'),
            color: wrapper.querySelector('.jtb-border-color'),
            radius: wrapper.querySelector('.jtb-border-radius')
        };

        const updateBorder = () => {
            const values = {
                width: parseInt(controls.width.value),
                style: controls.style.value,
                color: controls.color.value,
                radius: parseInt(controls.radius.value)
            };

            preview.style.border = `${values.width}px ${values.style} ${values.color}`;
            preview.style.borderRadius = `${values.radius}px`;

            hiddenInput.value = JSON.stringify(values);
            JTB.Settings.setValue(name, values);
        };

        Object.values(controls).forEach(control => {
            if (control) {
                control.addEventListener('input', updateBorder);
                control.addEventListener('change', updateBorder);
            }
        });
    };

    JTB.Settings.bindFontEvents = function(wrapper, name) {
        const hiddenInput = wrapper.querySelector('input[type="hidden"]');
        const controls = {
            family: wrapper.querySelector('.jtb-font-family-select'),
            size: wrapper.querySelector('.jtb-font-size-input'),
            weight: wrapper.querySelector('.jtb-font-weight-select'),
            style: wrapper.querySelector('.jtb-font-style-select'),
            lineHeight: wrapper.querySelector('.jtb-line-height-input'),
            letterSpacing: wrapper.querySelector('.jtb-letter-spacing-input')
        };

        const updateFont = () => {
            const values = {
                family: controls.family.value,
                size: parseInt(controls.size.value),
                weight: controls.weight.value,
                style: controls.style.value,
                lineHeight: parseFloat(controls.lineHeight.value),
                letterSpacing: parseFloat(controls.letterSpacing.value)
            };

            hiddenInput.value = JSON.stringify(values);
            JTB.Settings.setValue(name, values);
        };

        Object.values(controls).forEach(control => {
            if (control) {
                control.addEventListener('input', updateFont);
                control.addEventListener('change', updateFont);
            }
        });
    };

    JTB.Settings.openIconPicker = function(wrapper) {
        const name = wrapper.dataset.field;
        const hiddenInput = wrapper.querySelector('input[type="hidden"]');
        const preview = wrapper.querySelector('.jtb-icon-preview');

        // Create icon picker modal
        const modal = document.createElement('div');
        modal.className = 'jtb-modal jtb-icon-picker-modal';
        modal.innerHTML = `
            <div class="jtb-modal-content">
                <div class="jtb-modal-header">
                    <h3>Choose Icon</h3>
                    <button type="button" class="jtb-modal-close">&times;</button>
                </div>
                <div class="jtb-modal-body">
                    <input type="text" class="jtb-icon-search" placeholder="Search icons...">
                    <div class="jtb-icon-grid">
                        ${JTB.Settings.getIconsHtml()}
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // Close modal
        modal.querySelector('.jtb-modal-close').addEventListener('click', () => {
            modal.remove();
        });

        // Search
        const searchInput = modal.querySelector('.jtb-icon-search');
        searchInput.addEventListener('input', () => {
            const query = searchInput.value.toLowerCase();
            modal.querySelectorAll('.jtb-icon-option').forEach(option => {
                const iconName = option.dataset.icon.toLowerCase();
                option.style.display = iconName.includes(query) ? '' : 'none';
            });
        });

        // Select icon
        modal.querySelectorAll('.jtb-icon-option').forEach(option => {
            option.addEventListener('click', () => {
                const icon = option.dataset.icon;
                hiddenInput.value = icon;
                preview.innerHTML = `<span class="jtb-icon ${icon}"></span>`;
                JTB.Settings.setValue(name, icon);
                modal.remove();
            });
        });
    };

    JTB.Settings.getIconsHtml = function() {
        // Common icons
        const icons = [
            'icon-home', 'icon-user', 'icon-settings', 'icon-mail', 'icon-phone',
            'icon-search', 'icon-heart', 'icon-star', 'icon-check', 'icon-close',
            'icon-arrow-left', 'icon-arrow-right', 'icon-arrow-up', 'icon-arrow-down',
            'icon-menu', 'icon-grid', 'icon-list', 'icon-calendar', 'icon-clock',
            'icon-location', 'icon-globe', 'icon-link', 'icon-image', 'icon-video',
            'icon-music', 'icon-file', 'icon-folder', 'icon-download', 'icon-upload',
            'icon-share', 'icon-facebook', 'icon-twitter', 'icon-instagram', 'icon-linkedin',
            'icon-youtube', 'icon-pinterest', 'icon-whatsapp', 'icon-telegram', 'icon-tiktok'
        ];

        return icons.map(icon => `
            <div class="jtb-icon-option" data-icon="${icon}" title="${icon}">
                <span class="jtb-icon ${icon}">⬡</span>
                <span class="jtb-icon-name">${icon.replace('icon-', '')}</span>
            </div>
        `).join('');
    };

    JTB.Settings.refreshConditions = function() {
        const panel = document.querySelector('.jtb-settings-panel');
        if (!panel) return;

        panel.querySelectorAll('.jtb-field[data-show-if], .jtb-field[data-show-if-not]').forEach(fieldEl => {
            const showIf = fieldEl.dataset.showIf ? JSON.parse(fieldEl.dataset.showIf) : null;
            const showIfNot = fieldEl.dataset.showIfNot ? JSON.parse(fieldEl.dataset.showIfNot) : null;

            let visible = true;

            if (showIf) {
                visible = JTB.Settings.checkConditions({ show_if: showIf });
            }

            if (visible && showIfNot) {
                visible = JTB.Settings.checkConditions({ show_if_not: showIfNot });
            }

            fieldEl.style.display = visible ? '' : 'none';
        });
    };

    // ========================================
    // Responsive/Hover Handling
    // ========================================

    JTB.Settings.switchDeviceInput = function(fieldEl, device) {
        const fieldName = fieldEl.dataset.fieldName;
        const suffix = device === 'desktop' ? '' : '__' + device;
        const fullName = fieldName + suffix;

        const input = fieldEl.querySelector('.jtb-field-input input, .jtb-field-input select, .jtb-field-input textarea');
        if (input) {
            const currentValue = JTB.Settings.getValue(fullName, JTB.Settings.getValue(fieldName, ''));
            input.value = currentValue;
            input.name = fullName;
            input.dataset.field = fullName;
        }
    };

    JTB.Settings.toggleHoverInput = function(fieldEl, isHover) {
        const fieldName = fieldEl.dataset.fieldName;
        const suffix = isHover ? '__hover' : '';
        const fullName = fieldName + suffix;

        const input = fieldEl.querySelector('.jtb-field-input input, .jtb-field-input select');
        if (input) {
            const currentValue = JTB.Settings.getValue(fullName, JTB.Settings.getValue(fieldName, ''));
            input.value = currentValue;
            input.name = fullName;
            input.dataset.field = fullName;
        }
    };

    // ========================================
    // Tab Management
    // ========================================

    JTB.Settings.setActiveTab = function(tabName) {
        JTB.Settings.currentTab = tabName;

        const panel = document.querySelector('.jtb-settings-panel');
        if (!panel) return;

        panel.querySelectorAll('.jtb-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === tabName);
        });

        panel.querySelectorAll('.jtb-tab-content').forEach(content => {
            content.classList.toggle('active', content.dataset.tab === tabName);
        });
    };

    JTB.Settings.close = function() {
        const panel = document.querySelector('.jtb-settings-panel');
        if (!panel) return;

        JTB.Settings.currentModule = null;
        JTB.Settings.currentConfig = null;

        panel.innerHTML = `
            <div class="jtb-settings-empty">
                <div class="jtb-empty-icon">⚙️</div>
                <p>Select a module to edit its settings</p>
            </div>
        `;
    };

    // ========================================
    // Media Library
    // ========================================

    JTB.Settings.openMediaLibrary = function(fieldWrapper) {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = fieldWrapper.querySelector('.jtb-upload-btn').dataset.accept || 'image/*';

        input.onchange = (e) => {
            const file = e.target.files[0];
            if (!file) return;

            const formData = new FormData();
            formData.append('file', file);
            formData.append('csrf_token', JTB.config.csrfToken);

            JTB.showNotification('Uploading...', 'info');

            fetch(JTB.config.apiUrl + '/upload', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const hiddenInput = fieldWrapper.querySelector('input[type="hidden"]');
                    const preview = fieldWrapper.querySelector('.jtb-upload-preview');
                    const name = fieldWrapper.dataset.field;

                    hiddenInput.value = data.data.url;
                    preview.innerHTML = `<img src="${data.data.url}" alt="Preview">`;

                    // Add remove button if not exists
                    if (!fieldWrapper.querySelector('.jtb-upload-remove')) {
                        const removeBtn = document.createElement('button');
                        removeBtn.type = 'button';
                        removeBtn.className = 'jtb-btn jtb-upload-remove';
                        removeBtn.textContent = 'Remove';
                        removeBtn.onclick = () => {
                            hiddenInput.value = '';
                            preview.innerHTML = '<div class="jtb-upload-placeholder">No image selected</div>';
                            removeBtn.remove();
                            JTB.Settings.setValue(name, '');
                        };
                        fieldWrapper.querySelector('.jtb-upload-buttons').appendChild(removeBtn);
                    }

                    JTB.Settings.setValue(name, data.data.url);
                    JTB.showNotification('Image uploaded', 'success');
                } else {
                    throw new Error(data.error || 'Upload failed');
                }
            })
            .catch(error => {
                JTB.showNotification('Upload failed: ' + error.message, 'error');
            });
        };

        input.click();
    };

    // ========================================
    // Utilities
    // ========================================

    JTB.Settings.esc = function(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    };

})();
