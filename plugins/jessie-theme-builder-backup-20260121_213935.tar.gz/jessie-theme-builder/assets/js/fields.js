/**
 * JTB Fields JavaScript
 * Field rendering for settings panel
 */

(function() {
    'use strict';

    window.JTB = window.JTB || {};

    // ========================================
    // Fields Namespace
    // ========================================

    JTB.Fields = {};

    // ========================================
    // Main Render Method
    // ========================================

    JTB.Fields.render = function(type, name, config, value) {
        const method = 'render' + type.charAt(0).toUpperCase() + type.slice(1);

        if (typeof JTB.Fields[method] === 'function') {
            return JTB.Fields[method](name, config, value);
        }

        return JTB.Fields.renderText(name, config, value);
    };

    // ========================================
    // Field Render Methods
    // ========================================

    JTB.Fields.renderText = function(name, config, value) {
        const placeholder = JTB.Fields.esc(config.placeholder || '');
        const val = JTB.Fields.esc(value || config.default || '');

        return `
            <input type="text"
                class="jtb-input-text"
                name="${JTB.Fields.esc(name)}"
                value="${val}"
                placeholder="${placeholder}"
                data-field="${JTB.Fields.esc(name)}">
        `;
    };

    JTB.Fields.renderTextarea = function(name, config, value) {
        const rows = config.rows || 4;
        const placeholder = JTB.Fields.esc(config.placeholder || '');
        const val = JTB.Fields.esc(value || config.default || '');

        return `
            <textarea
                class="jtb-input-textarea"
                name="${JTB.Fields.esc(name)}"
                rows="${rows}"
                placeholder="${placeholder}"
                data-field="${JTB.Fields.esc(name)}">${val}</textarea>
        `;
    };

    JTB.Fields.renderRichtext = function(name, config, value) {
        const content = value || config.default || '';

        return `
            <div class="jtb-richtext-wrapper" data-field="${JTB.Fields.esc(name)}">
                <div class="jtb-richtext-toolbar">
                    <button type="button" class="jtb-richtext-btn" data-command="bold" title="Bold"><strong>B</strong></button>
                    <button type="button" class="jtb-richtext-btn" data-command="italic" title="Italic"><em>I</em></button>
                    <button type="button" class="jtb-richtext-btn" data-command="underline" title="Underline"><u>U</u></button>
                    <span class="jtb-toolbar-separator"></span>
                    <button type="button" class="jtb-richtext-btn" data-command="insertUnorderedList" title="Bullet List">•</button>
                    <button type="button" class="jtb-richtext-btn" data-command="insertOrderedList" title="Numbered List">1.</button>
                    <span class="jtb-toolbar-separator"></span>
                    <button type="button" class="jtb-richtext-btn" data-command="createLink" title="Insert Link">🔗</button>
                    <button type="button" class="jtb-richtext-btn" data-command="unlink" title="Remove Link">❌</button>
                </div>
                <div class="jtb-richtext-content" contenteditable="true">${content}</div>
                <input type="hidden" name="${JTB.Fields.esc(name)}" value="${JTB.Fields.esc(content)}">
            </div>
        `;
    };

    JTB.Fields.renderSelect = function(name, config, value) {
        const options = config.options || {};
        const currentValue = value !== undefined ? value : (config.default || '');

        let html = `<select class="jtb-input-select" name="${JTB.Fields.esc(name)}" data-field="${JTB.Fields.esc(name)}">`;

        for (const optValue in options) {
            const optLabel = options[optValue];
            const selected = optValue == currentValue ? ' selected' : '';
            html += `<option value="${JTB.Fields.esc(optValue)}"${selected}>${JTB.Fields.esc(optLabel)}</option>`;
        }

        html += '</select>';

        return html;
    };

    JTB.Fields.renderToggle = function(name, config, value) {
        const checked = value !== undefined ? value : (config.default || false);
        const checkedAttr = checked ? ' checked' : '';

        return `
            <label class="jtb-toggle-switch">
                <input type="checkbox"
                    name="${JTB.Fields.esc(name)}"
                    value="1"${checkedAttr}
                    data-field="${JTB.Fields.esc(name)}">
                <span class="jtb-toggle-slider"></span>
            </label>
        `;
    };

    JTB.Fields.renderRange = function(name, config, value) {
        const min = config.min !== undefined ? config.min : 0;
        const max = config.max !== undefined ? config.max : 100;
        const step = config.step || 1;
        const unit = config.unit || '';
        const currentValue = value !== undefined ? value : (config.default !== undefined ? config.default : min);

        return `
            <div class="jtb-range-wrapper">
                <input type="range"
                    class="jtb-input-range"
                    name="${JTB.Fields.esc(name)}_range"
                    min="${min}"
                    max="${max}"
                    step="${step}"
                    value="${currentValue}"
                    data-field="${JTB.Fields.esc(name)}">
                <input type="number"
                    class="jtb-input-number"
                    name="${JTB.Fields.esc(name)}"
                    min="${min}"
                    max="${max}"
                    step="${step}"
                    value="${currentValue}"
                    data-field="${JTB.Fields.esc(name)}">
                ${unit ? `<span class="jtb-range-unit">${JTB.Fields.esc(unit)}</span>` : ''}
            </div>
        `;
    };

    JTB.Fields.renderColor = function(name, config, value) {
        const currentValue = value || config.default || '#000000';

        return `
            <div class="jtb-color-wrapper">
                <input type="text"
                    class="jtb-input-color-text"
                    name="${JTB.Fields.esc(name)}"
                    value="${JTB.Fields.esc(currentValue)}"
                    data-field="${JTB.Fields.esc(name)}">
                <input type="color"
                    class="jtb-input-color"
                    value="${JTB.Fields.esc(currentValue.startsWith('#') ? currentValue : '#000000')}">
                <div class="jtb-color-preview" style="background-color: ${JTB.Fields.esc(currentValue)};"></div>
            </div>
        `;
    };

    JTB.Fields.renderUpload = function(name, config, value) {
        const accept = config.accept || 'image/*';
        const currentValue = value || '';

        let previewHtml;
        let removeBtn = '';

        if (currentValue) {
            previewHtml = `<img src="${JTB.Fields.esc(currentValue)}" alt="Preview">`;
            removeBtn = '<button type="button" class="jtb-btn jtb-upload-remove">Remove</button>';
        } else {
            previewHtml = '<div class="jtb-upload-placeholder">No image selected</div>';
        }

        return `
            <div class="jtb-upload-wrapper" data-field="${JTB.Fields.esc(name)}">
                <input type="hidden" name="${JTB.Fields.esc(name)}" value="${JTB.Fields.esc(currentValue)}">
                <div class="jtb-upload-preview">${previewHtml}</div>
                <div class="jtb-upload-buttons">
                    <button type="button" class="jtb-btn jtb-upload-btn" data-accept="${JTB.Fields.esc(accept)}">Choose Image</button>
                    ${removeBtn}
                </div>
            </div>
        `;
    };

    JTB.Fields.renderSpacing = function(name, config, value) {
        const sides = config.sides || ['top', 'right', 'bottom', 'left'];
        const unit = config.unit || 'px';
        const values = value || {};

        let inputsHtml = '';

        sides.forEach(side => {
            const sideValue = values[side] !== undefined ? values[side] : 0;
            const label = side.replace('_', ' ');

            inputsHtml += `
                <div class="jtb-spacing-input">
                    <label>${label.charAt(0).toUpperCase() + label.slice(1)}</label>
                    <input type="number"
                        name="${JTB.Fields.esc(name)}[${JTB.Fields.esc(side)}]"
                        value="${sideValue}"
                        data-side="${JTB.Fields.esc(side)}">
                </div>
            `;
        });

        return `
            <div class="jtb-spacing-wrapper" data-field="${JTB.Fields.esc(name)}">
                <div class="jtb-spacing-inputs">${inputsHtml}</div>
                <button type="button" class="jtb-spacing-link" title="Link values">
                    <span class="jtb-link-icon">🔗</span>
                </button>
                <span class="jtb-spacing-unit">${JTB.Fields.esc(unit)}</span>
            </div>
        `;
    };

    JTB.Fields.renderUrl = function(name, config, value) {
        const currentValue = value || config.default || '';

        return `
            <div class="jtb-url-wrapper">
                <input type="url"
                    class="jtb-input-url"
                    name="${JTB.Fields.esc(name)}"
                    value="${JTB.Fields.esc(currentValue)}"
                    placeholder="https://"
                    data-field="${JTB.Fields.esc(name)}">
                <button type="button" class="jtb-url-options" title="Link Options">⚙️</button>
            </div>
        `;
    };

    JTB.Fields.renderIcon = function(name, config, value) {
        const currentValue = value || '';

        let previewHtml;

        if (currentValue) {
            previewHtml = `<span class="jtb-icon ${JTB.Fields.esc(currentValue)}"></span>`;
        } else {
            previewHtml = '<span class="jtb-icon-placeholder">No icon</span>';
        }

        return `
            <div class="jtb-icon-wrapper" data-field="${JTB.Fields.esc(name)}">
                <input type="hidden" name="${JTB.Fields.esc(name)}" value="${JTB.Fields.esc(currentValue)}">
                <div class="jtb-icon-preview">${previewHtml}</div>
                <button type="button" class="jtb-btn jtb-icon-choose">Choose Icon</button>
            </div>
        `;
    };

    JTB.Fields.renderCode = function(name, config, value) {
        const language = config.language || 'html';
        const currentValue = value || config.default || '';
        const rows = config.rows || 10;

        return `
            <div class="jtb-code-wrapper" data-field="${JTB.Fields.esc(name)}" data-language="${JTB.Fields.esc(language)}">
                <div class="jtb-code-header">
                    <span class="jtb-code-language">${JTB.Fields.esc(language.toUpperCase())}</span>
                    <button type="button" class="jtb-code-fullscreen" title="Fullscreen">⛶</button>
                </div>
                <textarea
                    class="jtb-input-code"
                    name="${JTB.Fields.esc(name)}"
                    rows="${rows}"
                    spellcheck="false">${JTB.Fields.esc(currentValue)}</textarea>
            </div>
        `;
    };

    JTB.Fields.renderDate = function(name, config, value) {
        const currentValue = value || config.default || '';

        return `
            <div class="jtb-date-wrapper">
                <input type="date"
                    class="jtb-input-date"
                    name="${JTB.Fields.esc(name)}"
                    value="${JTB.Fields.esc(currentValue)}"
                    data-field="${JTB.Fields.esc(name)}">
            </div>
        `;
    };

    JTB.Fields.renderDatetime = function(name, config, value) {
        const currentValue = value || config.default || '';

        return `
            <div class="jtb-datetime-wrapper">
                <input type="datetime-local"
                    class="jtb-input-datetime"
                    name="${JTB.Fields.esc(name)}"
                    value="${JTB.Fields.esc(currentValue)}"
                    data-field="${JTB.Fields.esc(name)}">
            </div>
        `;
    };

    JTB.Fields.renderNumber = function(name, config, value) {
        const min = config.min !== undefined ? config.min : '';
        const max = config.max !== undefined ? config.max : '';
        const step = config.step || 1;
        const currentValue = value !== undefined ? value : (config.default !== undefined ? config.default : '');

        return `
            <input type="number"
                class="jtb-input-number-field"
                name="${JTB.Fields.esc(name)}"
                value="${currentValue}"
                ${min !== '' ? `min="${min}"` : ''}
                ${max !== '' ? `max="${max}"` : ''}
                step="${step}"
                data-field="${JTB.Fields.esc(name)}">
        `;
    };

    JTB.Fields.renderGallery = function(name, config, value) {
        const images = value || [];

        let imagesHtml = '';
        if (Array.isArray(images) && images.length > 0) {
            images.forEach((img, index) => {
                imagesHtml += `
                    <div class="jtb-gallery-item" data-index="${index}">
                        <img src="${JTB.Fields.esc(img)}" alt="">
                        <button type="button" class="jtb-gallery-remove" title="Remove">×</button>
                    </div>
                `;
            });
        }

        return `
            <div class="jtb-gallery-wrapper" data-field="${JTB.Fields.esc(name)}">
                <input type="hidden" name="${JTB.Fields.esc(name)}" value="${JTB.Fields.esc(JSON.stringify(images))}">
                <div class="jtb-gallery-items">${imagesHtml}</div>
                <div class="jtb-gallery-actions">
                    <button type="button" class="jtb-btn jtb-gallery-add">Add Images</button>
                </div>
            </div>
        `;
    };

    JTB.Fields.renderRepeater = function(name, config, value) {
        const fields = config.fields || {};
        const items = value || [];
        const addButtonText = config.add_button || 'Add Item';

        let itemsHtml = '';
        if (Array.isArray(items)) {
            items.forEach((item, index) => {
                itemsHtml += JTB.Fields.renderRepeaterItem(name, fields, item, index);
            });
        }

        return `
            <div class="jtb-repeater-wrapper" data-field="${JTB.Fields.esc(name)}">
                <div class="jtb-repeater-items">${itemsHtml}</div>
                <button type="button" class="jtb-btn jtb-repeater-add">${JTB.Fields.esc(addButtonText)}</button>
            </div>
        `;
    };

    JTB.Fields.renderRepeaterItem = function(parentName, fields, values, index) {
        let fieldsHtml = '';

        for (const fieldName in fields) {
            const fieldConfig = fields[fieldName];
            const fieldValue = values ? values[fieldName] : undefined;
            const fullName = `${parentName}[${index}][${fieldName}]`;

            fieldsHtml += `
                <div class="jtb-repeater-field">
                    <label>${JTB.Fields.esc(fieldConfig.label || fieldName)}</label>
                    ${JTB.Fields.render(fieldConfig.type || 'text', fullName, fieldConfig, fieldValue)}
                </div>
            `;
        }

        return `
            <div class="jtb-repeater-item" data-index="${index}">
                <div class="jtb-repeater-item-header">
                    <span class="jtb-repeater-drag-handle">☰</span>
                    <span class="jtb-repeater-item-title">Item ${index + 1}</span>
                    <button type="button" class="jtb-repeater-toggle">▼</button>
                    <button type="button" class="jtb-repeater-remove">×</button>
                </div>
                <div class="jtb-repeater-item-content">${fieldsHtml}</div>
            </div>
        `;
    };

    JTB.Fields.renderCheckbox = function(name, config, value) {
        const checked = value !== undefined ? value : (config.default || false);
        const checkedAttr = checked ? ' checked' : '';
        const label = config.checkbox_label || '';

        return `
            <label class="jtb-checkbox-wrapper">
                <input type="checkbox"
                    class="jtb-input-checkbox"
                    name="${JTB.Fields.esc(name)}"
                    value="1"${checkedAttr}
                    data-field="${JTB.Fields.esc(name)}">
                <span class="jtb-checkbox-label">${JTB.Fields.esc(label)}</span>
            </label>
        `;
    };

    JTB.Fields.renderRadio = function(name, config, value) {
        const options = config.options || {};
        const currentValue = value !== undefined ? value : (config.default || '');

        let html = '<div class="jtb-radio-wrapper">';

        for (const optValue in options) {
            const optLabel = options[optValue];
            const checked = optValue == currentValue ? ' checked' : '';
            const id = `${name}_${optValue}`.replace(/[^a-zA-Z0-9]/g, '_');

            html += `
                <label class="jtb-radio-item" for="${id}">
                    <input type="radio"
                        id="${id}"
                        name="${JTB.Fields.esc(name)}"
                        value="${JTB.Fields.esc(optValue)}"${checked}
                        data-field="${JTB.Fields.esc(name)}">
                    <span class="jtb-radio-label">${JTB.Fields.esc(optLabel)}</span>
                </label>
            `;
        }

        html += '</div>';

        return html;
    };

    JTB.Fields.renderButtonGroup = function(name, config, value) {
        const options = config.options || {};
        const currentValue = value !== undefined ? value : (config.default || '');

        let html = '<div class="jtb-button-group-wrapper" data-field="' + JTB.Fields.esc(name) + '">';
        html += '<input type="hidden" name="' + JTB.Fields.esc(name) + '" value="' + JTB.Fields.esc(currentValue) + '">';

        for (const optValue in options) {
            const optLabel = options[optValue];
            const active = optValue == currentValue ? ' jtb-active' : '';

            html += `
                <button type="button"
                    class="jtb-button-group-btn${active}"
                    data-value="${JTB.Fields.esc(optValue)}">
                    ${JTB.Fields.esc(optLabel)}
                </button>
            `;
        }

        html += '</div>';

        return html;
    };

    JTB.Fields.renderGradient = function(name, config, value) {
        const currentValue = value || config.default || 'linear-gradient(180deg, #ffffff 0%, #000000 100%)';

        return `
            <div class="jtb-gradient-wrapper" data-field="${JTB.Fields.esc(name)}">
                <input type="hidden" name="${JTB.Fields.esc(name)}" value="${JTB.Fields.esc(currentValue)}">
                <div class="jtb-gradient-preview" style="background: ${JTB.Fields.esc(currentValue)};"></div>
                <div class="jtb-gradient-controls">
                    <select class="jtb-gradient-type">
                        <option value="linear">Linear</option>
                        <option value="radial">Radial</option>
                    </select>
                    <input type="range" class="jtb-gradient-angle" min="0" max="360" value="180">
                    <span class="jtb-gradient-angle-value">180°</span>
                </div>
                <div class="jtb-gradient-stops">
                    <div class="jtb-gradient-stop" data-position="0">
                        <input type="color" value="#ffffff">
                        <span>0%</span>
                    </div>
                    <div class="jtb-gradient-stop" data-position="100">
                        <input type="color" value="#000000">
                        <span>100%</span>
                    </div>
                </div>
                <button type="button" class="jtb-btn jtb-gradient-add-stop">Add Stop</button>
            </div>
        `;
    };

    JTB.Fields.renderBoxShadow = function(name, config, value) {
        const defaults = {
            horizontal: 0,
            vertical: 4,
            blur: 10,
            spread: 0,
            color: 'rgba(0,0,0,0.1)',
            inset: false
        };

        const vals = value ? { ...defaults, ...value } : defaults;

        return `
            <div class="jtb-box-shadow-wrapper" data-field="${JTB.Fields.esc(name)}">
                <input type="hidden" name="${JTB.Fields.esc(name)}" value="${JTB.Fields.esc(JSON.stringify(vals))}">
                <div class="jtb-box-shadow-preview">
                    <div class="jtb-shadow-box" style="box-shadow: ${vals.inset ? 'inset ' : ''}${vals.horizontal}px ${vals.vertical}px ${vals.blur}px ${vals.spread}px ${vals.color};"></div>
                </div>
                <div class="jtb-box-shadow-controls">
                    <div class="jtb-shadow-control">
                        <label>Horizontal</label>
                        <input type="range" class="jtb-shadow-h" min="-50" max="50" value="${vals.horizontal}">
                        <span class="jtb-shadow-value">${vals.horizontal}px</span>
                    </div>
                    <div class="jtb-shadow-control">
                        <label>Vertical</label>
                        <input type="range" class="jtb-shadow-v" min="-50" max="50" value="${vals.vertical}">
                        <span class="jtb-shadow-value">${vals.vertical}px</span>
                    </div>
                    <div class="jtb-shadow-control">
                        <label>Blur</label>
                        <input type="range" class="jtb-shadow-blur" min="0" max="100" value="${vals.blur}">
                        <span class="jtb-shadow-value">${vals.blur}px</span>
                    </div>
                    <div class="jtb-shadow-control">
                        <label>Spread</label>
                        <input type="range" class="jtb-shadow-spread" min="-50" max="50" value="${vals.spread}">
                        <span class="jtb-shadow-value">${vals.spread}px</span>
                    </div>
                    <div class="jtb-shadow-control">
                        <label>Color</label>
                        <input type="text" class="jtb-shadow-color" value="${JTB.Fields.esc(vals.color)}">
                    </div>
                    <div class="jtb-shadow-control">
                        <label>
                            <input type="checkbox" class="jtb-shadow-inset"${vals.inset ? ' checked' : ''}>
                            Inset
                        </label>
                    </div>
                </div>
            </div>
        `;
    };

    JTB.Fields.renderBorder = function(name, config, value) {
        const defaults = {
            width: 1,
            style: 'solid',
            color: '#000000',
            radius: 0
        };

        const vals = value ? { ...defaults, ...value } : defaults;

        return `
            <div class="jtb-border-wrapper" data-field="${JTB.Fields.esc(name)}">
                <input type="hidden" name="${JTB.Fields.esc(name)}" value="${JTB.Fields.esc(JSON.stringify(vals))}">
                <div class="jtb-border-controls">
                    <div class="jtb-border-control">
                        <label>Width</label>
                        <input type="number" class="jtb-border-width" min="0" max="20" value="${vals.width}">
                        <span>px</span>
                    </div>
                    <div class="jtb-border-control">
                        <label>Style</label>
                        <select class="jtb-border-style">
                            <option value="solid"${vals.style === 'solid' ? ' selected' : ''}>Solid</option>
                            <option value="dashed"${vals.style === 'dashed' ? ' selected' : ''}>Dashed</option>
                            <option value="dotted"${vals.style === 'dotted' ? ' selected' : ''}>Dotted</option>
                            <option value="double"${vals.style === 'double' ? ' selected' : ''}>Double</option>
                            <option value="none"${vals.style === 'none' ? ' selected' : ''}>None</option>
                        </select>
                    </div>
                    <div class="jtb-border-control">
                        <label>Color</label>
                        <input type="color" class="jtb-border-color" value="${JTB.Fields.esc(vals.color)}">
                    </div>
                    <div class="jtb-border-control">
                        <label>Radius</label>
                        <input type="number" class="jtb-border-radius" min="0" max="100" value="${vals.radius}">
                        <span>px</span>
                    </div>
                </div>
                <div class="jtb-border-preview" style="border: ${vals.width}px ${vals.style} ${vals.color}; border-radius: ${vals.radius}px;"></div>
            </div>
        `;
    };

    JTB.Fields.renderFont = function(name, config, value) {
        const defaults = {
            family: 'inherit',
            size: 16,
            weight: '400',
            style: 'normal',
            lineHeight: 1.5,
            letterSpacing: 0
        };

        const vals = value ? { ...defaults, ...value } : defaults;

        const fonts = [
            'inherit', 'Arial', 'Georgia', 'Times New Roman', 'Verdana',
            'Trebuchet MS', 'Courier New', 'Helvetica', 'Tahoma', 'Palatino'
        ];

        let fontOptions = '';
        fonts.forEach(font => {
            const selected = vals.family === font ? ' selected' : '';
            fontOptions += `<option value="${JTB.Fields.esc(font)}"${selected}>${JTB.Fields.esc(font)}</option>`;
        });

        return `
            <div class="jtb-font-wrapper" data-field="${JTB.Fields.esc(name)}">
                <input type="hidden" name="${JTB.Fields.esc(name)}" value="${JTB.Fields.esc(JSON.stringify(vals))}">
                <div class="jtb-font-controls">
                    <div class="jtb-font-control jtb-font-family">
                        <label>Family</label>
                        <select class="jtb-font-family-select">${fontOptions}</select>
                    </div>
                    <div class="jtb-font-control jtb-font-size">
                        <label>Size</label>
                        <input type="number" class="jtb-font-size-input" min="8" max="200" value="${vals.size}">
                        <span>px</span>
                    </div>
                    <div class="jtb-font-control jtb-font-weight">
                        <label>Weight</label>
                        <select class="jtb-font-weight-select">
                            <option value="100"${vals.weight === '100' ? ' selected' : ''}>100 - Thin</option>
                            <option value="200"${vals.weight === '200' ? ' selected' : ''}>200 - Extra Light</option>
                            <option value="300"${vals.weight === '300' ? ' selected' : ''}>300 - Light</option>
                            <option value="400"${vals.weight === '400' ? ' selected' : ''}>400 - Normal</option>
                            <option value="500"${vals.weight === '500' ? ' selected' : ''}>500 - Medium</option>
                            <option value="600"${vals.weight === '600' ? ' selected' : ''}>600 - Semi Bold</option>
                            <option value="700"${vals.weight === '700' ? ' selected' : ''}>700 - Bold</option>
                            <option value="800"${vals.weight === '800' ? ' selected' : ''}>800 - Extra Bold</option>
                            <option value="900"${vals.weight === '900' ? ' selected' : ''}>900 - Black</option>
                        </select>
                    </div>
                    <div class="jtb-font-control jtb-font-style">
                        <label>Style</label>
                        <select class="jtb-font-style-select">
                            <option value="normal"${vals.style === 'normal' ? ' selected' : ''}>Normal</option>
                            <option value="italic"${vals.style === 'italic' ? ' selected' : ''}>Italic</option>
                        </select>
                    </div>
                    <div class="jtb-font-control jtb-line-height">
                        <label>Line Height</label>
                        <input type="number" class="jtb-line-height-input" min="0.5" max="5" step="0.1" value="${vals.lineHeight}">
                    </div>
                    <div class="jtb-font-control jtb-letter-spacing">
                        <label>Letter Spacing</label>
                        <input type="number" class="jtb-letter-spacing-input" min="-5" max="20" step="0.1" value="${vals.letterSpacing}">
                        <span>px</span>
                    </div>
                </div>
            </div>
        `;
    };

    JTB.Fields.renderAlign = function(name, config, value) {
        const currentValue = value || config.default || 'left';
        const options = config.options || {
            'left': '⬅',
            'center': '⬌',
            'right': '➡'
        };

        let html = `<div class="jtb-align-wrapper" data-field="${JTB.Fields.esc(name)}">`;
        html += `<input type="hidden" name="${JTB.Fields.esc(name)}" value="${JTB.Fields.esc(currentValue)}">`;

        for (const optValue in options) {
            const optLabel = options[optValue];
            const active = optValue == currentValue ? ' jtb-active' : '';

            html += `
                <button type="button"
                    class="jtb-align-btn${active}"
                    data-value="${JTB.Fields.esc(optValue)}"
                    title="${JTB.Fields.esc(optValue)}">
                    ${optLabel}
                </button>
            `;
        }

        html += '</div>';

        return html;
    };

    JTB.Fields.renderMultiSelect = function(name, config, value) {
        const options = config.options || {};
        const selectedValues = value || config.default || [];

        let html = `<div class="jtb-multiselect-wrapper" data-field="${JTB.Fields.esc(name)}">`;
        html += `<input type="hidden" name="${JTB.Fields.esc(name)}" value="${JTB.Fields.esc(JSON.stringify(selectedValues))}">`;

        for (const optValue in options) {
            const optLabel = options[optValue];
            const checked = selectedValues.includes(optValue) ? ' checked' : '';
            const id = `${name}_${optValue}`.replace(/[^a-zA-Z0-9]/g, '_');

            html += `
                <label class="jtb-multiselect-item" for="${id}">
                    <input type="checkbox"
                        id="${id}"
                        value="${JTB.Fields.esc(optValue)}"${checked}
                        class="jtb-multiselect-checkbox">
                    <span class="jtb-multiselect-label">${JTB.Fields.esc(optLabel)}</span>
                </label>
            `;
        }

        html += '</div>';

        return html;
    };

    // ========================================
    // Utilities
    // ========================================

    JTB.Fields.esc = function(str) {
        if (str === null || str === undefined) return '';
        if (typeof str !== 'string') str = String(str);

        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    };

})();
