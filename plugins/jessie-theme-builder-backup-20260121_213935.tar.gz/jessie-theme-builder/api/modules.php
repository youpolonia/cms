<?php
/**
 * Modules API Endpoint
 * GET /api/jtb/modules
 *
 * @package JessieThemeBuilder
 */

namespace JessieThemeBuilder;

defined('CMS_ROOT') or die('Direct access not allowed');

header('Content-Type: application/json');

// Verify request method
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Auth check
if (!\Core\Session::isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

// Build modules list
$modules = [];

foreach (JTB_Registry::getInstances() as $slug => $module) {
    $modules[$slug] = [
        'slug' => $module->getSlug(),
        'name' => $module->getName(),
        'icon' => $module->icon,
        'category' => $module->category,
        'is_child' => $module->is_child,
        'child_slug' => $module->child_slug,
        'fields' => [
            'content' => $module->getContentFields(),
            'design' => $module->getDesignFields(),
            'advanced' => $module->getAdvancedFields()
        ]
    ];
}

// Return response
echo json_encode([
    'success' => true,
    'data' => [
        'modules' => $modules,
        'categories' => JTB_Registry::getCategories(),
        'count' => JTB_Registry::count()
    ]
]);
