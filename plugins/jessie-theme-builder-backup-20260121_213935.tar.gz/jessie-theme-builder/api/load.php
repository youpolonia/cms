<?php
/**
 * Load API Endpoint
 * GET /api/jtb/load/{post_id}
 *
 * @package JessieThemeBuilder
 */

namespace JessieThemeBuilder;

defined('CMS_ROOT') or die('Direct access not allowed');

header('Content-Type: application/json');

// Verify request method
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Auth check
if (!\Core\Session::isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

// Get post_id from query string or URL
$postId = isset($_GET['post_id']) ? (int) $_GET['post_id'] : 0;

if ($postId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid post ID']);
    exit;
}

// Check if post exists and get title
$db = \core\Database::connection();
$stmt = $db->prepare("SELECT id, title, slug FROM pages WHERE id = ?");
$stmt->execute([$postId]);
$post = $stmt->fetch(\PDO::FETCH_ASSOC);

if (!$post) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Post not found']);
    exit;
}

// Get JTB content
$content = JTB_Builder::getContent($postId);
$hasContent = ($content !== null);

if ($content === null) {
    $content = JTB_Builder::getEmptyContent();
}

// Get CSS cache
$stmt = $db->prepare("SELECT css_cache FROM jtb_pages WHERE post_id = ?");
$stmt->execute([$postId]);
$jtbPage = $stmt->fetch(\PDO::FETCH_ASSOC);

$cssCache = $jtbPage ? ($jtbPage['css_cache'] ?? '') : '';

// Return response
echo json_encode([
    'success' => true,
    'data' => [
        'post_id' => $postId,
        'post_title' => $post['title'],
        'post_slug' => $post['slug'] ?? '',
        'content' => $content,
        'css_cache' => $cssCache,
        'has_content' => $hasContent
    ]
]);
