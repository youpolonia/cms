<?php
/**
 * JTB API Router
 * Routes API requests to appropriate endpoint files
 *
 * Include this file in your CMS router to handle /api/jtb/* requests
 *
 * @package JessieThemeBuilder
 *
 * Usage in CMS index.php or router:
 *
 * if (preg_match('#^/api/jtb/(\w+)(?:/(\d+))?#', $requestUri, $matches)) {
 *     require_once CMS_ROOT . '/plugins/jessie-theme-builder/api/router.php';
 *     exit;
 * }
 */

namespace JessieThemeBuilder;

defined('CMS_ROOT') or die('Direct access not allowed');

// Get action and ID from URL
$requestUri = $_SERVER['REQUEST_URI'] ?? '';
$matches = [];

if (!preg_match('#^/api/jtb/(\w+)(?:/(\d+))?#', $requestUri, $matches)) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Invalid API endpoint']);
    exit;
}

$action = $matches[1] ?? '';
$id = $matches[2] ?? null;

// Set ID in GET for endpoints that need it
if ($id) {
    $_GET['post_id'] = (int) $id;
}

// Plugin path
$pluginPath = dirname(__DIR__);

// Load dependencies
require_once $pluginPath . '/includes/class-jtb-element.php';
require_once $pluginPath . '/includes/class-jtb-registry.php';
require_once $pluginPath . '/includes/class-jtb-fields.php';
require_once $pluginPath . '/includes/class-jtb-renderer.php';
require_once $pluginPath . '/includes/class-jtb-settings.php';
require_once $pluginPath . '/includes/class-jtb-builder.php';

// Initialize registry
JTB_Registry::init();
JTB_Fields::init();

// Load modules
$modulesPath = $pluginPath . '/modules';

// All module categories to load
$moduleCategories = ['structure', 'content', 'interactive', 'media', 'forms', 'blog', 'fullwidth'];

foreach ($moduleCategories as $category) {
    $categoryPath = $modulesPath . '/' . $category;
    if (is_dir($categoryPath)) {
        foreach (glob($categoryPath . '/*.php') as $moduleFile) {
            require_once $moduleFile;
        }
    }
}

// Valid endpoints
$validEndpoints = ['save', 'load', 'render', 'modules', 'upload'];

if (!in_array($action, $validEndpoints)) {
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Endpoint not found: ' . $action]);
    exit;
}

// Route to API file
$apiFile = $pluginPath . '/api/' . $action . '.php';

if (file_exists($apiFile)) {
    require_once $apiFile;
} else {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'API file not found']);
}
