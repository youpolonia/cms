<?php
/**
 * Jessie Theme Builder - Admin Entry Point
 * Access via: /admin/jessie-theme-builder
 *
 * Called from JtbController - session/auth already handled by framework
 */

// CMS_ROOT is already defined by the framework/controller
if (!defined('CMS_ROOT')) {
    die('Direct access not allowed');
}

// Get post ID if provided
$postId = isset($_GET['post_id']) ? (int)$_GET['post_id'] : 0;

// If post_id provided, redirect to proper edit URL
if ($postId > 0) {
    header('Location: /admin/jessie-theme-builder/edit/' . $postId);
    exit;
}

// Get pages from database
$db = \core\Database::connection();
$posts = $db->query("SELECT id, title, slug, status FROM pages ORDER BY updated_at DESC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

if (!function_exists('esc')) {
    function esc($str) {
        return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jessie Theme Builder</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
            color: #fff;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 40px;
        }
        .header h1 {
            font-size: 28px;
            color: #e94560;
        }
        .header a {
            color: #888;
            text-decoration: none;
            padding: 8px 16px;
            border: 1px solid #333;
            border-radius: 6px;
            transition: all 0.2s;
        }
        .header a:hover {
            border-color: #e94560;
            color: #e94560;
        }
        .intro {
            background: rgba(255,255,255,0.05);
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 40px;
        }
        .intro h2 {
            font-size: 20px;
            margin-bottom: 10px;
        }
        .intro p {
            color: #888;
            line-height: 1.6;
        }
        .pages-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
        }
        .page-card {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            padding: 20px;
            transition: all 0.2s;
        }
        .page-card:hover {
            border-color: #e94560;
            transform: translateY(-2px);
        }
        .page-card h3 {
            font-size: 16px;
            margin-bottom: 8px;
            color: #fff;
        }
        .page-card .meta {
            font-size: 12px;
            color: #666;
            margin-bottom: 15px;
        }
        .page-card .meta span {
            display: inline-block;
            padding: 2px 8px;
            background: rgba(233, 69, 96, 0.2);
            color: #e94560;
            border-radius: 4px;
            margin-right: 8px;
        }
        .page-card .actions {
            display: flex;
            gap: 10px;
        }
        .page-card .btn {
            flex: 1;
            padding: 10px;
            text-align: center;
            border-radius: 6px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.2s;
        }
        .btn-primary {
            background: #e94560;
            color: white;
        }
        .btn-primary:hover {
            background: #ff6b6b;
        }
        .btn-secondary {
            background: rgba(255,255,255,0.1);
            color: #fff;
        }
        .btn-secondary:hover {
            background: rgba(255,255,255,0.2);
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }
        .empty-state h3 {
            font-size: 18px;
            margin-bottom: 10px;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>🎨 Jessie Theme Builder</h1>
            <a href="/admin">← Back to Dashboard</a>
        </header>

        <section class="intro">
            <h2>Visual Page Builder</h2>
            <p>Create beautiful pages with our drag-and-drop builder. Select a page below to start editing, or create a new page first in the Content section.</p>
        </section>

        <?php if (empty($posts)): ?>
        <div class="empty-state">
            <h3>No pages found</h3>
            <p>Create a page first, then come back here to design it visually.</p>
            <a href="/admin/pages/new" class="btn btn-primary" style="display: inline-block; margin-top: 20px; padding: 12px 24px;">Create New Page</a>
        </div>
        <?php else: ?>
        <div class="pages-grid">
            <?php foreach ($posts as $post): ?>
            <div class="page-card">
                <h3><?= esc($post['title']) ?></h3>
                <div class="meta">
                    <span><?= esc($post['status'] ?? 'draft') ?></span>
                    ID: <?= $post['id'] ?>
                </div>
                <div class="actions">
                    <a href="?post_id=<?= $post['id'] ?>" class="btn btn-primary">✏️ Edit with Builder</a>
                    <a href="/<?= esc($post['slug'] ?? 'post/' . $post['id']) ?>" target="_blank" class="btn btn-secondary">👁️ View</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
