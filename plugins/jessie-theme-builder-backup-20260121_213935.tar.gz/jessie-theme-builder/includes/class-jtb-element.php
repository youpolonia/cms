<?php
/**
 * Base Element Class
 * Abstract class for all JTB modules with field generators
 *
 * @package JessieThemeBuilder
 */

namespace JessieThemeBuilder;

defined('CMS_ROOT') or die('Direct access not allowed');

abstract class JTB_Element
{
    // ========================================
    // Public Properties
    // ========================================

    public string $slug = '';
    public string $name = '';
    public string $icon = 'text';
    public string $category = 'content';

    // Feature Flags
    public bool $use_background = true;
    public bool $use_spacing = true;
    public bool $use_border = true;
    public bool $use_box_shadow = true;
    public bool $use_typography = false;
    public bool $use_animation = true;
    public bool $use_transform = true;
    public bool $use_position = false;
    public bool $use_filters = true;

    // Parent-Child
    public bool $is_child = false;
    public string $child_slug = '';

    // ========================================
    // Abstract Methods
    // ========================================

    abstract public function getSlug(): string;
    abstract public function getName(): string;
    abstract public function getFields(): array;
    abstract public function render(array $attrs, string $content = ''): string;

    // ========================================
    // Public Methods
    // ========================================

    public function getContentFields(): array
    {
        return $this->getFields();
    }

    public function getDesignFields(): array
    {
        $fields = [];

        if ($this->use_typography) {
            $fields['typography'] = [
                'label' => 'Typography',
                'type' => 'group',
                'toggle' => true,
                'fields' => $this->getTypographyFields()
            ];
        }

        if ($this->use_spacing) {
            $fields['spacing'] = [
                'label' => 'Spacing',
                'type' => 'group',
                'toggle' => true,
                'fields' => $this->getSpacingFields()
            ];
        }

        if ($this->use_border) {
            $fields['border'] = [
                'label' => 'Border',
                'type' => 'group',
                'toggle' => true,
                'fields' => $this->getBorderFields()
            ];
        }

        if ($this->use_box_shadow) {
            $fields['box_shadow'] = [
                'label' => 'Box Shadow',
                'type' => 'group',
                'toggle' => true,
                'fields' => $this->getBoxShadowFields()
            ];
        }

        if ($this->use_background) {
            $fields['background'] = [
                'label' => 'Background',
                'type' => 'group',
                'toggle' => true,
                'fields' => $this->getBackgroundFields()
            ];
        }

        if ($this->use_filters) {
            $fields['filters'] = [
                'label' => 'Filters',
                'type' => 'group',
                'toggle' => true,
                'fields' => $this->getFilterFields()
            ];
        }

        if ($this->use_transform) {
            $fields['transform'] = [
                'label' => 'Transform',
                'type' => 'group',
                'toggle' => true,
                'fields' => $this->getTransformFields()
            ];
        }

        if ($this->use_animation) {
            $fields['animation'] = [
                'label' => 'Animation',
                'type' => 'group',
                'toggle' => true,
                'fields' => $this->getAnimationFields()
            ];
        }

        return $fields;
    }

    public function getAdvancedFields(): array
    {
        $fields = [];

        // CSS ID & Classes
        $fields['css_id_classes'] = [
            'label' => 'CSS ID & Classes',
            'type' => 'group',
            'toggle' => true,
            'fields' => [
                'css_id' => [
                    'label' => 'CSS ID',
                    'type' => 'text',
                    'description' => 'Unique ID for this element'
                ],
                'css_class' => [
                    'label' => 'CSS Class',
                    'type' => 'text',
                    'description' => 'Additional CSS classes'
                ]
            ]
        ];

        // Custom CSS
        $fields['custom_css'] = [
            'label' => 'Custom CSS',
            'type' => 'group',
            'toggle' => true,
            'fields' => $this->getCustomCssFields()
        ];

        // Visibility
        $fields['visibility'] = [
            'label' => 'Visibility',
            'type' => 'group',
            'toggle' => true,
            'fields' => [
                'disable_on_desktop' => [
                    'label' => 'Disable on Desktop',
                    'type' => 'toggle',
                    'default' => false
                ],
                'disable_on_tablet' => [
                    'label' => 'Disable on Tablet',
                    'type' => 'toggle',
                    'default' => false
                ],
                'disable_on_phone' => [
                    'label' => 'Disable on Phone',
                    'type' => 'toggle',
                    'default' => false
                ]
            ]
        ];

        // Position (if enabled)
        if ($this->use_position) {
            $fields['position'] = [
                'label' => 'Position',
                'type' => 'group',
                'toggle' => true,
                'fields' => $this->getPositionFields()
            ];
        }

        return $fields;
    }

    // ========================================
    // Protected Field Generator Methods
    // ========================================

    protected function getTypographyFields(): array
    {
        return [
            'font_family' => [
                'label' => 'Font Family',
                'type' => 'select',
                'options' => $this->getFontOptions(),
                'responsive' => true
            ],
            'font_size' => [
                'label' => 'Font Size',
                'type' => 'range',
                'min' => 1,
                'max' => 100,
                'unit' => 'px',
                'responsive' => true
            ],
            'font_weight' => [
                'label' => 'Font Weight',
                'type' => 'select',
                'options' => [
                    '100' => 'Thin (100)',
                    '200' => 'Extra Light (200)',
                    '300' => 'Light (300)',
                    '400' => 'Regular (400)',
                    '500' => 'Medium (500)',
                    '600' => 'Semi Bold (600)',
                    '700' => 'Bold (700)',
                    '800' => 'Extra Bold (800)',
                    '900' => 'Black (900)'
                ],
                'responsive' => true
            ],
            'font_style' => [
                'label' => 'Font Style',
                'type' => 'select',
                'options' => [
                    'normal' => 'Normal',
                    'italic' => 'Italic'
                ]
            ],
            'text_transform' => [
                'label' => 'Text Transform',
                'type' => 'select',
                'options' => [
                    'none' => 'None',
                    'uppercase' => 'Uppercase',
                    'lowercase' => 'Lowercase',
                    'capitalize' => 'Capitalize'
                ]
            ],
            'text_decoration' => [
                'label' => 'Text Decoration',
                'type' => 'select',
                'options' => [
                    'none' => 'None',
                    'underline' => 'Underline',
                    'line-through' => 'Line Through'
                ]
            ],
            'line_height' => [
                'label' => 'Line Height',
                'type' => 'range',
                'min' => 0.5,
                'max' => 3,
                'step' => 0.1,
                'unit' => 'em',
                'responsive' => true
            ],
            'letter_spacing' => [
                'label' => 'Letter Spacing',
                'type' => 'range',
                'min' => -5,
                'max' => 20,
                'unit' => 'px',
                'responsive' => true
            ],
            'text_color' => [
                'label' => 'Text Color',
                'type' => 'color',
                'hover' => true
            ],
            'text_align' => [
                'label' => 'Text Alignment',
                'type' => 'select',
                'options' => [
                    'left' => 'Left',
                    'center' => 'Center',
                    'right' => 'Right',
                    'justify' => 'Justify'
                ],
                'responsive' => true
            ]
        ];
    }

    protected function getSpacingFields(): array
    {
        return [
            'margin' => [
                'label' => 'Margin',
                'type' => 'spacing',
                'responsive' => true,
                'sides' => ['top', 'right', 'bottom', 'left'],
                'unit' => 'px'
            ],
            'padding' => [
                'label' => 'Padding',
                'type' => 'spacing',
                'responsive' => true,
                'sides' => ['top', 'right', 'bottom', 'left'],
                'unit' => 'px'
            ]
        ];
    }

    protected function getBorderFields(): array
    {
        return [
            'border_width' => [
                'label' => 'Border Width',
                'type' => 'spacing',
                'sides' => ['top', 'right', 'bottom', 'left'],
                'unit' => 'px'
            ],
            'border_style' => [
                'label' => 'Border Style',
                'type' => 'select',
                'options' => [
                    'none' => 'None',
                    'solid' => 'Solid',
                    'dashed' => 'Dashed',
                    'dotted' => 'Dotted',
                    'double' => 'Double'
                ]
            ],
            'border_color' => [
                'label' => 'Border Color',
                'type' => 'color',
                'hover' => true
            ],
            'border_radius' => [
                'label' => 'Border Radius',
                'type' => 'spacing',
                'sides' => ['top_left', 'top_right', 'bottom_right', 'bottom_left'],
                'unit' => 'px'
            ]
        ];
    }

    protected function getBoxShadowFields(): array
    {
        return [
            'box_shadow_style' => [
                'label' => 'Box Shadow',
                'type' => 'select',
                'options' => [
                    'none' => 'None',
                    'preset1' => 'Preset 1 (Light)',
                    'preset2' => 'Preset 2 (Medium)',
                    'preset3' => 'Preset 3 (Heavy)',
                    'custom' => 'Custom'
                ]
            ],
            'box_shadow_horizontal' => [
                'label' => 'Horizontal Offset',
                'type' => 'range',
                'min' => -100,
                'max' => 100,
                'unit' => 'px',
                'show_if' => ['box_shadow_style' => 'custom']
            ],
            'box_shadow_vertical' => [
                'label' => 'Vertical Offset',
                'type' => 'range',
                'min' => -100,
                'max' => 100,
                'unit' => 'px',
                'show_if' => ['box_shadow_style' => 'custom']
            ],
            'box_shadow_blur' => [
                'label' => 'Blur',
                'type' => 'range',
                'min' => 0,
                'max' => 100,
                'unit' => 'px',
                'show_if' => ['box_shadow_style' => 'custom']
            ],
            'box_shadow_spread' => [
                'label' => 'Spread',
                'type' => 'range',
                'min' => -100,
                'max' => 100,
                'unit' => 'px',
                'show_if' => ['box_shadow_style' => 'custom']
            ],
            'box_shadow_color' => [
                'label' => 'Shadow Color',
                'type' => 'color',
                'default' => 'rgba(0,0,0,0.3)',
                'show_if' => ['box_shadow_style' => 'custom']
            ]
        ];
    }

    protected function getBackgroundFields(): array
    {
        return [
            'background_type' => [
                'label' => 'Background Type',
                'type' => 'select',
                'options' => [
                    'none' => 'None',
                    'color' => 'Color',
                    'gradient' => 'Gradient',
                    'image' => 'Image'
                ]
            ],
            'background_color' => [
                'label' => 'Background Color',
                'type' => 'color',
                'hover' => true,
                'show_if' => ['background_type' => 'color']
            ],
            'background_gradient_start' => [
                'label' => 'Gradient Start',
                'type' => 'color',
                'show_if' => ['background_type' => 'gradient']
            ],
            'background_gradient_end' => [
                'label' => 'Gradient End',
                'type' => 'color',
                'show_if' => ['background_type' => 'gradient']
            ],
            'background_gradient_type' => [
                'label' => 'Gradient Type',
                'type' => 'select',
                'options' => [
                    'linear' => 'Linear',
                    'radial' => 'Radial'
                ],
                'show_if' => ['background_type' => 'gradient']
            ],
            'background_gradient_direction' => [
                'label' => 'Gradient Direction',
                'type' => 'range',
                'min' => 0,
                'max' => 360,
                'unit' => 'deg',
                'show_if' => ['background_type' => 'gradient']
            ],
            'background_image' => [
                'label' => 'Background Image',
                'type' => 'upload',
                'show_if' => ['background_type' => 'image']
            ],
            'background_size' => [
                'label' => 'Background Size',
                'type' => 'select',
                'options' => [
                    'cover' => 'Cover',
                    'contain' => 'Contain',
                    'auto' => 'Auto'
                ],
                'show_if' => ['background_type' => 'image']
            ],
            'background_position' => [
                'label' => 'Background Position',
                'type' => 'select',
                'options' => [
                    'top left' => 'Top Left',
                    'top center' => 'Top Center',
                    'top right' => 'Top Right',
                    'center left' => 'Center Left',
                    'center center' => 'Center',
                    'center right' => 'Center Right',
                    'bottom left' => 'Bottom Left',
                    'bottom center' => 'Bottom Center',
                    'bottom right' => 'Bottom Right'
                ],
                'show_if' => ['background_type' => 'image']
            ],
            'background_repeat' => [
                'label' => 'Background Repeat',
                'type' => 'select',
                'options' => [
                    'no-repeat' => 'No Repeat',
                    'repeat' => 'Repeat',
                    'repeat-x' => 'Repeat X',
                    'repeat-y' => 'Repeat Y'
                ],
                'show_if' => ['background_type' => 'image']
            ],
            'parallax' => [
                'label' => 'Parallax Effect',
                'type' => 'toggle',
                'default' => false,
                'show_if' => ['background_type' => 'image']
            ]
        ];
    }

    protected function getFilterFields(): array
    {
        return [
            'filter_hue_rotate' => [
                'label' => 'Hue Rotate',
                'type' => 'range',
                'min' => 0,
                'max' => 360,
                'unit' => 'deg',
                'default' => 0,
                'hover' => true
            ],
            'filter_saturate' => [
                'label' => 'Saturation',
                'type' => 'range',
                'min' => 0,
                'max' => 200,
                'unit' => '%',
                'default' => 100,
                'hover' => true
            ],
            'filter_brightness' => [
                'label' => 'Brightness',
                'type' => 'range',
                'min' => 0,
                'max' => 200,
                'unit' => '%',
                'default' => 100,
                'hover' => true
            ],
            'filter_contrast' => [
                'label' => 'Contrast',
                'type' => 'range',
                'min' => 0,
                'max' => 200,
                'unit' => '%',
                'default' => 100,
                'hover' => true
            ],
            'filter_invert' => [
                'label' => 'Invert',
                'type' => 'range',
                'min' => 0,
                'max' => 100,
                'unit' => '%',
                'default' => 0,
                'hover' => true
            ],
            'filter_sepia' => [
                'label' => 'Sepia',
                'type' => 'range',
                'min' => 0,
                'max' => 100,
                'unit' => '%',
                'default' => 0,
                'hover' => true
            ],
            'filter_blur' => [
                'label' => 'Blur',
                'type' => 'range',
                'min' => 0,
                'max' => 50,
                'unit' => 'px',
                'default' => 0,
                'hover' => true
            ]
        ];
    }

    protected function getTransformFields(): array
    {
        return [
            'transform_scale' => [
                'label' => 'Scale',
                'type' => 'range',
                'min' => 0,
                'max' => 200,
                'unit' => '%',
                'default' => 100,
                'hover' => true
            ],
            'transform_rotate' => [
                'label' => 'Rotate',
                'type' => 'range',
                'min' => -360,
                'max' => 360,
                'unit' => 'deg',
                'default' => 0,
                'hover' => true
            ],
            'transform_skew_x' => [
                'label' => 'Skew X',
                'type' => 'range',
                'min' => -60,
                'max' => 60,
                'unit' => 'deg',
                'default' => 0,
                'hover' => true
            ],
            'transform_skew_y' => [
                'label' => 'Skew Y',
                'type' => 'range',
                'min' => -60,
                'max' => 60,
                'unit' => 'deg',
                'default' => 0,
                'hover' => true
            ],
            'transform_translate_x' => [
                'label' => 'Translate X',
                'type' => 'range',
                'min' => -500,
                'max' => 500,
                'unit' => 'px',
                'responsive' => true,
                'hover' => true
            ],
            'transform_translate_y' => [
                'label' => 'Translate Y',
                'type' => 'range',
                'min' => -500,
                'max' => 500,
                'unit' => 'px',
                'responsive' => true,
                'hover' => true
            ],
            'transform_origin' => [
                'label' => 'Transform Origin',
                'type' => 'select',
                'options' => [
                    'top left' => 'Top Left',
                    'top center' => 'Top Center',
                    'top right' => 'Top Right',
                    'center left' => 'Center Left',
                    'center center' => 'Center',
                    'center right' => 'Center Right',
                    'bottom left' => 'Bottom Left',
                    'bottom center' => 'Bottom Center',
                    'bottom right' => 'Bottom Right'
                ]
            ]
        ];
    }

    protected function getAnimationFields(): array
    {
        return [
            'animation_style' => [
                'label' => 'Animation Style',
                'type' => 'select',
                'options' => [
                    'none' => 'None',
                    'fade' => 'Fade',
                    'slide' => 'Slide',
                    'bounce' => 'Bounce',
                    'zoom' => 'Zoom',
                    'flip' => 'Flip',
                    'fold' => 'Fold',
                    'roll' => 'Roll'
                ]
            ],
            'animation_direction' => [
                'label' => 'Animation Direction',
                'type' => 'select',
                'options' => [
                    'center' => 'Center',
                    'left' => 'Left',
                    'right' => 'Right',
                    'top' => 'Top',
                    'bottom' => 'Bottom'
                ],
                'show_if_not' => ['animation_style' => 'none']
            ],
            'animation_duration' => [
                'label' => 'Animation Duration',
                'type' => 'range',
                'min' => 0,
                'max' => 3000,
                'unit' => 'ms',
                'default' => 500,
                'show_if_not' => ['animation_style' => 'none']
            ],
            'animation_delay' => [
                'label' => 'Animation Delay',
                'type' => 'range',
                'min' => 0,
                'max' => 3000,
                'unit' => 'ms',
                'default' => 0,
                'show_if_not' => ['animation_style' => 'none']
            ],
            'animation_intensity' => [
                'label' => 'Animation Intensity',
                'type' => 'range',
                'min' => 0,
                'max' => 100,
                'unit' => '%',
                'default' => 50,
                'show_if_not' => ['animation_style' => 'none']
            ],
            'animation_starting_opacity' => [
                'label' => 'Starting Opacity',
                'type' => 'range',
                'min' => 0,
                'max' => 100,
                'unit' => '%',
                'default' => 0,
                'show_if_not' => ['animation_style' => 'none']
            ],
            'animation_repeat' => [
                'label' => 'Repeat Animation',
                'type' => 'toggle',
                'default' => false,
                'show_if_not' => ['animation_style' => 'none']
            ]
        ];
    }

    protected function getPositionFields(): array
    {
        return [
            'position_type' => [
                'label' => 'Position Type',
                'type' => 'select',
                'options' => [
                    'default' => 'Default',
                    'relative' => 'Relative',
                    'absolute' => 'Absolute',
                    'fixed' => 'Fixed'
                ]
            ],
            'position_origin' => [
                'label' => 'Position Origin',
                'type' => 'select',
                'options' => [
                    'top left' => 'Top Left',
                    'top center' => 'Top Center',
                    'top right' => 'Top Right',
                    'center left' => 'Center Left',
                    'center center' => 'Center',
                    'center right' => 'Center Right',
                    'bottom left' => 'Bottom Left',
                    'bottom center' => 'Bottom Center',
                    'bottom right' => 'Bottom Right'
                ],
                'show_if_not' => ['position_type' => ['default', 'relative']]
            ],
            'position_vertical_offset' => [
                'label' => 'Vertical Offset',
                'type' => 'range',
                'min' => -1000,
                'max' => 1000,
                'unit' => 'px',
                'responsive' => true,
                'show_if_not' => ['position_type' => 'default']
            ],
            'position_horizontal_offset' => [
                'label' => 'Horizontal Offset',
                'type' => 'range',
                'min' => -1000,
                'max' => 1000,
                'unit' => 'px',
                'responsive' => true,
                'show_if_not' => ['position_type' => 'default']
            ],
            'z_index' => [
                'label' => 'Z-Index',
                'type' => 'range',
                'min' => -100,
                'max' => 1000,
                'responsive' => true
            ]
        ];
    }

    protected function getCustomCssFields(): array
    {
        return [
            'before_module' => [
                'label' => 'Before Module',
                'type' => 'textarea',
                'rows' => 3,
                'description' => 'CSS applied before the module'
            ],
            'main_element' => [
                'label' => 'Main Element',
                'type' => 'textarea',
                'rows' => 3,
                'description' => 'CSS applied to the main element'
            ],
            'after_module' => [
                'label' => 'After Module',
                'type' => 'textarea',
                'rows' => 3,
                'description' => 'CSS applied after the module'
            ]
        ];
    }

    protected function getFontOptions(): array
    {
        return [
            // System Fonts
            'Arial' => 'Arial',
            'Helvetica' => 'Helvetica',
            'Georgia' => 'Georgia',
            'Times New Roman' => 'Times New Roman',
            'Verdana' => 'Verdana',
            'Courier New' => 'Courier New',
            // Google Fonts
            'Roboto' => 'Roboto',
            'Open Sans' => 'Open Sans',
            'Lato' => 'Lato',
            'Montserrat' => 'Montserrat',
            'Poppins' => 'Poppins',
            'Raleway' => 'Raleway',
            'Playfair Display' => 'Playfair Display',
            'Merriweather' => 'Merriweather',
            'Oswald' => 'Oswald',
            'Source Sans Pro' => 'Source Sans Pro'
        ];
    }

    // ========================================
    // Helper Methods
    // ========================================

    protected function esc(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    }

    protected function renderWrapper(string $content, array $attrs): string
    {
        $classes = ['jtb-module', 'jtb-module-' . $this->getSlug()];

        // Add custom CSS class
        if (!empty($attrs['css_class'])) {
            $classes[] = $this->esc($attrs['css_class']);
        }

        // Add visibility classes
        if (!empty($attrs['disable_on_desktop'])) {
            $classes[] = 'jtb-hide-desktop';
        }
        if (!empty($attrs['disable_on_tablet'])) {
            $classes[] = 'jtb-hide-tablet';
        }
        if (!empty($attrs['disable_on_phone'])) {
            $classes[] = 'jtb-hide-phone';
        }

        // Add animation classes
        if (!empty($attrs['animation_style']) && $attrs['animation_style'] !== 'none') {
            $classes[] = 'jtb-animated';
            $classes[] = 'jtb-animation-' . $this->esc($attrs['animation_style']);

            if (!empty($attrs['animation_direction'])) {
                $classes[] = 'jtb-animation-' . $this->esc($attrs['animation_direction']);
            }
        }

        $classStr = implode(' ', $classes);
        $idAttr = !empty($attrs['css_id']) ? ' id="' . $this->esc($attrs['css_id']) . '"' : '';

        // Animation data attributes
        $dataAttrs = '';
        if (!empty($attrs['animation_style']) && $attrs['animation_style'] !== 'none') {
            $dataAttrs .= ' data-animation-duration="' . ($attrs['animation_duration'] ?? 500) . '"';
            $dataAttrs .= ' data-animation-delay="' . ($attrs['animation_delay'] ?? 0) . '"';
            $dataAttrs .= ' data-animation-intensity="' . ($attrs['animation_intensity'] ?? 50) . '"';
            $dataAttrs .= ' data-animation-starting-opacity="' . ($attrs['animation_starting_opacity'] ?? 0) . '"';
            if (!empty($attrs['animation_repeat'])) {
                $dataAttrs .= ' data-animation-repeat="true"';
            }
        }

        return '<div class="' . $classStr . '"' . $idAttr . $dataAttrs . '>' . $content . '</div>';
    }

    public function generateId(): string
    {
        return $this->getSlug() . '_' . substr(bin2hex(random_bytes(4)), 0, 8);
    }

    public function generateCss(array $attrs, string $selector): string
    {
        $css = '';

        // Background
        $css .= $this->generateBackgroundCss($attrs, $selector);

        // Spacing
        $css .= $this->generateSpacingCss($attrs, $selector);

        // Border
        $css .= $this->generateBorderCss($attrs, $selector);

        // Box Shadow
        $css .= $this->generateBoxShadowCss($attrs, $selector);

        // Typography (if enabled)
        if ($this->use_typography) {
            $css .= $this->generateTypographyCss($attrs, $selector);
        }

        // Filters
        $css .= $this->generateFiltersCss($attrs, $selector);

        // Transform
        $css .= $this->generateTransformCss($attrs, $selector);

        // Position
        if ($this->use_position) {
            $css .= $this->generatePositionCss($attrs, $selector);
        }

        // Custom CSS
        $css .= $this->generateCustomCss($attrs, $selector);

        // Responsive CSS
        $css .= $this->generateResponsiveCss($attrs, $selector, 'tablet', 980);
        $css .= $this->generateResponsiveCss($attrs, $selector, 'phone', 767);

        return $css;
    }

    protected function generateBackgroundCss(array $attrs, string $selector): string
    {
        $css = '';
        $rules = [];

        $bgType = $attrs['background_type'] ?? 'none';

        if ($bgType === 'color' && !empty($attrs['background_color'])) {
            $rules[] = 'background-color: ' . $attrs['background_color'];
        } elseif ($bgType === 'gradient') {
            $start = $attrs['background_gradient_start'] ?? '#ffffff';
            $end = $attrs['background_gradient_end'] ?? '#000000';
            $type = $attrs['background_gradient_type'] ?? 'linear';
            $direction = $attrs['background_gradient_direction'] ?? 180;

            if ($type === 'linear') {
                $rules[] = "background: linear-gradient({$direction}deg, {$start}, {$end})";
            } else {
                $rules[] = "background: radial-gradient(circle, {$start}, {$end})";
            }
        } elseif ($bgType === 'image' && !empty($attrs['background_image'])) {
            $rules[] = 'background-image: url(' . $attrs['background_image'] . ')';
            $rules[] = 'background-size: ' . ($attrs['background_size'] ?? 'cover');
            $rules[] = 'background-position: ' . ($attrs['background_position'] ?? 'center center');
            $rules[] = 'background-repeat: ' . ($attrs['background_repeat'] ?? 'no-repeat');

            if (!empty($attrs['parallax'])) {
                $rules[] = 'background-attachment: fixed';
            }
        }

        if (!empty($rules)) {
            $css .= $selector . ' { ' . implode('; ', $rules) . '; }' . "\n";
        }

        // Hover state
        if ($bgType === 'color' && !empty($attrs['background_color__hover'])) {
            $css .= $selector . ':hover { background-color: ' . $attrs['background_color__hover'] . '; }' . "\n";
        }

        return $css;
    }

    protected function generateSpacingCss(array $attrs, string $selector): string
    {
        $css = '';
        $rules = [];

        // Margin
        if (!empty($attrs['margin'])) {
            $margin = $attrs['margin'];
            if (is_array($margin)) {
                $rules[] = 'margin: ' . ($margin['top'] ?? 0) . 'px ' . ($margin['right'] ?? 0) . 'px ' . ($margin['bottom'] ?? 0) . 'px ' . ($margin['left'] ?? 0) . 'px';
            }
        }

        // Padding
        if (!empty($attrs['padding'])) {
            $padding = $attrs['padding'];
            if (is_array($padding)) {
                $rules[] = 'padding: ' . ($padding['top'] ?? 0) . 'px ' . ($padding['right'] ?? 0) . 'px ' . ($padding['bottom'] ?? 0) . 'px ' . ($padding['left'] ?? 0) . 'px';
            }
        }

        if (!empty($rules)) {
            $css .= $selector . ' { ' . implode('; ', $rules) . '; }' . "\n";
        }

        return $css;
    }

    protected function generateBorderCss(array $attrs, string $selector): string
    {
        $css = '';
        $rules = [];

        // Border width
        if (!empty($attrs['border_width'])) {
            $width = $attrs['border_width'];
            if (is_array($width)) {
                $rules[] = 'border-width: ' . ($width['top'] ?? 0) . 'px ' . ($width['right'] ?? 0) . 'px ' . ($width['bottom'] ?? 0) . 'px ' . ($width['left'] ?? 0) . 'px';
            }
        }

        // Border style
        if (!empty($attrs['border_style']) && $attrs['border_style'] !== 'none') {
            $rules[] = 'border-style: ' . $attrs['border_style'];
        }

        // Border color
        if (!empty($attrs['border_color'])) {
            $rules[] = 'border-color: ' . $attrs['border_color'];
        }

        // Border radius
        if (!empty($attrs['border_radius'])) {
            $radius = $attrs['border_radius'];
            if (is_array($radius)) {
                $rules[] = 'border-radius: ' . ($radius['top_left'] ?? 0) . 'px ' . ($radius['top_right'] ?? 0) . 'px ' . ($radius['bottom_right'] ?? 0) . 'px ' . ($radius['bottom_left'] ?? 0) . 'px';
            }
        }

        if (!empty($rules)) {
            $css .= $selector . ' { ' . implode('; ', $rules) . '; }' . "\n";
        }

        // Hover state
        if (!empty($attrs['border_color__hover'])) {
            $css .= $selector . ':hover { border-color: ' . $attrs['border_color__hover'] . '; }' . "\n";
        }

        return $css;
    }

    protected function generateBoxShadowCss(array $attrs, string $selector): string
    {
        $css = '';
        $style = $attrs['box_shadow_style'] ?? 'none';

        if ($style === 'none') {
            return $css;
        }

        $shadow = '';

        if ($style === 'preset1') {
            $shadow = '0 2px 4px rgba(0,0,0,0.1)';
        } elseif ($style === 'preset2') {
            $shadow = '0 4px 12px rgba(0,0,0,0.15)';
        } elseif ($style === 'preset3') {
            $shadow = '0 8px 24px rgba(0,0,0,0.2)';
        } elseif ($style === 'custom') {
            $h = $attrs['box_shadow_horizontal'] ?? 0;
            $v = $attrs['box_shadow_vertical'] ?? 0;
            $blur = $attrs['box_shadow_blur'] ?? 0;
            $spread = $attrs['box_shadow_spread'] ?? 0;
            $color = $attrs['box_shadow_color'] ?? 'rgba(0,0,0,0.3)';
            $shadow = "{$h}px {$v}px {$blur}px {$spread}px {$color}";
        }

        if (!empty($shadow)) {
            $css .= $selector . ' { box-shadow: ' . $shadow . '; }' . "\n";
        }

        return $css;
    }

    protected function generateTypographyCss(array $attrs, string $selector): string
    {
        $css = '';
        $rules = [];

        if (!empty($attrs['font_family'])) {
            $rules[] = "font-family: '{$attrs['font_family']}', sans-serif";
        }

        if (!empty($attrs['font_size'])) {
            $rules[] = 'font-size: ' . $attrs['font_size'] . 'px';
        }

        if (!empty($attrs['font_weight'])) {
            $rules[] = 'font-weight: ' . $attrs['font_weight'];
        }

        if (!empty($attrs['font_style'])) {
            $rules[] = 'font-style: ' . $attrs['font_style'];
        }

        if (!empty($attrs['text_transform'])) {
            $rules[] = 'text-transform: ' . $attrs['text_transform'];
        }

        if (!empty($attrs['text_decoration'])) {
            $rules[] = 'text-decoration: ' . $attrs['text_decoration'];
        }

        if (!empty($attrs['line_height'])) {
            $rules[] = 'line-height: ' . $attrs['line_height'] . 'em';
        }

        if (!empty($attrs['letter_spacing'])) {
            $rules[] = 'letter-spacing: ' . $attrs['letter_spacing'] . 'px';
        }

        if (!empty($attrs['text_color'])) {
            $rules[] = 'color: ' . $attrs['text_color'];
        }

        if (!empty($attrs['text_align'])) {
            $rules[] = 'text-align: ' . $attrs['text_align'];
        }

        if (!empty($rules)) {
            $css .= $selector . ' { ' . implode('; ', $rules) . '; }' . "\n";
        }

        // Hover state
        if (!empty($attrs['text_color__hover'])) {
            $css .= $selector . ':hover { color: ' . $attrs['text_color__hover'] . '; }' . "\n";
        }

        return $css;
    }

    protected function generateFiltersCss(array $attrs, string $selector): string
    {
        $css = '';
        $filters = [];
        $hoverFilters = [];

        $filterProps = ['hue_rotate', 'saturate', 'brightness', 'contrast', 'invert', 'sepia', 'blur'];
        $defaults = [0, 100, 100, 100, 0, 0, 0];

        foreach ($filterProps as $i => $prop) {
            $key = 'filter_' . $prop;
            $hoverKey = $key . '__hover';

            if (isset($attrs[$key]) && $attrs[$key] != $defaults[$i]) {
                $value = $attrs[$key];
                $unit = ($prop === 'hue_rotate') ? 'deg' : (($prop === 'blur') ? 'px' : '%');
                $funcName = str_replace('_', '-', $prop);
                if ($funcName === 'hue-rotate') {
                    $funcName = 'hue-rotate';
                }
                $filters[] = "{$funcName}({$value}{$unit})";
            }

            if (isset($attrs[$hoverKey])) {
                $value = $attrs[$hoverKey];
                $unit = ($prop === 'hue_rotate') ? 'deg' : (($prop === 'blur') ? 'px' : '%');
                $funcName = str_replace('_', '-', $prop);
                if ($funcName === 'hue-rotate') {
                    $funcName = 'hue-rotate';
                }
                $hoverFilters[] = "{$funcName}({$value}{$unit})";
            }
        }

        if (!empty($filters)) {
            $css .= $selector . ' { filter: ' . implode(' ', $filters) . '; }' . "\n";
        }

        if (!empty($hoverFilters)) {
            $css .= $selector . ':hover { filter: ' . implode(' ', $hoverFilters) . '; }' . "\n";
        }

        return $css;
    }

    protected function generateTransformCss(array $attrs, string $selector): string
    {
        $css = '';
        $transforms = [];
        $hoverTransforms = [];

        // Scale
        if (isset($attrs['transform_scale']) && $attrs['transform_scale'] != 100) {
            $transforms[] = 'scale(' . ($attrs['transform_scale'] / 100) . ')';
        }
        if (isset($attrs['transform_scale__hover'])) {
            $hoverTransforms[] = 'scale(' . ($attrs['transform_scale__hover'] / 100) . ')';
        }

        // Rotate
        if (isset($attrs['transform_rotate']) && $attrs['transform_rotate'] != 0) {
            $transforms[] = 'rotate(' . $attrs['transform_rotate'] . 'deg)';
        }
        if (isset($attrs['transform_rotate__hover'])) {
            $hoverTransforms[] = 'rotate(' . $attrs['transform_rotate__hover'] . 'deg)';
        }

        // Skew
        if (isset($attrs['transform_skew_x']) && $attrs['transform_skew_x'] != 0) {
            $transforms[] = 'skewX(' . $attrs['transform_skew_x'] . 'deg)';
        }
        if (isset($attrs['transform_skew_y']) && $attrs['transform_skew_y'] != 0) {
            $transforms[] = 'skewY(' . $attrs['transform_skew_y'] . 'deg)';
        }

        // Translate
        if (isset($attrs['transform_translate_x']) && $attrs['transform_translate_x'] != 0) {
            $transforms[] = 'translateX(' . $attrs['transform_translate_x'] . 'px)';
        }
        if (isset($attrs['transform_translate_y']) && $attrs['transform_translate_y'] != 0) {
            $transforms[] = 'translateY(' . $attrs['transform_translate_y'] . 'px)';
        }

        $rules = [];

        if (!empty($transforms)) {
            $rules[] = 'transform: ' . implode(' ', $transforms);
        }

        if (!empty($attrs['transform_origin'])) {
            $rules[] = 'transform-origin: ' . $attrs['transform_origin'];
        }

        if (!empty($rules)) {
            $css .= $selector . ' { ' . implode('; ', $rules) . '; }' . "\n";
        }

        if (!empty($hoverTransforms)) {
            $css .= $selector . ':hover { transform: ' . implode(' ', $hoverTransforms) . '; }' . "\n";
        }

        return $css;
    }

    protected function generatePositionCss(array $attrs, string $selector): string
    {
        $css = '';
        $rules = [];

        $posType = $attrs['position_type'] ?? 'default';

        if ($posType !== 'default') {
            $rules[] = 'position: ' . $posType;

            if (isset($attrs['z_index'])) {
                $rules[] = 'z-index: ' . $attrs['z_index'];
            }

            if ($posType !== 'relative') {
                $origin = $attrs['position_origin'] ?? 'top left';
                $vOffset = $attrs['position_vertical_offset'] ?? 0;
                $hOffset = $attrs['position_horizontal_offset'] ?? 0;

                $originParts = explode(' ', $origin);
                $vertical = $originParts[0] ?? 'top';
                $horizontal = $originParts[1] ?? 'left';

                $rules[] = $vertical . ': ' . $vOffset . 'px';
                $rules[] = $horizontal . ': ' . $hOffset . 'px';
            } else {
                if (isset($attrs['position_vertical_offset'])) {
                    $rules[] = 'top: ' . $attrs['position_vertical_offset'] . 'px';
                }
                if (isset($attrs['position_horizontal_offset'])) {
                    $rules[] = 'left: ' . $attrs['position_horizontal_offset'] . 'px';
                }
            }
        }

        if (!empty($rules)) {
            $css .= $selector . ' { ' . implode('; ', $rules) . '; }' . "\n";
        }

        return $css;
    }

    protected function generateCustomCss(array $attrs, string $selector): string
    {
        $css = '';

        if (!empty($attrs['before_module'])) {
            $css .= $selector . '::before { ' . $attrs['before_module'] . ' }' . "\n";
        }

        if (!empty($attrs['main_element'])) {
            $css .= $selector . ' { ' . $attrs['main_element'] . ' }' . "\n";
        }

        if (!empty($attrs['after_module'])) {
            $css .= $selector . '::after { ' . $attrs['after_module'] . ' }' . "\n";
        }

        return $css;
    }

    protected function generateResponsiveCss(array $attrs, string $selector, string $device, int $breakpoint): string
    {
        $css = '';
        $rules = [];

        $suffix = '__' . $device;

        // Check for responsive values
        $responsiveFields = [
            'font_size' => 'px',
            'line_height' => 'em',
            'letter_spacing' => 'px',
            'text_align' => '',
            'transform_translate_x' => 'px',
            'transform_translate_y' => 'px',
            'position_vertical_offset' => 'px',
            'position_horizontal_offset' => 'px'
        ];

        foreach ($responsiveFields as $field => $unit) {
            $key = $field . $suffix;
            if (isset($attrs[$key])) {
                $property = str_replace('_', '-', $field);
                $value = $attrs[$key] . $unit;
                $rules[] = "{$property}: {$value}";
            }
        }

        // Responsive margin
        if (!empty($attrs['margin' . $suffix])) {
            $margin = $attrs['margin' . $suffix];
            if (is_array($margin)) {
                $rules[] = 'margin: ' . ($margin['top'] ?? 0) . 'px ' . ($margin['right'] ?? 0) . 'px ' . ($margin['bottom'] ?? 0) . 'px ' . ($margin['left'] ?? 0) . 'px';
            }
        }

        // Responsive padding
        if (!empty($attrs['padding' . $suffix])) {
            $padding = $attrs['padding' . $suffix];
            if (is_array($padding)) {
                $rules[] = 'padding: ' . ($padding['top'] ?? 0) . 'px ' . ($padding['right'] ?? 0) . 'px ' . ($padding['bottom'] ?? 0) . 'px ' . ($padding['left'] ?? 0) . 'px';
            }
        }

        if (!empty($rules)) {
            $css .= '@media (max-width: ' . $breakpoint . 'px) {' . "\n";
            $css .= '  ' . $selector . ' { ' . implode('; ', $rules) . '; }' . "\n";
            $css .= '}' . "\n";
        }

        return $css;
    }
}
