<?php
/**
 * Notification model for admin notifications
 * 
 * @package CMS
 * @subpackage Models
 */

defined('CMS_ROOT') or die('No direct script access allowed');

class Notification {
    const TYPE_INFO = 'info';
    const TYPE_WARNING = 'warning';
    const TYPE_CRITICAL = 'critical';
    const TYPE_SUCCESS = 'success';

    /**
     * Create a new notification
     * 
     * @param string $title
     * @param string $message
     * @param string $type
     * @param int|null $recipient_id
     * @param bool $is_global
     * @return bool
     */
    public static function create(
        string $title,
        string $message,
        string $type = self::TYPE_INFO,
        ?int $recipient_id = null,
        bool $is_global = false
    ): bool {
        $db = Database::getConnection();
        $stmt = $db->prepare(
            "INSERT INTO admin_notifications 
            (title, message, type, recipient_id, is_global) 
            VALUES (?, ?, ?, ?, ?)"
        );
        
        return $stmt->execute([$title, $message, $type, $recipient_id, (int)$is_global]);
    }

    /**
     * Mark notification as read
     * 
     * @param int $notification_id
     * @return bool
     */
    public static function markAsRead(int $notification_id): bool {
        $db = Database::getConnection();
        $stmt = $db->prepare(
            "UPDATE admin_notifications 
            SET is_read = 1, read_at = NOW() 
            WHERE notification_id = ?"
        );
        return $stmt->execute([$notification_id]);
    }

    /**
     * Get notifications for user
     * 
     * @param int|null $user_id
     * @param int $limit
     * @param int $offset
     * @param bool $unread_only
     * @return array
     */
    public static function getForUser(
        ?int $user_id,
        int $limit = 20,
        int $offset = 0,
        bool $unread_only = false
    ): array {
        $db = Database::getConnection();
        $where = "(is_global = 1" . ($user_id ? " OR recipient_id = ?" : "") . ")";
        $params = $user_id ? [$user_id] : [];

        if ($unread_only) {
            $where .= " AND is_read = 0";
        }

        $stmt = $db->prepare(
            "SELECT * FROM admin_notifications 
            WHERE $where
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?"
        );

        $params = array_merge($params, [$limit, $offset]);
        $stmt->execute($params);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Count unread notifications for user
     * 
     * @param int|null $user_id
     * @return int
     */
    public static function countUnread(?int $user_id): int {
        $db = Database::getConnection();
        $where = "(is_global = 1" . ($user_id ? " OR recipient_id = ?" : "") . ")";
        $params = $user_id ? [$user_id] : [];

        $stmt = $db->prepare(
            "SELECT COUNT(*) FROM admin_notifications 
            WHERE $where AND is_read = 0"
        );
        $stmt->execute($params);
        
        return (int)$stmt->fetchColumn();
    }
}