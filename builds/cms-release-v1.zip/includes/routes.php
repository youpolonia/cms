<?php
// Existing routes...

// Add WebSocket route
$router->addRoute('GET', '/ws-presence', function() {
    $container = require __DIR__ . '/container.php';
    return new \CMS\Core\Response('WebSocket connection established', 200);
});

// Rest of existing routes...