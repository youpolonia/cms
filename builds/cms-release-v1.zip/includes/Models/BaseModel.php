<?php

namespace Includes\Models;

use Includes\Database\Connection;
use Includes\Database\TenantScope;

class BaseModel
{
    protected static $connection;
    protected static $table;
    protected static $columnWhitelist = [];
    
    public static function setConnection(Connection $connection)
    {
        self::$connection = $connection;
    }
    
    protected static function validateColumn(string $column): bool
    {
        if (!empty(static::$columnWhitelist)) {
            return in_array($column, static::$columnWhitelist);
        }
        return preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $column);
    }
    
    protected static function validateInOperator(array $values): void
    {
        if (count($values) > 100) {
            throw new \InvalidArgumentException('IN operator cannot accept more than 100 values');
        }
        
        foreach ($values as $value) {
            if (!is_scalar($value)) {
                throw new \InvalidArgumentException('IN operator values must be scalar');
            }
        }
    }
    
    protected static function addTenantScope()
    {
        // Implementation depends on TenantScope class
    }
}