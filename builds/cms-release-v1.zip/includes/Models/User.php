<?php
/**
 * User Model
 *
 * Handles database interactions for the users table.
 *
 * @package CMS
 * @subpackage Models
 */

// Prevent direct access
defined('CMS_ROOT') or die('No direct script access allowed');

class User
{
    private $db;

    public function __construct($dbConnection)
    {
        $this->db = $dbConnection;
    }

    /**
     * Finds a user by their ID.
     *
     * @param int $id The user's ID.
     * @return array|false The user data as an associative array, or false if not found.
     */
    public function findById($id)
    {
        $stmt = $this->db->prepare("SELECT id, username, email, first_name, last_name, is_active, created_at, updated_at FROM users WHERE id = ? AND is_active = 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    /**
     * Finds a user by their username.
     *
     * @param string $username The user's username.
     * @return array|false The user data as an associative array (including password_hash), or false if not found.
     */
    public function findByUsername($username)
    {
        $stmt = $this->db->prepare("SELECT id, username, password_hash, email, is_active FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    /**
     * Finds a user by their email address.
     *
     * @param string $email The user's email address.
     * @return array|false The user data as an associative array (including password_hash), or false if not found.
     */
    public function findByEmail($email)
    {
        $stmt = $this->db->prepare("SELECT id, username, password_hash, email, is_active FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    /**
     * Verifies a user's password.
     *
     * @param string $password The plain-text password to verify.
     * @param string $hashedPassword The hashed password from the database.
     * @return bool True if the password matches, false otherwise.
     */
    public function verifyPassword($password, $hashedPassword)
    {
        return password_verify($password, $hashedPassword);
    }

    /**
     * Creates a new user.
     *
     * @param string $username
     * @param string $password Plain text password
     * @param string $email
     * @param string|null $firstName
     * @param string|null $lastName
     * @param int $isActive
     * @return int|false The ID of the newly created user, or false on failure.
     */
    public function createUser($username, $password, $email, $firstName = null, $lastName = null, $isActive = 1)
    {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        if (!$passwordHash) {
            // Log error: password_hash failed
            return false;
        }

        $sql = "INSERT INTO users (username, password_hash, email, first_name, last_name, is_active) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            // Log error: prepare failed $this->db->error
            return false;
        }

        $stmt->bind_param("sssssi", $username, $passwordHash, $email, $firstName, $lastName, $isActive);

        if ($stmt->execute()) {
            return $this->db->insert_id;
        } else {
            // Log error: execute failed $stmt->error
            return false;
        }
    }

    /**
     * Assigns a role to a user.
     *
     * @param int $userId
     * @param int $roleId
     * @return bool True on success, false on failure or if already assigned.
     */
    public function assignRole($userId, $roleId)
    {
        // Check if already assigned
        $checkStmt = $this->db->prepare("SELECT user_id FROM user_roles WHERE user_id = ? AND role_id = ?");
        $checkStmt->bind_param("ii", $userId, $roleId);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        if ($checkResult->num_rows > 0) {
            return true; // Already assigned
        }

        $sql = "INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)";
        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            // Log error
            return false;
        }
        $stmt->bind_param("ii", $userId, $roleId);
        return $stmt->execute();
    }

    /**
     * Removes a role from a user.
     *
     * @param int $userId
     * @param int $roleId
     * @return bool True on success, false on failure.
     */
    public function removeRole($userId, $roleId)
    {
        $sql = "DELETE FROM user_roles WHERE user_id = ? AND role_id = ?";
        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            // Log error
            return false;
        }
        $stmt->bind_param("ii", $userId, $roleId);
        return $stmt->execute();
    }

    /**
     * Gets all roles assigned to a specific user.
     *
     * @param int $userId
     * @return array An array of role data (id, name).
     */
    public function getUserRoles($userId)
    {
        $sql = "SELECT r.id, r.name
                FROM roles r
                JOIN user_roles ur ON r.id = ur.role_id
                WHERE ur.user_id = ?";
        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            // Log error
            return [];
        }
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    /**
     * Checks if a user has a specific role.
     *
     * @param int $userId
     * @param string $roleName
     * @return bool True if the user has the role, false otherwise.
     */
    public function hasRole($userId, $roleName)
    {
        $roles = $this->getUserRoles($userId);
        foreach ($roles as $role) {
            if ($role['name'] === $roleName) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if a user has a specific permission.
     * This requires joining User -> UserRoles -> Roles -> RolePermissions -> Permissions
     *
     * @param int $userId
     * @param string $permissionName The name of the permission (e.g., 'create_page').
     * @return bool True if the user has the permission, false otherwise.
     */
    public function hasPermission($userId, $permissionName)
    {
        $sql = "SELECT COUNT(*) as count
                FROM user_roles ur
                JOIN role_permissions rp ON ur.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE ur.user_id = ? AND p.name = ?";
        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            // Log error
            return false;
        }
        $stmt->bind_param("is", $userId, $permissionName);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result['count'] > 0;
    }
     /**
      * Counts the total number of users in the system.
      *
      * @return int The total number of users.
      */
     public function countAllUsers()
     {
         $result = $this->db->query("SELECT COUNT(*) as total FROM users");
         if ($result) {
             return (int)$result->fetch_assoc()['total'];
         }
         return 0; // Or handle error
     }

     /**
      * Creates a password reset token for a user
      *
      * @param int $userId
      * @return string|false The reset token or false on failure
      */
     public function createPasswordResetToken($userId)
     {
         $token = bin2hex(random_bytes(32));
         $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
         
         $stmt = $this->db->prepare("UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?");
         if (!$stmt) {
             return false;
         }
         $stmt->bind_param("ssi", $token, $expires, $userId);
         return $stmt->execute() ? $token : false;
     }

     /**
      * Validates a password reset token
      *
      * @param string $token
      * @return array|false User data if valid token, false otherwise
      */
     public function validatePasswordResetToken($token)
     {
         $stmt = $this->db->prepare("SELECT id, email FROM users WHERE reset_token = ? AND reset_token_expires > NOW()");
         if (!$stmt) {
             return false;
         }
         $stmt->bind_param("s", $token);
         $stmt->execute();
         $result = $stmt->get_result();
         return $result->fetch_assoc();
     }

     /**
      * Updates a user's password and clears reset token
      *
      * @param int $userId
      * @param string $newPassword
      * @return bool True on success, false on failure
      */
     public function updatePassword($userId, $newPassword)
     {
         $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
         if (!$passwordHash) {
             return false;
         }

         $stmt = $this->db->prepare("UPDATE users SET password_hash = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?");
         if (!$stmt) {
             return false;
         }
         $stmt->bind_param("si", $passwordHash, $userId);
         return $stmt->execute();
     }
}