<?php

// Define env() helper for accessing environment variables or fallback .env file
if (!function_exists('env')) {
    function env(string $key, $default = null) {
        $value = getenv($key);
        if ($value !== false) {
            return $value;
        }

        // Optional fallback to .env file in project root
        static $envCache = null;
        if ($envCache === null && file_exists(__DIR__ . '/../../.env')) {
            $lines = file(__DIR__ . '/../../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $envCache = [];
            foreach ($lines as $line) {
                if (str_starts_with(trim($line), '#')) continue;
                if (!str_contains($line, '=')) continue;
                [$k, $v] = explode('=', $line, 2);
                $envCache[trim($k)] = trim($v);
            }
        }

        if ($envCache && isset($envCache[$key])) {
            return $envCache[$key];
        }

        return $default;
    }
}