<?php
/**
 * Static HTML Cache Handler
 * Generates and serves static HTML cache files for improved performance
 */
class StaticHtmlCache extends FileCache {
    private string $publicCacheDir;

    public function __construct() {
        $this->publicCacheDir = defined('CMS_ROOT') 
            ? CMS_ROOT . '/public/cache/'
            : __DIR__ . '/../../public/cache/';
        
        parent::__construct($this->publicCacheDir);
        
        if (!is_dir($this->publicCacheDir)) {
            if (!mkdir($this->publicCacheDir, 0755, true) && !is_dir($this->publicCacheDir)) {
                throw new RuntimeException("Failed to create cache directory: {$this->publicCacheDir}");
            }
        }
    }

    /**
     * Generate cache file from sanitized slug and HTML content
     */
    public function generateCache(string $slug, string $htmlContent, int $ttl = 86400): bool {
        $sanitizedSlug = $this->sanitizeSlug($slug);
        $cacheFile = $this->getCacheFilePath($sanitizedSlug);
        
        try {
            // Write HTML content directly (no serialization needed for static HTML)
            $tempFile = $this->publicCacheDir . uniqid('temp_', true) . '.html';
            
            if (file_put_contents($tempFile, $htmlContent) === false) {
                throw new RuntimeException("Failed to write temporary cache file");
            }
            
            if (!rename($tempFile, $cacheFile)) {
                @unlink($tempFile);
                throw new RuntimeException("Failed to move cache file to final location");
            }
            
            @chmod($cacheFile, 0644);
            return true;
            
        } catch (Exception $e) {
            error_log("StaticHtmlCache Error: " . $e->getMessage());
            @unlink($tempFile ?? '');
            return false;
        }
    }

    /**
     * Get cached HTML if exists and is fresh
     */
    public function getCachedHtml(string $slug): ?string {
        $sanitizedSlug = $this->sanitizeSlug($slug);
        $cacheFile = $this->getCacheFilePath($sanitizedSlug);
        
        if (!file_exists($cacheFile) || !is_readable($cacheFile)) {
            return null;
        }
        
        return file_get_contents($cacheFile) ?: null;
    }

    /**
     * Sanitize slug for safe filename usage
     */
    protected function sanitizeSlug(string $slug): string {
        $slug = preg_replace('/[^a-zA-Z0-9\-_]/', '-', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        return trim($slug, '-');
    }

    /**
     * Override parent method to use .html extension
     */
    protected function getCacheFilePath(string $key): string {
        $safeKey = $this->sanitizeSlug($this->cacheKeyPrefix . $key);
        return $this->cacheDir . $safeKey . '.html';
    }
}