<?php
namespace Includes\RoutingV2\Middleware;

use Includes\RoutingV2\Request;
use Includes\RoutingV2\Response;
use Includes\RoutingV2\MiddlewareInterface;

class TestMiddleware implements MiddlewareInterface {
    public function process(Request $request, callable $next): Response {
        error_log('TestMiddleware: Starting execution');
        error_log('TestMiddleware: Request method: ' . $request->getMethod());
        error_log('TestMiddleware: Request URI: ' . $request->getPath());
        
        $response = $next($request);
        error_log('TestMiddleware: Response object: ' . get_class($response));
        
        // Add header to response
        $headers = $response->getHeaders();
        $headers['X-Test-Middleware'] = 'Working';
        $responseWithHeader = new Response(
            $response->getStatusCode(),
            $headers,
            $response->getBody()
        );
        
        error_log('TestMiddleware: Response headers: ' . print_r($responseWithHeader->getHeaders(), true));
        
        return $responseWithHeader;
    }
}