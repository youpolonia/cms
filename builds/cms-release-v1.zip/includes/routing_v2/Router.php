<?php

namespace Includes\RoutingV2;

class Router {
    private RouteTable $routeTable;
    private array $globalMiddlewares = [];

    public function __construct() {
        $this->routeTable = new RouteTable();
    }

    public function addGlobalMiddleware(MiddlewareInterface $middleware): void {
        $this->globalMiddlewares[] = $middleware;
    }

    public function addRoute(string $method, string $path, $handler, ?string $tenantId = null): Route {
        $route = str_contains($path, '{')
            ? new DynamicRoute($method, $path, $handler)
            : new Route($method, $path, $handler);
        $this->routeTable->addRoute($route, $tenantId);
        return $route;
    }

    public function addTenantRoute(string $method, string $path, $handler, string $tenantId): Route {
        return $this->addRoute($method, "/$tenantId$path", $handler, $tenantId);
    }

    public function handle(Request $request): Response {
        $route = $this->routeTable->findRoute(
            $request->getMethod(),
            $request->getPath(),
            $request->getTenantId()
        );

        if (!$route) {
            return new Response(404, ['Content-Type' => 'text/plain'], 'Not Found');
        }

        $middlewares = array_merge($this->globalMiddlewares, $route->getMiddlewares());
        $handler = $route->getHandler();

        $pipeline = array_reduce(
            array_reverse($middlewares),
            function($next, $middleware) {
                return function($request) use ($middleware, $next) {
                    return $middleware->process($request, $next);
                };
            },
            function($request) use ($handler) {
                return $handler($request);
            }
        );

        return $pipeline($request);
    }
}