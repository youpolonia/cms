<?php
// Communications Index View
echo '<h1>Communications</h1>';
echo '<p>Communications system will be implemented here</p>';