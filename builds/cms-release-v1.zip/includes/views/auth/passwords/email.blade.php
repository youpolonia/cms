@extends('layouts.auth')

@section('content')
    <form method="POST" action="{{ route('password.email') }}">
        @csrf
        <div class="form-group">
            <label for="email">Email Address</label>
            <input id="email" type="email" name="email" required autofocus>
        </div>
        <button type="submit">Send Password Reset Link</button>
    </form>
@endsection