<?php View::extend('layout'); ?>

<?php View::section('content'); ?>
<h1>Test View</h1>
<p>This is a test view template.</p>
<p>Current time: <?= date('Y-m-d H:i:s') ?></p>
<?php View::endSection(); ?>