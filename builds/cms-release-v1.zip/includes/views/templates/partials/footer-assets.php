<?php if (isset($scripts)): ?>
    <?php foreach ($scripts as $js): ?>
        <script src="<?= $js ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>