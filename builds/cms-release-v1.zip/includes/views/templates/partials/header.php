<header class="site-header">
    <div class="container">
        <a href="/" class="logo"><?= View::e('site_name', 'CMS') ?></a>
        <nav class="main-nav">
            <?php View::partial('partials/navigation') ?>
        </nav>
    </div>
</header>