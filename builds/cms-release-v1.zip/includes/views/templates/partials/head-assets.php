<?php if (isset($stylesheets)): ?>
    <?php foreach ($stylesheets as $css): ?>
        <link rel="stylesheet" href="<?= $css ?>">
    <?php endforeach; ?>
<?php endif; ?>