<?php
/**
 * Enhanced File Cache with LRU eviction policy
 * 
 * @package CMS\Cache
 */

namespace CMS\Cache;

class EnhancedFileCache {
    public static $cacheDir = __DIR__ . '/../../cache/';
    private static $maxItems = 1000;
    private static $lruList = [];
    private static $lruFile = __DIR__ . '/../../cache/lru_index.json';
    public static $statsFile = __DIR__ . '/../../cache/stats.json';
    private static $compressionEnabled = true;
    private static $compressionLevel = 6; // 1-9 where 9 is maximum compression
    private static $stats = [
        'hits' => 0,
        'misses' => 0,
        'evictions' => 0,
        'compressions' => 0,
        'writes' => 0,
        'reads' => 0
    ];

    /**
     * Initialize cache directory and LRU tracking
     */
    public static function init() {
        if (!file_exists(self::$cacheDir)) {
            mkdir(self::$cacheDir, 0755, true);
        }
        
        if (file_exists(self::$lruFile)) {
            self::$lruList = json_decode(file_get_contents(self::$lruFile), true) ?: [];
        }

        if (file_exists(self::$statsFile)) {
            self::$stats = json_decode(file_get_contents(self::$statsFile), true) ?: self::$stats;
        }
    }

    /**
     * Store item in cache
     *
     * @param string $key Cache key
     * @param mixed $data Data to cache
     * @param int $ttl Time to live in seconds
     * @return bool True on success
     */
    public static function set(string $key, $data, int $ttl = 3600): bool {
        self::evictIfNeeded();
        self::$stats['writes']++;
        
        $cacheFile = self::getCachePath($key);
        
        if (self::$compressionEnabled) {
            self::$stats['compressions']++;
            $data = gzcompress(serialize($data), self::$compressionLevel);
        }
        
        $cacheData = [
            'data' => $data,
            'expires' => time() + $ttl,
            'created' => time(),
            'compressed' => self::$compressionEnabled
        ];
        
        $result = file_put_contents($cacheFile, serialize($cacheData));
        
        if ($result !== false) {
            self::updateLru($key);
            return true;
        }
        
        return false;
    }

    /**
     * Get item from cache
     * 
     * @param string $key Cache key
     * @return mixed|null Cached data or null if not found/expired
     */
    public static function get(string $key) {
        $cacheFile = self::getCachePath($key);
        
        if (!file_exists($cacheFile)) {
            self::$stats['misses']++;
            self::saveStats();
            return null;
        }
        
        self::$stats['hits']++;
        self::$stats['reads']++;
        
        $cacheData = unserialize(file_get_contents($cacheFile));
        
        if (!is_array($cacheData) || time() > $cacheData['expires']) {
            self::delete($key);
            return null;
        }
        
        self::updateLru($key);
        
        if (isset($cacheData['compressed']) && $cacheData['compressed']) {
            return unserialize(gzuncompress($cacheData['data']));
        }
        
        return $cacheData['data'];
    }

    /**
     * Delete item from cache
     * 
     * @param string $key Cache key
     * @return bool True if deleted, false if not found
     */
    public static function delete(string $key): bool {
        $cacheFile = self::getCachePath($key);
        
        if (file_exists($cacheFile)) {
            unlink($cacheFile);
            self::removeFromLru($key);
            return true;
        }
        
        return false;
    }

    /**
     * Enable/disable compression
     *
     * @param bool $enabled Whether to enable compression
     * @param int $level Compression level (1-9)
     */
    public static function setCompression(bool $enabled, int $level = 6): void {
        self::$compressionEnabled = $enabled;
        self::$compressionLevel = max(1, min(9, $level));
    }

    /**
     * Clear entire cache
     */
    /**
     * Clear entire cache
     * @static
     */
    public static function clear(): bool {
        $files = glob(self::$cacheDir . '*');
        $success = true;
        foreach ($files as $file) {
            if (is_file($file)) {
                $filename = basename($file);
                if ($filename !== 'lru_index.json' && $filename !== 'stats.json') {
                    $success = $success && unlink($file);
                }
            }
        }
        
        self::$lruList = [];
        file_put_contents(self::$lruFile, json_encode([]));
        self::$stats = [
            'hits' => 0,
            'misses' => 0,
            'evictions' => 0,
            'compressions' => 0,
            'writes' => 0,
            'reads' => 0
        ];
        self::saveStats();
        
        return $success;
    }

    /**
     * Warm up cache with frequently accessed items
     *
     * @param array $items Array of key => value pairs to pre-cache
     * @param int $ttl Time to live in seconds for warmed items
     */
    public static function warm(array $items, int $ttl = 86400): void {
        foreach ($items as $key => $value) {
            self::set($key, $value, $ttl);
        }
    }

    /**
     * Warm up cache from a callable that generates cache items
     *
     * @param callable $generator Function that returns key => value pairs
     * @param int $ttl Time to live in seconds for warmed items
     * @param int $chunkSize Number of items to process at once
     */
    public static function warmFromGenerator(callable $generator, int $ttl = 86400, int $chunkSize = 100): void {
        $chunk = [];
        $count = 0;
        
        foreach ($generator() as $key => $value) {
            $chunk[$key] = $value;
            $count++;
            
            if ($count % $chunkSize === 0) {
                self::warm($chunk, $ttl);
                $chunk = [];
            }
        }
        
        if (!empty($chunk)) {
            self::warm($chunk, $ttl);
        }
    }

    /**
     * Evict least recently used items if cache is full
     */
    private static function evictIfNeeded(): void {
        if (count(self::$lruList) >= self::$maxItems) {
            $keysToEvict = array_slice(self::$lruList, 0, ceil(self::$maxItems * 0.1)); // Evict 10%
            foreach ($keysToEvict as $key) {
                self::delete($key);
                self::$stats['evictions']++;
            }
            self::saveStats();
        }
    }

    /**
     * Update LRU tracking for a key
     * 
     * @param string $key Cache key
     */
    private static function updateLru(string $key): void {
        self::removeFromLru($key);
        self::$lruList[] = $key;
        file_put_contents(self::$lruFile, json_encode(self::$lruList));
    }

    /**
     * Remove key from LRU tracking
     * 
     * @param string $key Cache key
     */
    private static function removeFromLru(string $key): void {
        self::$lruList = array_filter(self::$lruList, fn($item) => $item !== $key);
    }

    /**
     * Get full path for cache file
     * 
     * @param string $key Cache key
     * @return string Full file path
     */
    private static function getCachePath(string $key): string {
        return self::$cacheDir . md5($key) . '.cache';
    }

    /**
     * Get current cache statistics
     *
     * @return array Cache statistics including hits, misses, evictions etc.
     */
    public static function getStats(): array {
        return self::$stats;
    }

    /**
     * Reset all statistics counters to zero and clear stats file
     *
     * @return bool True if stats were successfully reset, false on error
     */
    public static function resetStats(): bool {
        try {
            // Reset in-memory stats
            self::$stats = [
                'hits' => 0,
                'misses' => 0,
                'evictions' => 0,
                'compressions' => 0,
                'writes' => 0,
                'reads' => 0
            ];
            
            // Clear stats file if it exists
            if (file_exists(self::$statsFile)) {
                if (!unlink(self::$statsFile)) {
                    return false;
                }
            }
            
            // Save fresh stats
            return self::saveStats();
        } catch (\Exception $e) {
            error_log("Failed to reset cache stats: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Save statistics to persistent storage
     */
    private static function saveStats(): void {
        file_put_contents(self::$statsFile, json_encode(self::$stats));
    }
}

// Initialize on first load
EnhancedFileCache::init();