<?php
/**
 * Tenant-Aware Cache Implementation
 * 
 * Extends EnhancedFileCache with tenant-specific partitioning and metadata caching
 */

namespace CMS\Cache;

require_once __DIR__ . '/EnhancedFileCache.php';

class TenantCache extends EnhancedFileCache {
    private static $tenantId = null;
    private static $metadataCache = [];
    private static $metadataFile = __DIR__ . '/../../cache/tenant_metadata.json';

    /**
     * Set current tenant ID for cache operations
     * 
     * @param string $tenantId Tenant identifier
     */
    public static function setTenant(string $tenantId): void {
        self::$tenantId = $tenantId;
        self::loadMetadata();
    }

    /**
     * Get current tenant ID
     * 
     * @return string|null Current tenant ID or null if not set
     */
    public static function getTenant(): ?string {
        return self::$tenantId;
    }

    /**
     * Store item in tenant-aware cache
     * 
     * @param string $key Cache key
     * @param mixed $data Data to cache
     * @param int $ttl Time to live in seconds
     * @return bool True on success
     */
    public static function set(string $key, $data, int $ttl = 3600): bool {
        if (self::$tenantId === null) {
            throw new \RuntimeException('Tenant ID must be set before using TenantCache');
        }

        $tenantKey = self::getTenantKey($key);
        return parent::set($tenantKey, $data, $ttl);
    }

    /**
     * Get item from tenant-aware cache
     * 
     * @param string $key Cache key
     * @return mixed|null Cached data or null if not found/expired
     */
    public static function get(string $key) {
        if (self::$tenantId === null) {
            throw new \RuntimeException('Tenant ID must be set before using TenantCache');
        }

        $tenantKey = self::getTenantKey($key);
        return parent::get($tenantKey);
    }

    /**
     * Cache query results with tenant context
     * 
     * @param string $query Query string
     * @param array $params Query parameters
     * @param callable $executor Function to execute if cache miss
     * @param int $ttl Time to live in seconds
     * @return mixed Query results
     */
    public static function cacheQuery(string $query, array $params, callable $executor, int $ttl = 3600) {
        $cacheKey = self::getQueryCacheKey($query, $params);
        
        if ($cached = self::get($cacheKey)) {
            return $cached;
        }

        $result = $executor();
        self::set($cacheKey, $result, $ttl);
        return $result;
    }

    /**
     * Cache tenant metadata
     * 
     * @param string $key Metadata key
     * @param mixed $value Metadata value
     */
    public static function setMetadata(string $key, $value): void {
        if (self::$tenantId === null) {
            throw new \RuntimeException('Tenant ID must be set before using metadata cache');
        }

        self::$metadataCache[self::$tenantId][$key] = $value;
        self::saveMetadata();
    }

    /**
     * Get tenant metadata
     * 
     * @param string $key Metadata key
     * @return mixed|null Metadata value or null if not found
     */
    public static function getMetadata(string $key) {
        if (self::$tenantId === null) {
            throw new \RuntimeException('Tenant ID must be set before using metadata cache');
        }

        return self::$metadataCache[self::$tenantId][$key] ?? null;
    }

    /**
     * Generate tenant-specific cache key
     */
    private static function getTenantKey(string $key): string {
        return self::$tenantId . ':' . $key;
    }

    /**
     * Generate cache key for query results
     */
    private static function getQueryCacheKey(string $query, array $params): string {
        $normalizedQuery = preg_replace('/\s+/', ' ', trim($query));
        $paramsHash = md5(json_encode($params));
        return 'query:' . $normalizedQuery . ':' . $paramsHash;
    }

    /**
     * Load metadata from persistent storage
     */
    private static function loadMetadata(): void {
        if (file_exists(self::$metadataFile)) {
            self::$metadataCache = json_decode(file_get_contents(self::$metadataFile), true) ?: [];
        }
    }

    /**
     * Save metadata to persistent storage
     */
    private static function saveMetadata(): void {
        file_put_contents(self::$metadataFile, json_encode(self::$metadataCache));
    }
}