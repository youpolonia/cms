<?php
/**
 * CMS Asset Manager
 * 
 * @package CMS
 * @subpackage Theme
 */

namespace Includes\Theme;

class AssetManager
{
    protected Theme $theme;
    protected array $assets = [];
    protected bool $useMinified = false;
    protected bool $combineAssets = false;

    public function __construct(Theme $theme, array $config = [])
    {
        $this->theme = $theme;
        $this->useMinified = $config['use_minified'] ?? false;
        $this->combineAssets = $config['combine_assets'] ?? false;
    }

    public function addCss(string $path, array $options = []): void
    {
        $this->assets['css'][$path] = $options;
    }

    public function addJs(string $path, array $options = []): void
    {
        $this->assets['js'][$path] = $options;
    }

    public function renderCss(): string
    {
        $output = '';
        foreach ($this->assets['css'] ?? [] as $path => $options) {
            $version = $options['version'] ?? $this->getAssetVersion($path);
            $output .= sprintf(
                '<link rel="stylesheet" href="%s?%s">',
                $this->getAssetUrl($path),
                $version
            ) . "\n";
        }
        return $output;
    }

    public function renderJs(): string
    {
        $output = '';
        foreach ($this->assets['js'] ?? [] as $path => $options) {
            $version = $options['version'] ?? $this->getAssetVersion($path);
            $output .= sprintf(
                '<script src="%s?%s"></script>',
                $this->getAssetUrl($path),
                $version
            ) . "\n";
        }
        return $output;
    }

    protected function getAssetUrl(string $path): string
    {
        if (strpos($path, '://') !== false) {
            return $path; // CDN or absolute URL
        }
        return THEMES_DIR . $this->theme->getActiveTheme() . '/assets/' . $path;
    }

    protected function getAssetVersion(string $path): string
    {
        $fullPath = $this->theme->getThemePath() . '/assets/' . $path;
        return file_exists($fullPath) ? (string)filemtime($fullPath) : '1';
    }
}