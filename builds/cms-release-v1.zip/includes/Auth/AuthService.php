<?php

namespace Includes\Auth;

use PDO;
use PDOException;
use Core\Logger;

class AuthService
{
    private PDO $db;

    public function __construct()
    {
        $config = require __DIR__ . '/../../config/database.php';
        $connection = $config['connections'][$config['default_connection']];

        try {
            $this->db = new PDO(
                "mysql:host={$connection['host']};dbname={$connection['database']}",
                $connection['username'],
                $connection['password'],
                $config['options']
            );
        } catch (PDOException $e) {
            \Core\Logger::log('database', 'Connection failed: ' . $e->getMessage());
            throw $e;
        }
    }

    public function authenticate(string $username, string $password): ?array
    {
        $stmt = $this->db->prepare("
            SELECT id, username, password_hash, role 
            FROM cms_users 
            WHERE username = :username OR email = :username
        ");
        $stmt->execute([':username' => $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            return [
                'id' => $user['id'],
                'role' => $user['role']
            ];
        }

        return null;
    }
}