<?php
/**
 * View Renderer
 * Handles template rendering with layout support
 */
class ViewRenderer {
    public function render($viewPath, $data = [], $layoutPath = null) {
        $baseDir = __DIR__ . '/../'; // Project root from includes/

        extract($data);
        
        $fullViewPath = $baseDir . $viewPath;
        
        if ($layoutPath) {
            $fullLayoutPath = $baseDir . $layoutPath;
            ob_start();
            include $fullViewPath;
            $content = ob_get_clean();
            
            if (file_exists($fullLayoutPath)) {
                include $fullLayoutPath;
            } else {
                error_log("ViewRenderer: Layout file not found at {$fullLayoutPath}");
                echo "Layout file missing. "; // Output something if layout is missing
                echo $content; // Still output content
            }
        } else {
            if (file_exists($fullViewPath)) {
                include $fullViewPath;
            } else {
                error_log("ViewRenderer: View file not found at {$fullViewPath}");
                echo "View file missing.";
            }
        }
    }
}