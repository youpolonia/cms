<?php
// Load core path constants first
require_once __DIR__ . '/../core/constants.php';

// Ensure CMS_ROOT is defined
if (!defined('CMS_ROOT')) {
    throw new RuntimeException('CMS_ROOT must be defined before including bootstrap.php');
}

// Initialize error handling early
require_once __DIR__ . '/Debug/debug_error_handler.php';
\Includes\Debug\ErrorHandler::register();

// Maintenance mode check
try {
    // Skip maintenance check for admin users
    $isAdmin = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
    
    if (!$isAdmin) {
        // Check for maintenance flag file
        $maintenanceFlagPath = CMS_ROOT . '/config/maintenance.flag';
        if (file_exists($maintenanceFlagPath)) {
            // Verify maintenance template exists
            if (file_exists(CMS_ROOT . '/public/maintenance.php')) {
                // Maintenance mode is enabled - redirect
                header('Location: /maintenance.php');
                exit;
            }
            // Log error if template missing
            error_log('Maintenance template missing but flag present');
        }
    }
} catch (\Exception $e) {
    // Log error but continue execution
    error_log('Maintenance mode check failed: ' . $e->getMessage());
}

// Load environment variables
if (file_exists(__DIR__ . '/../.env')) {
    error_log('[BOOTSTRAP] Loading .env file');
    $envVars = parse_ini_file(__DIR__ . '/../.env');
    foreach ($envVars as $key => $value) {
        $_ENV[$key] = $value;
        putenv("$key=$value");
        error_log("[BOOTSTRAP] Set env: $key=" . substr($value, 0, 3) . '...');
    }
} else {
    error_log('[BOOTSTRAP] Warning: No .env file found');
}

// Load core files with existence checks
$coreFiles = [
    '/Core/Application.php',
    '/Core/ServiceContainer.php',
    '/ErrorHandler.php',
    '/Config/ConfigInterface.php',
    '/Config/ConfigCache.php',
    '/Config/ConfigLoader.php',
    '/Routing/Router.php',
    '/Performance/MetricsCollector.php'
];

foreach ($coreFiles as $file) {
    $path = __DIR__ . $file;
    if (!file_exists($path)) {
        throw new RuntimeException("Required core file missing: $file");
    }
    require_once $path;
}

// Initialize application
$app = \Includes\Core\Application::getInstance();

// Ensure MultiSite is loaded safely
$multiSitePath = __DIR__ . '/MultiSite.php';
if (!file_exists($multiSitePath)) {
    error_log('MultiSite.php missing - CMS cannot initialize');
    throw new RuntimeException('Required MultiSite component missing');
}
require_once $multiSitePath;

// Register core services
$app->register('config', function() {
    $fileCache = new \FileCache(); // FileCache is in global namespace
    $configDir = \CMS_ROOT . '/config';
    $env = $_ENV['APP_ENV'] ?? 'production';
    $configLoader = new \Includes\Config\ConfigLoader($fileCache, $configDir, $env);
    return $configLoader->all();
});

// Initialize MultiSite: now it can safely access the 'config' service
\App\Includes\MultiSite::initialize();

$app->register('router', function($app) {
    $globalRoutes = $app->get('config')['routes'] ?? [];
    $finalRoutes = $globalRoutes;

    if (\App\Includes\MultiSite::isEnabled()) {
        $currentSiteHandle = \App\Includes\MultiSite::getCurrentSiteId();
        if ($currentSiteHandle) {
            // Define path for site-specific routes. This assumes 'config' is a dir in site storage.
            // And CMS_ROOT is defined.
            $basePath = defined('CMS_ROOT') ? CMS_ROOT : dirname(__DIR__, 2); // Adjust if CMS_ROOT not defined
            $siteConfigPath = \App\Includes\MultiSite::getSiteStoragePath('config');
            $siteRoutesFile = $siteConfigPath . DIRECTORY_SEPARATOR . 'routes.php';
            
            if (!file_exists($siteRoutesFile)) {
                error_log("Site routes file missing: $siteRoutesFile");
                $siteRoutesFile = null; // Fall back to global routes only
            }

            if (file_exists($siteRoutesFile)) {
                $siteRoutes = require $siteRoutesFile;
                if (is_array($siteRoutes)) {
                    // Merge, site-specific routes can override global ones.
                    // array_replace_recursive might be better if routes are deeply nested.
                    // For simple [method][path] structure, array_merge should work if site routes come second.
                    // To ensure site routes properly override, we can iterate and replace.
                    foreach ($siteRoutes as $method => $methodRoutes) {
                        if (isset($finalRoutes[$method])) {
                            $finalRoutes[$method] = array_merge($finalRoutes[$method], $methodRoutes);
                        } else {
                            $finalRoutes[$method] = $methodRoutes;
                        }
                    }
                }
            }
        }
    }
    return new \Includes\Routing\Router($finalRoutes);
});

$app->register('db', function($app) {
    $config = $app->get('config');
    $databaseSettings = $config['database'] ?? []; // This is the whole array from config/database.php
    $defaultConnectionName = $databaseSettings['default_connection'] ?? 'mysql';
    // Get the specific connection's configuration from the 'connections' sub-array
    $connectionConfig = $databaseSettings['connections'][$defaultConnectionName] ?? [];

    $driver = $connectionConfig['driver'] ?? $defaultConnectionName; // Fallback to connection name if driver not set
    $dsn = '';
    $username = $connectionConfig['username'] ?? null;
    $password = $connectionConfig['password'] ?? null;
    // Use general PDO options from config, fallback to hardcoded if not present
    $options = $databaseSettings['options'] ?? [ // Use $databaseSettings for top-level 'options'
        \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
        \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
        \PDO::ATTR_EMULATE_PREPARES => false,
    ];
    // Merge connection-specific options if they exist
    if (isset($connectionConfig['options'])) {
        $options = array_replace($options, $connectionConfig['options']);
    }


    if ($driver === 'mysql') {
        $host = $connectionConfig['host'] ?? 'localhost';
        $port = $connectionConfig['port'] ?? '3306';
        $database = $connectionConfig['database'] ?? '';
        $charset = $connectionConfig['charset'] ?? 'utf8mb4';
        $dsn = "mysql:host={$host};port={$port};dbname={$database};charset={$charset}";
    } elseif ($driver === 'sqlite') {
        $dbPath = $connectionConfig['database'] ?? '';
        if (!$dbPath) {
            throw new \RuntimeException("SQLite database path not configured for connection '{$defaultConnectionName}'.");
        }
        // Ensure the path to sqlite is absolute or correctly relative to CMS_ROOT
        if (strpos($dbPath, '/') !== 0 && strpos($dbPath, ':') !== 1) { // Not absolute (Unix/Windows)
             $dbPath = \CMS_ROOT . '/' . ltrim($dbPath, '/');
        }
        $dsn = "sqlite:" . $dbPath;
    } else {
        throw new \RuntimeException("Unsupported database driver: {$driver} for connection '{$defaultConnectionName}'.");
    }

    try {
        return new \PDO($dsn, $username, $password, $options);
    } catch (\PDOException $e) {
        throw new \RuntimeException("Could not connect to database '{$defaultConnectionName}': " . $e->getMessage(), (int)$e->getCode(), $e);
    }
});

// Initialize Worker Monitoring Service
require_once __DIR__ . '/../services/WorkerMonitoringService.php';
try {
    $app->register('workerMonitoring', function($app) {
        return new \Services\WorkerMonitoringService(
            $app->get('config')['worker_monitoring'] ?? []
        );
    });
} catch (\Exception $e) {
    throw new \RuntimeException("Failed to initialize Worker Monitoring Service: " . $e->getMessage());
}

// Initialize Redis Cache Service with fallback
require_once __DIR__ . '/Cache/RedisCache.php';
require_once __DIR__ . '/Cache/FileCache.php';
try {
    $app->register('cache', function($app) {
        try {
            return new \Includes\Cache\RedisCache(
                $app->get('config')['redis'] ?? []
            );
        } catch (\Exception $e) {
            \Includes\Debug\ErrorHandler::logServiceFailure('RedisCache', $e->getMessage());
            return new \Includes\Cache\FileCache(
                $app->get('config')['file_cache'] ?? ['path' => \CMS_ROOT . '/cache']
            );
        }
    });
} catch (\Exception $e) {
    throw new \RuntimeException("Failed to initialize Cache Service: " . $e->getMessage());
}

// Initialize Personalization Services
require_once __DIR__ . '/Personalization/RuleEvaluator.php';
require_once __DIR__ . '/Personalization/ContentTargeting.php';
try {
    $app->register('personalization', function($app) {
        return [
            'ruleEvaluator' => new \Includes\Personalization\RuleEvaluator(
                $app->get('config')['personalization']['rules'] ?? []
            ),
            'contentTargeting' => new \Includes\Personalization\ContentTargeting(
                $app->get('config')['personalization']['content_targeting'] ?? []
            )
        ];
    });
} catch (\Exception $e) {
    throw new \RuntimeException("Failed to initialize Personalization Services: " . $e->getMessage());
}

// Load application constants
require_once __DIR__ . '/../config/constants.php';

// Configure error reporting based on debug mode
$debugMode = $app->get('config')['debug'] ?? false;
$errorLevels = $app->get('config')['error_levels'] ?? [E_ALL]; // Wrap in array

// Initialize Logger with configurable path
require_once __DIR__ . '/Core/Logger.php';
\Includes\Core\Logger::init($app->get('config')['logging']['path'] ?? 'logs/system.log');

// Initialize Security Service
require_once __DIR__ . '/Core/SecurityService.php';
try {
    $app->register('security', function($app) {
        return new \Includes\Core\SecurityService(
            $app->get('config')['security'] ?? []
        );
    });
} catch (\Exception $e) {
    throw new \RuntimeException("Failed to initialize Security Service: " . $e->getMessage());
}

if ($debugMode) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ERROR | E_WARNING | E_PARSE);
    ini_set('display_errors', '0');
}

// Bootstrap the application
$app->bootstrap();

return $app;