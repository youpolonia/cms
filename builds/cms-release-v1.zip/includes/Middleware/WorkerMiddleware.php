<?php

class WorkerMiddleware {
    private $auth;

    public function __construct() {
        $this->auth = new Authentication();
    }

    public function handle(string $token, string $requiredPermission): bool {
        if (!$this->auth->validateWorkerToken($token, $requiredPermission)) {
            http_response_code(403);
            echo json_encode(['error' => 'Invalid worker token or insufficient permissions']);
            return false;
        }
        return true;
    }
}