<?php
declare(strict_types=1);

namespace Includes\Middleware;

use Core\TenantContext;
use Services\TenantQuotaService;
use Exception;

class TenantMiddleware
{
    public function handle(array $request): array
    {
        try {
            $tenantId = $this->extractTenantId($request);
            $this->validateTenant($tenantId);
            
            TenantContext::setCurrent($tenantId);
            
            // Wrap quota check in try-catch to prevent middleware from failing
            try {
                TenantQuotaService::checkQuota($tenantId);
            } catch (Exception $e) {
                // Log quota check failure but continue processing
                error_log("Tenant quota check failed for {$tenantId}: " . $e->getMessage());
            }

            return $request;
        } catch (Exception $e) {
            error_log("TenantMiddleware failed: " . $e->getMessage());
            throw $e; // Re-throw to maintain existing behavior for critical failures
        }
    }

    private function extractTenantId(array $request): string
    {
        // First try subdomain (e.g. tenant1.example.com)
        $hostParts = explode('.', $request['headers']['host'] ?? '');
        if (count($hostParts) > 2) {
            return $hostParts[0];
        }

        // Fallback to X-Tenant-ID header
        if (!empty($request['headers']['x-tenant-id'])) {
            return $request['headers']['x-tenant-id'];
        }

        throw new Exception('Tenant identifier not found in request');
    }

    private function validateTenant(string $tenantId): void
    {
        // Implementation would query tenant database
        // For now, just validate format
        if (!preg_match('/^[a-z0-9\-]{3,32}$/i', $tenantId)) {
            throw new Exception('Invalid tenant identifier format');
        }
    }
}