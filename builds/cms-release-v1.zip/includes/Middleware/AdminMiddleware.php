<?php
namespace Middleware;

require_once __DIR__ . '/AuthMiddleware.php';

class AdminMiddleware extends AuthMiddleware {
    public static function handle($request, $next) {
        $response = parent::handle($request, $next);
        
        // If auth failed, return the error response
        if (isset($response['error'])) {
            return $response;
        }

        // Check for admin role
        $token = parent::getBearerToken($request);
        $payload = \Auth\JWT::decode($token);
        
        if ($payload->role !== 'admin') {
            return parent::unauthorizedResponse('Admin access required');
        }

        return $next($request);
    }
}