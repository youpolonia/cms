<?php
namespace Middleware;

use Core\Http\Request;
use Core\Http\Response;
use Core\Http\MiddlewareInterface;
use Core\Cache\CacheInterface;

class RateLimiterMiddleware implements MiddlewareInterface {
    private $cache;
    private $limit;
    private $window;

    public function __construct(CacheInterface $cache, int $limit = 100, int $window = 60) {
        $this->cache = $cache;
        $this->limit = $limit;
        $this->window = $window;
    }

    public function handle(Request $request, callable $next): Response {
        $ip = $request->getClientIp();
        $key = "rate_limit:$ip:" . $request->getPath();

        $count = $this->cache->get($key, 0);
        if ($count >= $this->limit) {
            return new Response(
                'Rate limit exceeded', 
                429,
                ['Retry-After' => $this->window]
            );
        }

        $this->cache->set($key, $count + 1, $this->window);
        return $next($request);
    }
}