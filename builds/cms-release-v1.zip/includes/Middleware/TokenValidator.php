<?php

class TokenValidator {
    public static function validate(string $token): array {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            SELECT u.id, u.username, u.email 
            FROM users u
            JOIN auth_tokens t ON u.id = t.user_id
            WHERE t.token = ? AND t.expires_at > NOW()
        ");
        $stmt->execute([$token]);
        
        $user = $stmt->fetch();
        if (!$user) {
            throw new Exception('Invalid or expired token');
        }

        return $user;
    }
}