<?php

class TenantAuth {
    /**
     * Authenticate tenant request
     * @param array $request Request data
     * @return array Modified request with tenant context
     * @throws Exception If authentication fails
     */
    public static function handle(array $request): array {
        // Validate required headers
        if (empty($request['headers']['X-Tenant-ID'])) {
            throw new Exception('Tenant ID header missing');
        }

        $tenantId = $request['headers']['X-Tenant-ID'];

        // Verify tenant exists
        if (!TenantManager::validateTenant($tenantId)) {
            throw new Exception('Invalid tenant ID');
        }

        // Check API quota
        if (!TenantManager::checkQuota($tenantId, 'requests', 1)) {
            throw new Exception('Tenant request quota exceeded');
        }

        // Record usage
        TenantQuotaService::recordUsage($tenantId, 'requests', 1);

        // Add tenant context to request
        $request['tenant'] = [
            'id' => $tenantId,
            'details' => TenantManager::getTenant($tenantId)
        ];

        return $request;
    }

    /**
     * Switch tenant context (for admin/superuser operations)
     * @param string $tenantId Tenant ID to switch to
     * @param string $currentUserId Current user ID
     * @throws Exception If switch not allowed
     */
    public static function switchTenant(string $tenantId, string $currentUserId): void {
        // Verify user has permission to switch tenants
        $pdo = DB::getConnection();
        $stmt = $pdo->prepare("
            SELECT is_superadmin FROM users 
            WHERE id = ? AND tenant_id = ?
        ");
        $stmt->execute([$currentUserId, $tenantId]);
        $user = $stmt->fetch();

        if (!$user || !$user['is_superadmin']) {
            throw new Exception('Not authorized to switch tenants');
        }

        // Verify target tenant exists
        if (!TenantManager::validateTenant($tenantId)) {
            throw new Exception('Invalid target tenant');
        }

        // Update session context
        $_SESSION['current_tenant'] = $tenantId;
    }
}