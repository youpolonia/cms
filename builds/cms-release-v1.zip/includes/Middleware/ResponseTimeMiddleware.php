<?php

declare(strict_types=1);

namespace App\Includes\Middleware;

use App\Includes\MultiSite;
use App\Includes\Database\DatabaseConnection;

class ResponseTimeMiddleware implements MiddlewareInterface {
    public static function handle($request, $next) {
        $start = microtime(true);
        $response = $next($request);
        $duration = (microtime(true) - $start) * 1000; // milliseconds

        if (MultiSite::isInitialized()) {
            DatabaseConnection::logPerformanceMetric(
                'response_time',
                $duration,
                [
                    'route' => $request->getRoute(),
                    'method' => $request->getMethod(),
                    'status' => $response->getStatusCode()
                ]
            );
        }

        return $response;
    }
}