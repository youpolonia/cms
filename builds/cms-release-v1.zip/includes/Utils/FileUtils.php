<?php

namespace Includes\Utils;

class FileUtils {
    /**
     * Checks if a directory exists and is writable
     * @param string $path Directory path
     * @return bool True if directory exists and is writable
     */
    public static function is_directory_writable(string $path): bool {
        return is_dir($path) && is_writable($path);
    }
}