<?php
declare(strict_types=1);

class WorkflowController {
    public static function handleTransitionRequest(
        int $contentId,
        string $transition,
        int $userId,
        array $context = []
    ): array {
        // Validate user can perform this transition
        $currentState = WorkflowStateManager::getCurrentState($contentId);
        
        if (!WorkflowTransitionHandler::canUserTransition($userId, $currentState, $transition)) {
            return [
                'success' => false,
                'error' => 'User not authorized for this transition'
            ];
        }

        // Check if transition requires approval
        $transitionData = ContentWorkflowSystem::getTransitionData($transition);
        
        if ($transitionData['requires_approval'] ?? false) {
            $approvers = UserManager::getUsersByRoles($transitionData['approver_roles']);
            $result = WorkflowApprovalSystem::requestApproval(
                $contentId,
                $userId,
                $approvers,
                $context['message'] ?? ''
            );
            
            return [
                'success' => $result,
                'requires_approval' => true,
                'approvers' => $approvers
            ];
        }

        // Execute immediate transition
        $result = WorkflowTransitionHandler::executeTransition(
            $contentId,
            $transition,
            $userId,
            $context
        );

        return [
            'success' => $result,
            'requires_approval' => false
        ];
    }

    public static function handleApprovalResponse(
        int $approvalId,
        int $approverId,
        bool $approved,
        string $comment = ''
    ): array {
        $result = WorkflowApprovalSystem::processApproval(
            $approvalId,
            $approverId,
            $approved,
            $comment
        );

        return [
            'success' => $result,
            'approved' => $approved
        ];
    }

    public static function getWorkflowState(int $contentId): array {
        return [
            'current_state' => WorkflowStateManager::getCurrentState($contentId),
            'available_transitions' => ContentWorkflowSystem::getAvailableTransitions(
                WorkflowStateManager::getCurrentState($contentId)
            )
        ];
    }
}