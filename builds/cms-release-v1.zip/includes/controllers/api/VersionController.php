<?php

class VersionController extends \Includes\Controllers\TenantAwareController {
    public function createVersion($contentId, $contentData, $userId, $isAutosave = false) {
        // Get next version number
        $this->requireTenant();
        $versionNumber = $this->db->querySingleValue(
            "SELECT COALESCE(MAX(version_number), 0) + 1
             FROM content_versions
             WHERE content_id = ? AND site_id = ?",
            [$contentId, $this->getCurrentSiteId()]
        );

        // Save new version
        $this->db->execute(
            "INSERT INTO content_versions
             (content_id, version_number, content_data, created_by, is_autosave, site_id)
             VALUES (?, ?, ?, ?, ?, ?)",
            [$contentId, $versionNumber, $contentData, $userId, $isAutosave, $this->getCurrentSiteId()]
        );

        return $versionNumber;
    }

    public function getVersions($contentId) {
        $this->requireTenant();
        return $this->db->query(
            "SELECT id, version_number, created_at, created_by, is_autosave
             FROM content_versions
             WHERE content_id = ? AND site_id = ?
             ORDER BY version_number DESC",
            [$contentId, $this->getCurrentSiteId()]
        );
    }

    public function restoreVersion($versionId, $userId, $reason = '') {
        $this->requireTenant();
        $version = $this->db->querySingleRow(
            "SELECT cv.content_id, cv.content_data, c.content as current_content, c.site_id
             FROM content_versions cv
             JOIN contents c ON cv.content_id = c.id
             WHERE cv.id = ? AND cv.site_id = ?",
            [$versionId, $this->getCurrentSiteId()]
        );

        if ($version) {
            $this->validateTenantAccess($version['site_id']);
            // Begin transaction
            $this->db->beginTransaction();
            
            try {
                // Update main content
                $this->db->execute(
                    "UPDATE contents
                     SET content = ?
                     WHERE id = ? AND site_id = ?",
                    [$version['content_data'], $version['content_id'], $this->getCurrentSiteId()]
                );

                // Log restoration details
                $this->db->execute(
                    "INSERT INTO restoration_log
                     (version_id, restored_by, ip_address, user_agent,
                      reason, changes, status, content_id, site_id)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [
                        $versionId,
                        $userId,
                        $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
                        $_SERVER['HTTP_USER_AGENT'] ?? '',
                        $reason,
                        json_encode([
                            'old' => $version['current_content'],
                            'new' => $version['content_data']
                        ]),
                        'completed',
                        $version['content_id'],
                        $this->getCurrentSiteId()
                    ]
                );

                $this->db->commit();
                return true;
            } catch (Exception $e) {
                $this->db->rollback();
                return false;
            }
        }
        return false;
    }

    public function getVersionDiff($versionId1, $versionId2) {
        $this->requireTenant();
        $version1 = $this->db->querySingleValue(
            "SELECT content_data FROM content_versions WHERE id = ? AND site_id = ?",
            [$versionId1, $this->getCurrentSiteId()]
        );
        $version2 = $this->db->querySingleValue(
            "SELECT content_data FROM content_versions WHERE id = ? AND site_id = ?",
            [$versionId2, $this->getCurrentSiteId()]
        );

        return [
            'diff' => $this->calculateDiff($version1, $version2),
            'version1' => $version1,
            'version2' => $version2
        ];
    }

    private function calculateDiff($old, $new) {
        // Simple diff implementation for text content
        $oldLines = explode("\n", $old);
        $newLines = explode("\n", $new);
        
        $diff = [];
        foreach ($newLines as $i => $line) {
            if (!isset($oldLines[$i])) {
                $diff[] = ['type' => 'added', 'line' => $line];
            } elseif ($oldLines[$i] !== $line) {
                $diff[] = ['type' => 'modified', 'old' => $oldLines[$i], 'new' => $line];
            }
        }
        
        return $diff;
    }
}