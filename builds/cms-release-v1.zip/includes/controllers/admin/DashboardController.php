<?php
/**
 * Admin Dashboard Controller
 * Handles admin dashboard functionality
 */
require_once __DIR__ . '/../../auth/AuthenticationMiddleware.php';
require_once __DIR__ . '/../Controller.php';

class DashboardController extends Controller
{
    protected $authMiddleware;

    public function __construct()
    {
        $this->authMiddleware = new AuthenticationMiddleware();
        
        if (!$this->authMiddleware->isAdmin()) {
            header('HTTP/1.0 403 Forbidden');
            exit('Access denied');
        }
    }

    /**
     * Show admin dashboard
     */
    public function index()
    {
        $data = [
            'pageTitle' => 'Admin Dashboard',
            'content' => $this->getDashboardStats()
        ];
        
        require_once __DIR__ . '/../../views/templates/admin/dashboard.php';
    }

    /**
     * Get dashboard statistics
     */
    protected function getDashboardStats()
    {
        return [
            'users' => $this->getUserCount(),
            'content' => $this->getContentCount(),
            'plugins' => $this->getPluginCount()
        ];
    }

    // Additional protected methods for stats would go here
}