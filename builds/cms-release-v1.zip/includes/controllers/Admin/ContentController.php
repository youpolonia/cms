<?php
declare(strict_types=1);

namespace Includes\Controllers\Admin;

use Includes\Controllers\Controller;
use Includes\Models\ContentModel;
use Includes\Routing\Response;

class ContentController extends Controller
{
    protected ContentModel $contentModel;

    public function __construct()
    {
        $this->contentModel = new ContentModel();
    }

    public function index(): void
    {
        $contents = $this->contentModel->getAll();
        require_once __DIR__ . '/../../../views/templates/admin/content/index.php';
    }

    public function create(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $this->sanitizeInput($_POST);
            $this->contentModel->create($data);
            Response::redirect('/admin/content');
        }
        
        require_once __DIR__ . '/../../../views/templates/admin/content/create.php';
    }

    public function edit(int $id): void
    {
        $content = $this->contentModel->getById($id);
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $this->sanitizeInput($_POST);
            $this->contentModel->update($id, $data);
            Response::redirect('/admin/content');
        }
        
        require_once __DIR__ . '/../../../views/templates/admin/content/edit.php';
    }

    public function delete(int $id): void
    {
        $this->contentModel->delete($id);
        Response::redirect('/admin/content');
    }

    private function sanitizeInput(array $input): array
    {
        // Basic input sanitization
        return array_map(function($value) {
            return htmlspecialchars(strip_tags(trim($value)), ENT_QUOTES, 'UTF-8');
        }, $input);
    }
}