<?php
declare(strict_types=1);

namespace Includes\Controllers\Admin;

use Includes\Controllers\Controller;
use Includes\Auth\AuthService;
use Includes\Routing\Response;

class UserController extends Controller
{
    protected AuthService $authService;

    public function __construct()
    {
        $this->authService = new AuthService();
    }

    public function index(): void
    {
        $users = $this->authService->getAllUsers();
        require_once __DIR__ . '/../../../views/templates/admin/users/index.php';
    }

    public function create(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $this->sanitizeInput($_POST);
            $this->authService->register($data);
            Response::redirect('/admin/users');
        }
        
        require_once __DIR__ . '/../../../views/templates/admin/users/create.php';
    }

    public function edit(int $id): void
    {
        $user = $this->authService->getUserById($id);
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $this->sanitizeInput($_POST);
            $this->authService->updateUser($id, $data);
            Response::redirect('/admin/users');
        }
        
        require_once __DIR__ . '/../../../views/templates/admin/users/edit.php';
    }

    public function delete(int $id): void
    {
        $this->authService->deleteUser($id);
        Response::redirect('/admin/users');
    }

    private function sanitizeInput(array $input): array
    {
        return array_map(function($value) {
            return htmlspecialchars(strip_tags(trim($value)), ENT_QUOTES, 'UTF-8');
        }, $input);
    }
}