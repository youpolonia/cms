<?php
namespace Includes\Controllers\Admin;

use Includes\Controllers\AdminController;
use Includes\Core\Response;

class DashboardController extends AdminController
{
    public function index()
    {
        return $this->adminView('dashboard', [
            'title' => 'Admin Dashboard',
            'stats' => $this->getDashboardStats()
        ]);
    }

    protected function getDashboardStats()
    {
        return [
            'totalPages' => 0, // Will be populated later
            'totalUsers' => 0,
            'recentActivity' => []
        ];
    }
}