<?php
/**
 * Company Controller
 * Handles company-related operations
 */
class CompanyController
{
    /**
     * Show company profile
     *
     * @param string $slug Company slug
     */
    public function show($slug)
    {
        // Get company data from database
        $company = $this->getCompanyBySlug($slug);
        
        if (!$company) {
            // Return 404 if company not found
            http_response_code(404);
            include 'templates/404.php';
            return;
        }

        // Render company profile template
        include 'templates/company_profile.php';
    }

    /**
     * Get company data by slug
     *
     * @param string $slug Company slug
     * @return array|null Company data or null if not found
     */
    private function getCompanyBySlug($slug)
    {
        $db = DatabaseConnection::getInstance();
        $stmt = $db->prepare("
            SELECT
                c.id,
                c.name,
                c.slug,
                c.description,
                c.website,
                m.path AS logo
            FROM companies c
            LEFT JOIN media m ON c.logo_id = m.id
            WHERE c.slug = :slug
            AND c.status = 'active'
            LIMIT 1
        ");
        
        $stmt->execute([':slug' => $slug]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($company) {
            // Format data for template
            $company['logo'] = $company['logo'] ? '/uploads/' . $company['logo'] : null;
        }

        return $company ?: null;
    }
}