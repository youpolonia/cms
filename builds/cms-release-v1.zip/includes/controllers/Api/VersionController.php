<?php
require_once __DIR__.'/../../../DiffRenderer.php';
require_once __DIR__.'/../../../models/VersionModel.php';
require_once __DIR__.'/../../../models/VersionMetadata.php';

class VersionController {
    private $diffRenderer;
    private $versionModel;
    private $versionMetadata;

    public function __construct() {
        $this->diffRenderer = new DiffRenderer();
        $this->versionModel = new VersionModel();
        $this->versionMetadata = new VersionMetadata();
    }

    /**
     * Compare a version against current content
     */
    public function diffAgainstCurrent($versionId) {
        try {
            $version = $this->versionModel->getById($versionId);
            $current = $this->versionModel->getCurrentContent($version['content_id']);
            $metadata = $this->versionMetadata->getByVersionId($versionId);
            
            $version['metadata'] = $metadata;
            $diff = $this->diffRenderer->compareTexts($version['content'], $current['content']);
            
            return array(
                'status' => 'success',
                'data' => array(
                    'diff' => $diff,
                    'version' => $version,
                    'current' => $current
                )
            );
        } catch (Exception $e) {
            return array(
                'status' => 'error',
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * Compare two versions
     */
    public function diffBetweenVersions($versionId1, $versionId2) {
        try {
            $version1 = $this->versionModel->getById($versionId1);
            $version2 = $this->versionModel->getById($versionId2);
            $metadata1 = $this->versionMetadata->getByVersionId($versionId1);
            $metadata2 = $this->versionMetadata->getByVersionId($versionId2);
            
            $version1['metadata'] = $metadata1;
            $version2['metadata'] = $metadata2;
            
            if ($version1['content_id'] !== $version2['content_id']) {
                throw new Exception('Versions must belong to the same content item');
            }
            
            $diff = $this->diffRenderer->compareTexts($version1['content'], $version2['content']);
            
            return array(
                'status' => 'success',
                'data' => array(
                    'diff' => $diff,
                    'version1' => $version1,
                    'version2' => $version2
                )
            );
        } catch (Exception $e) {
            return array(
                'status' => 'error',
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * Update version metadata
     * @param int $versionId Version ID to update
     * @param int $userId User ID making changes
     * @param array $metadata Key-value pairs of metadata
     * @return array Operation result
     */
    public function updateMetadata($versionId, $userId, $metadata) {
        try {
            // Validate required fields
            if (empty($versionId) || empty($userId)) {
                throw new Exception('Version ID and User ID are required');
            }

            // Get existing metadata
            $existing = $this->versionMetadata->getByVersionId($versionId);
            
            if ($existing) {
                // Update existing metadata
                $result = $this->versionMetadata->update($versionId, $metadata);
                
                // Log changes
                foreach ($metadata as $field => $value) {
                    if (isset($existing[$field])) {
                        $this->versionMetadata->logChange(
                            $versionId,
                            $userId,
                            $field,
                            $existing[$field],
                            $value
                        );
                    }
                }
            } else {
                // Create new metadata
                $result = $this->versionMetadata->create(array_merge(
                    ['version_id' => $versionId, 'user_id' => $userId],
                    $metadata
                ));
            }
            
            return [
                'status' => 'success',
                'data' => $result
            ];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }
}