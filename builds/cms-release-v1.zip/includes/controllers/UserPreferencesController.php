<?php

class UserPreferencesController {
    private $model;

    public function __construct() {
        require_once __DIR__.'/../models/UserPreferencesModel.php';
        $this->model = new UserPreferencesModel();
    }

    public function showPreferences() {
        // Get current user ID from session
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            header('Location: /login');
            exit;
        }

        // Get all preferences for the user
        $preferences = $this->model->getAllPreferences($userId);

        // Render the view
        require_once __DIR__.'/../../templates/user/preferences.php';
    }

    public function savePreferences() {
        header('Content-Type: application/json');
        
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            echo json_encode(['success' => false, 'error' => 'Not authenticated']);
            return;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input || !isset($input['key']) || !isset($input['value'])) {
            echo json_encode(['success' => false, 'error' => 'Invalid input']);
            return;
        }

        $success = $this->model->setPreference($userId, $input['key'], $input['value']);
        echo json_encode(['success' => $success]);
    }
}