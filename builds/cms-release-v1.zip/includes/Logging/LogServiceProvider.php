<?php

namespace CMS\Logging;

class LogServiceProvider
{
    public static function register(): void
    {
        $config = require __DIR__ . '/../../config/logging.php';
        
        // Set default log path from config
        if (isset($config['default_path'])) {
            Logger::setLogPath($config['default_path']);
        }

        // Set default channel from config
        if (isset($config['default'])) {
            Logger::setDefaultChannel($config['default']);
        }
    }

    public static function getLogger($channel = null)
    {
        return new Logger($channel);
    }
}