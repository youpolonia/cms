<?php
declare(strict_types=1);

require_once __DIR__ . '/Config.php';

class Database {
    private static ?Database $instance = null;
    private PDO $connection;

    private string $host;
    private string $dbName;
    private string $userName;
    private string $password;
    private string $charset;

    private function __construct() {
        $config = require __DIR__ . '/../config/database.php';
        $connection = $config['connections'][$config['default_connection']];
        
        $this->host = $connection['host'];
        $this->dbName = $connection['database'];
        $this->userName = $connection['username'];
        $this->password = $connection['password'];
        $this->charset = $connection['charset'];

        $dsn = "mysql:host={$this->host};dbname={$this->dbName};charset={$this->charset}";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            // SSL options for Neon DB (or other cloud DBs) should be configurable
            // For local development, these might not be needed or might differ.
            // PDO::MYSQL_ATTR_SSL_CA => Config::get('DB_SSL_CA'),
            // PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT => Config::get('DB_SSL_VERIFY', true),
        ];

        try {
            $this->connection = new PDO($dsn, $this->userName, $this->password, $options);
        } catch (\PDOException $e) {
            // Log error securely, don't expose details to public
            error_log("Database Connection Error: " . $e->getMessage());
            // For a user-facing scenario, throw a generic error or handle gracefully
            throw new \PDOException("Could not connect to the database. Please try again later.", (int)$e->getCode());
        }
    }

    public static function getInstance(): Database {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function getConnection(): PDO {
        return $this->connection;
    }

    // Prevent cloning and unserialization
    private function __clone() {}
    public function __wakeup() {
        throw new \Exception("Cannot unserialize a singleton.");
    }
}