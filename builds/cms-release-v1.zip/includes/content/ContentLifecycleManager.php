<?php
/**
 * Content Lifecycle Manager
 * Handles content status transitions and automated updates
 */
class ContentLifecycleManager {
    // Content status constants
    const STATUS_DRAFT = 'draft';
    const STATUS_SCHEDULED = 'scheduled';
    const STATUS_PUBLISHED = 'published';
    const STATUS_ARCHIVED = 'archived';
    const STATUS_EXPIRED = 'expired';

    // Valid status transitions
    private static $validTransitions = [
        self::STATUS_DRAFT => [self::STATUS_SCHEDULED],
        self::STATUS_SCHEDULED => [self::STATUS_PUBLISHED, self::STATUS_DRAFT],
        self::STATUS_PUBLISHED => [self::STATUS_ARCHIVED, self::STATUS_EXPIRED],
    ];

    /**
     * Validate if a status transition is allowed
     */
    public static function validateTransition(string $currentStatus, string $newStatus): bool {
        return in_array($newStatus, self::$validTransitions[$currentStatus] ?? []);
    }

    /**
     * Update content status based on publish/expiry dates
     */
    public static function updateStatusAutomatically(array &$content): void {
        $now = time();
        $publishDate = strtotime($content['publish_date'] ?? '');
        $expiryDate = strtotime($content['expiry_date'] ?? '');

        if ($content['status'] === self::STATUS_SCHEDULED && $publishDate !== false && $publishDate <= $now) {
            $content['status'] = self::STATUS_PUBLISHED;
        } elseif ($content['status'] === self::STATUS_PUBLISHED && $expiryDate !== false && $expiryDate && $expiryDate <= $now) {
            $content['status'] = self::STATUS_EXPIRED;
        }
    }

    /**
     * Process batch content updates
     */
    public static function processBatch(array $contentItems): array {
        $results = [
            'success' => 0,
            'failed' => 0,
            'errors' => []
        ];

        foreach ($contentItems as $id => $content) {
            try {
                self::updateStatusAutomatically($content);
                $results['success']++;
            } catch (\Exception $e) {
                $results['failed']++;
                $results['errors'][$id] = $e->getMessage();
            }
        }

        return $results;
    }

    /**
     * Get all valid status transitions
     */
    public static function getAllTransitions(): array {
        return self::$validTransitions;
    }
}