<?php

require_once __DIR__ . '/WorkflowManager.php';
require_once __DIR__ . '/Triggers/ContentCreateTrigger.php';
require_once __DIR__ . '/Triggers/ContentUpdateTrigger.php';
require_once __DIR__ . '/Triggers/ContentDeleteTrigger.php';
require_once __DIR__ . '/Triggers/StatusChangeTrigger.php';
require_once __DIR__ . '/Triggers/SEOModificationTrigger.php';

// Register all workflow triggers
WorkflowManager::registerTrigger('content_create', new ContentCreateTrigger());
WorkflowManager::registerTrigger('content_update', new ContentUpdateTrigger());
WorkflowManager::registerTrigger('content_delete', new ContentDeleteTrigger());
WorkflowManager::registerTrigger('status_change', new StatusChangeTrigger());
WorkflowManager::registerTrigger('seo_modification', new SEOModificationTrigger());