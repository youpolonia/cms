<?php

class WorkflowManager {
    private static array $triggers = [];
    private static array $firedTriggers = [];

    public static function trigger(string $eventType, array $payload): void {
        if (!isset(self::$triggers[$eventType])) {
            return;
        }

        // Register shutdown function for non-blocking execution
        register_shutdown_function(function() use ($eventType, $payload) {
            foreach (self::$triggers[$eventType] as $trigger) {
                $trigger->execute($payload);
                self::$firedTriggers[] = [
                    'event' => $eventType,
                    'trigger' => get_class($trigger),
                    'timestamp' => time()
                ];
            }
        });
    }

    public static function registerTrigger(string $eventType, WorkflowTrigger $trigger): void {
        if (!isset(self::$triggers[$eventType])) {
            self::$triggers[$eventType] = [];
        }
        self::$triggers[$eventType][] = $trigger;
    }

    public static function getFiredTriggers(): array {
        return self::$firedTriggers;
    }
}

interface WorkflowTrigger {
    public function execute(array $payload): void;
}