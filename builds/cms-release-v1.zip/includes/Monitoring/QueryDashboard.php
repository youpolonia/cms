<?php
/**
 * Tenant-Aware Query Performance Dashboard
 * Integrates with existing OpenTelemetry and Redis metrics
 */
class QueryDashboard {
    const SLOW_QUERY_THRESHOLD = 500; // ms
    const WARNING_THRESHOLD = 300; // ms
    
    private $redis;
    private $tenantId;
    
    public function __construct($tenantId) {
        $this->tenantId = $tenantId;
        $this->redis = $this->connectRedis();
    }
    
    private function connectRedis() {
        require_once __DIR__ . '/../../config/redis.php';
        return RedisManager::getClient();
    }
    
    /**
     * Get query metrics for current tenant
     */
    public function getQueryMetrics() {
        $metrics = [];
        
        // Get slow queries from Redis
        $slowQueries = $this->redis->hGetAll("tenant:{$this->tenantId}:slow_queries");
        
        // Get performance stats from OpenTelemetry
        $traceData = $this->getTraceData();
        
        return [
            'slow_queries' => $this->formatSlowQueries($slowQueries),
            'performance_stats' => $this->analyzeTraceData($traceData),
            'thresholds' => [
                'slow' => self::SLOW_QUERY_THRESHOLD,
                'warning' => self::WARNING_THRESHOLD
            ]
        ];
    }
    
    private function formatSlowQueries($queries) {
        $formatted = [];
        foreach ($queries as $query => $time) {
            $formatted[] = [
                'query' => $query,
                'execution_time' => $time,
                'is_critical' => ($time > self::SLOW_QUERY_THRESHOLD)
            ];
        }
        return $formatted;
    }
    
    private function getTraceData() {
        // Connect to OpenTelemetry collector
        require_once __DIR__ . '/../../includes/Core/Tracing.php';
        return Tracing::getTenantTraces($this->tenantId);
    }
    
    private function analyzeTraceData($traces) {
        $stats = [
            'total_queries' => 0,
            'avg_time' => 0,
            'max_time' => 0,
            'slow_count' => 0
        ];
        
        if (empty($traces)) return $stats;
        
        $totalTime = 0;
        foreach ($traces as $trace) {
            $stats['total_queries']++;
            $totalTime += $trace['duration'];
            
            if ($trace['duration'] > $stats['max_time']) {
                $stats['max_time'] = $trace['duration'];
            }
            
            if ($trace['duration'] > self::WARNING_THRESHOLD) {
                $stats['slow_count']++;
            }
        }
        
        $stats['avg_time'] = $totalTime / $stats['total_queries'];
        return $stats;
    }
    
    /**
     * Render dashboard HTML
     */
    public function renderDashboard() {
        $metrics = $this->getQueryMetrics();
        ob_start();
        ?>
        <div class="query-dashboard">
            <h2>Query Performance for Tenant <?= htmlspecialchars($this->tenantId) ?></h2>
            
            <div class="summary-stats">
                <div class="stat-card">
                    <h3>Total Queries</h3>
                    <p><?= $metrics['performance_stats']['total_queries'] ?></p>
                </div>
                <div class="stat-card">
                    <h3>Avg Time (ms)</h3>
                    <p><?= round($metrics['performance_stats']['avg_time'], 2) ?></p>
                </div>
                <div class="stat-card warning">
                    <h3>Slow Queries</h3>
                    <p><?= $metrics['performance_stats']['slow_count'] ?></p>
                </div>
            </div>
            
            <h3>Slow Query Details</h3>
            <table class="slow-queries">
                <thead>
                    <tr>
                        <th>Query</th>
                        <th>Execution Time (ms)</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($metrics['slow_queries'] as $query): ?>
                    <tr class="<?= $query['is_critical'] ? 'critical' : 'warning' ?>">
                        <td><code><?= htmlspecialchars($query['query']) ?></code></td>
                        <td><?= $query['execution_time'] ?></td>
                        <td><?= $query['is_critical'] ? 'CRITICAL' : 'WARNING' ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
        return ob_get_clean();
    }
}