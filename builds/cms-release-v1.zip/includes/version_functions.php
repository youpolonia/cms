<?php
declare(strict_types=1);

class VersionFunctions {
    public static function getAllVersions(): array {
        global $db;
        
        $query = "SELECT v.id, v.version_number, v.created_at, 
                 u.username AS author, v.comment
                 FROM versions v
                 JOIN users u ON v.user_id = u.id
                 ORDER BY v.created_at DESC";
        $result = $db->query($query);
        
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public static function createVersion(): int {
        global $db;
        
        $userId = $_SESSION['user_id'];
        $comment = $_POST['comment'] ?? 'Automatic version';
        
        $db->query("INSERT INTO versions 
                   (user_id, version_number, comment) 
                   VALUES ($userId, UNIX_TIMESTAMP(), '$comment')");
        
        return $db->insert_id;
    }

    public static function restoreVersion(int $versionId): void {
        global $db;
        
        // Get version content
        $version = $db->query("SELECT content FROM versions WHERE id = $versionId")->fetch_assoc();
        if (!$version) {
            throw new RuntimeException("Version not found");
        }
        
        // Restore to current content
        $db->query("UPDATE current_content SET content = '{$version['content']}'");
    }

    public static function getVersionDiff(int $version1, int $version2): array {
        global $db;
        
        $v1 = $db->query("SELECT content FROM versions WHERE id = $version1")->fetch_assoc();
        $v2 = $db->query("SELECT content FROM versions WHERE id = $version2")->fetch_assoc();
        
        if (!$v1 || !$v2) {
            throw new RuntimeException("One or both versions not found");
        }
        
        return [
            'left' => htmlspecialchars($v1['content']),
            'right' => htmlspecialchars($v2['content'])
        ];
    }
}