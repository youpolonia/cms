<?php
/**
 * Enhanced Router Implementation
 * Handles request routing with dynamic segments and improved error handling
 */
class Router {
    private $routes = [];
    private $path;
    private $method;

    public function __construct() {
        $this->path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $this->method = $_SERVER['REQUEST_METHOD'];
    }

    public function addRoute($method, $path, $handler) {
        $this->routes[] = [
            'method' => strtoupper($method),
            'path' => $path,
            'pattern' => $this->createPattern($path),
            'handler' => $handler
        ];
        return $this;
    }

    private function createPattern($path) {
        $pattern = preg_replace('/\{(\w+)\}/', '(?P<$1>[^\/]+)', $path);
        return '#^' . $pattern . '$#';
    }

    public function addGatewayRoutes() {
        $gateway = new GatewayController();
        $this->addRoute('GET', '/gateway', [$gateway, 'index']);
        $this->addRoute('POST', '/gateway', [$gateway, 'process']);
        $this->addRoute('GET', '/gateway/{id}', [$gateway, 'show']);
        $this->addRoute('PUT', '/gateway/{id}', [$gateway, 'update']);
        $this->addRoute('DELETE', '/gateway/{id}', [$gateway, 'delete']);
        return $this;
    }

    public function dispatch() {
        try {
            foreach ($this->routes as $route) {
                if ($this->matchRoute($route)) {
                    return $this->callHandler($route['handler'], $route['params'] ?? []);
                }
            }
            throw new Exception('Route not found', 404);
        } catch (Exception $e) {
            http_response_code($e->getCode() ?: 500);
            error_log($e->getMessage());
            return $this->handleError($e);
        }
    }

    private function matchRoute($route) {
        if ($route['method'] !== $this->method) {
            return false;
        }

        if (preg_match($route['pattern'], $this->path, $matches)) {
            $route['params'] = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
            return true;
        }
        return false;
    }

    private function callHandler($handler, $params = []) {
        if (is_callable($handler)) {
            return call_user_func_array($handler, $params);
        } elseif (is_array($handler) && count($handler) === 2) {
            list($class, $method) = $handler;
            if (class_exists($class) && method_exists($class, $method)) {
                $instance = new $class();
                return call_user_func_array([$instance, $method], $params);
            }
        }
        throw new RuntimeException("Invalid route handler", 500);
    }

    private function handleError(Exception $e) {
        if (php_sapi_name() === 'cli-server') {
            return "Error: " . $e->getMessage();
        }
        return json_encode(['error' => $e->getMessage(), 'code' => $e->getCode()]);
    }
}