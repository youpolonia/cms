<?php
/**
 * Enhanced File Cache - Phase 4 Performance Optimization
 * 
 * Features:
 * - Cache tagging for bulk invalidation
 * - Gzip compression for large values
 * - Namespaced cache directories
 * - Automatic cleanup of expired items
 */
class EnhancedFileCache {
    protected $baseDir;
    protected $defaultTtl;
    protected $compressThreshold = 10240; // 10KB
    
    public function __construct(string $namespace = 'default', int $defaultTtl = 3600) {
        $cacheRoot = realpath(__DIR__ . '/../../storage/cache');
        $this->baseDir = $cacheRoot . '/' . $namespace . '/';
        $this->defaultTtl = $defaultTtl;
        
        if (!file_exists($this->baseDir)) {
            error_log("Attempting to create cache directory: {$this->baseDir}");
            error_log("Cache root exists: " . (file_exists($cacheRoot) ? 'Yes' : 'No'));
            error_log("Cache root permissions: " . substr(sprintf('%o', fileperms($cacheRoot)), -4));
            
            if (!mkdir($this->baseDir, 0777, true)) {
                throw new \RuntimeException(sprintf(
                    "Failed to create cache directory: %s\nRoot: %s\nRoot exists: %s\nRoot perms: %s",
                    $this->baseDir,
                    $cacheRoot,
                    file_exists($cacheRoot) ? 'Yes' : 'No',
                    substr(sprintf('%o', fileperms($cacheRoot)), -4)
                ));
            }
        }
    }

    public function get(string $key, $default = null) {
        $file = $this->getFilePath($key);
        
        if (!file_exists($file)) {
            return $default;
        }
        
        $data = @file_get_contents($file);
        if ($data === false) {
            return $default;
        }
        
        $data = $this->maybeDecompress($data);
        $data = @unserialize($data);
        
        if ($data === false || !$this->isValid($data)) {
            @unlink($file);
            return $default;
        }
        
        return $data['value'];
    }

    public function set(string $key, $value, $ttl = null): bool {
        $ttl = $ttl ?? $this->defaultTtl;
        $file = $this->getFilePath($key);
        
        $data = [
            'value' => $value,
            'expires' => time() + $ttl,
            'created' => time()
        ];
        
        $serialized = serialize($data);
        $serialized = $this->maybeCompress($serialized);
        
        return file_put_contents($file, $serialized, LOCK_EX) !== false;
    }

    public function delete(string $key): bool {
        $file = $this->getFilePath($key);
        return file_exists($file) ? @unlink($file) : true;
    }

    public function clear(): bool {
        return $this->clearDirectory($this->baseDir);
    }

    public function getMultiple(array $keys, $default = null): array {
        $results = [];
        foreach ($keys as $key) {
            $results[$key] = $this->get($key, $default);
        }
        return $results;
    }

    public function setMultiple(array $values, $ttl = null): bool {
        $success = true;
        foreach ($values as $key => $value) {
            if (!$this->set($key, $value, $ttl)) {
                $success = false;
            }
        }
        return $success;
    }

    public function deleteMultiple(array $keys): bool {
        $success = true;
        foreach ($keys as $key) {
            if (!$this->delete($key)) {
                $success = false;
            }
        }
        return $success;
    }

    public function has(string $key): bool {
        return $this->get($key) !== null;
    }

    public function tag(string $name, array $keys): bool {
        $tagFile = $this->baseDir . 'tags/' . $name . '.tag';
        $dir = dirname($tagFile);
        
        if (!file_exists($dir)) {
            mkdir($dir, 0755, true);
        }
        
        return file_put_contents($tagFile, serialize($keys), LOCK_EX) !== false;
    }

    public function invalidateTag(string $name): bool {
        $tagFile = $this->baseDir . 'tags/' . $name . '.tag';
        
        if (!file_exists($tagFile)) {
            return false;
        }
        
        $keys = @unserialize(file_get_contents($tagFile));
        if (!is_array($keys)) {
            return false;
        }
        
        return $this->deleteMultiple($keys);
    }

    public function cleanup(): int {
        $count = 0;
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($this->baseDir),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        
        foreach ($files as $file) {
            if ($file->isDir()) {
                continue;
            }
            
            if (strpos($file->getPathname(), '/tags/') !== false) {
                continue; // Skip tag files
            }
            
            $data = @file_get_contents($file->getPathname());
            if ($data === false) {
                continue;
            }
            
            $data = $this->maybeDecompress($data);
            $data = @unserialize($data);
            
            if ($data === false || !$this->isValid($data)) {
                @unlink($file->getPathname());
                $count++;
            }
        }
        
        return $count;
    }

    protected function getFilePath(string $key): string {
        $safeKey = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $key);
        $dir = $this->baseDir . substr($safeKey, 0, 2) . '/';
        
        if (!file_exists($dir)) {
            if (!mkdir($dir, 0777, true) && !is_dir($dir)) {
                throw new \RuntimeException("Failed to create cache subdirectory: " . $dir);
            }
        }
        
        return $dir . $safeKey . '.cache';
    }

    protected function isValid(array $data): bool {
        return isset($data['expires']) && $data['expires'] > time();
    }

    protected function maybeCompress(string $data): string {
        if (strlen($data) > $this->compressThreshold && function_exists('gzencode')) {
            return gzencode($data);
        }
        return $data;
    }

    protected function maybeDecompress(string $data): string {
        if (function_exists('gzdecode') && substr($data, 0, 2) === "\x1f\x8b") {
            return @gzdecode($data) ?: $data;
        }
        return $data;
    }

    protected function clearDirectory(string $dir): bool {
        $success = true;
        $files = array_diff(scandir($dir), ['.', '..']);
        
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            
            if (is_dir($path)) {
                $success = $this->clearDirectory($path) && $success;
                $success = @rmdir($path) && $success;
            } else {
                $success = @unlink($path) && $success;
            }
        }
        
        return $success;
    }
}