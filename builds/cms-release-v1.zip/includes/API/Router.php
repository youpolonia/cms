<?php
/**
 * API Router with Caching Support
 */

declare(strict_types=1);

namespace CMS\API;

use CMS\ApiCache;
require_once __DIR__ . '/../../debug_router_fix.php';

class Router
{
    private array $routes = [
        'GET' => [],
        'POST' => [],
        'PUT' => [],
        'PATCH' => [],
        'DELETE' => []
    ];

    private ApiCache $cache;

    public function __construct(ApiCache $cache = null)
    {
        $this->cache = $cache ?? new ApiCache(
            $_SERVER['HTTP_X_TENANT_ID'] ?? 'default',
            new \FileCacheStorage()
        );
        $this->loadRoutes();
    }

    private function loadRoutes(): void
    {
        // Load route definitions from api/v1/routes.php
        if (file_exists(__DIR__ . '/../../../api/v1/routes.php')) {
            $routes = require __DIR__ . '/../../../api/v1/routes.php';
            $routes = RouterDebugger::checkRouterCompatibility($routes);
            $this->routes = array_merge_recursive($this->routes, $routes);
        }
    }

    public function route(): void
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $path = str_replace('/api/v1', '', $path);

        // Generate cache key for GET requests
        $cacheKey = null;
        if ($method === 'GET') {
            $cacheKey = $this->generateCacheKey($path, $_GET);
            if ($cached = $this->cache->get($cacheKey)) {
                (new Response())->setHeader('X-Cache', 'HIT')->success($cached);
                return;
            }
        }

        foreach ($this->routes[$method] as $route => $handler) {
            $pattern = '#^' . preg_replace('/\{[^}]+\}/', '([^/]+)', $route) . '$#';
            
            if (preg_match($pattern, $path, $matches)) {
                array_shift($matches);
                $this->callHandler($handler, $matches, $cacheKey);
                return;
            }
        }

        throw new \RuntimeException('Route not found', 404);
    }

    private function generateCacheKey(string $path, array $params): string
    {
        ksort($params);
        return md5($path . '?' . http_build_query($params));
    }

    private function callHandler($handler, array $params, ?string $cacheKey = null): void
    {
        ob_start();
        
        try {
            if (is_callable($handler)) {
                call_user_func_array($handler, $params);
            } elseif (is_string($handler) && strpos($handler, '@') !== false) {
                [$controller, $method] = explode('@', $handler);
                $controller = "CMS\\Controllers\\" . $controller;
                
                if (class_exists($controller) && method_exists($controller, $method)) {
                    $instance = new $controller();
                    call_user_func_array([$instance, $method], $params);
                } else {
                    throw new \RuntimeException('Invalid route handler', 500);
                }
            } else {
                throw new \RuntimeException('Invalid route handler', 500);
            }

            $output = ob_get_clean();
            $response = json_decode($output, true) ?? [];

            // Cache successful GET responses
            if ($cacheKey && $_SERVER['REQUEST_METHOD'] === 'GET' && http_response_code() === 200) {
                $this->cache->set($cacheKey, $response, 300); // 5 minute TTL
            }
        } catch (\Exception $e) {
            ob_end_clean();
            throw $e;
        }
    }
}