<?php

namespace Includes\API;

use Includes\Core\Controller;
use Includes\Core\Request;
use Includes\Core\Response;
use Includes\Core\Database;
use JsonException;

class VersionController extends Controller
{
    public function compare(Request $request)
    {
        $version1 = $request->input('version1');
        $version2 = $request->input('version2');
        $contentType = $request->input('content_type', 'json');

        if (empty($version1) || empty($version2)) {
            return Response::json(['error' => 'Both versions are required'], 400);
        }

        $version1Path = $this->getVersionPath($version1);
        $version2Path = $this->getVersionPath($version2);

        if (!file_exists($version1Path) || !file_exists($version2Path)) {
            return Response::json(['error' => 'One or both versions not found'], 404);
        }

        $version1Content = file_get_contents($version1Path);
        $version2Content = file_get_contents($version2Path);

        if ($contentType === 'html') {
            $comparator = new VersionComparator();
            $diff = $comparator->compare($version1Content, $version2Content);
            
            // Calculate change stats
            $added = substr_count($diff, "\n+ ");
            $removed = substr_count($diff, "\n- ");
            $changed = substr_count($diff, "\n~ ");
            
            $changeStats = [
                'added' => $added,
                'removed' => $removed,
                'changed' => $changed,
                'change_count' => $added + $removed + $changed
            ];

            // Store in version_diffs table
            $this->storeVersionDiff($version1, $version2, $diff, $changeStats);

            return Response::json([
                'version1' => $version1,
                'version2' => $version2,
                'diff' => $diff,
                'change_stats' => $changeStats
            ]);
        } else {
            $version1Data = json_decode($version1Content, true);
            $version2Data = json_decode($version2Content, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                return Response::json(['error' => 'Invalid JSON content in version files'], 500);
            }

            $diff = $this->computeJsonDiff($version1Data, $version2Data);
            return Response::json([
                'version1' => $version1,
                'version2' => $version2,
                'diff' => $diff,
            ]);
        }
    }

    public function listVersions(Request $request)
    {
        $db = Database::getConnection();
        $stmt = $db->query("SELECT id, name, created_at FROM content_versions ORDER BY created_at DESC");
        return Response::json($stmt->fetchAll());
    }

    public function getVersion(Request $request, $versionId)
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("SELECT * FROM content_versions WHERE id = ?");
        $stmt->execute([$versionId]);
        $version = $stmt->fetch();

        if (!$version) {
            return Response::json(['error' => 'Version not found'], 404);
        }

        return Response::json($version);
    }

    public function getComparisonHistory(Request $request)
    {
        $limit = $request->input('limit', 10);
        $db = Database::getConnection();
        $stmt = $db->prepare("
            SELECT v1.name as version1_name, v2.name as version2_name,
                   vd.created_at, vd.change_stats
            FROM version_diffs vd
            JOIN content_versions v1 ON vd.version1_id = v1.id
            JOIN content_versions v2 ON vd.version2_id = v2.id
            ORDER BY vd.created_at DESC
            LIMIT ?
        ");
        $stmt->execute([$limit]);
        return Response::json($stmt->fetchAll());
    }

    private function getVersionPath($versionId)
    {
        $baseDir = __DIR__ . "/../../versions";
        $path = $baseDir . "/{$versionId}";
        $realPath = realpath($path);
        if ($realPath === false || strpos($realPath, $baseDir) !== 0) {
            throw new \Exception("Invalid version ID");
        }
        return $realPath;
    }

    private function storeVersionDiff($version1, $version2, $diff, $changeStats)
    {
        $db = Database::getConnection();
        $stmt = $db->prepare("
            INSERT INTO version_diffs
            (version1_id, version2_id, diff_content, change_stats, created_at)
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $version1,
            $version2,
            $diff,
            json_encode($changeStats)
        ]);
    }

    private function computeJsonDiff($data1, $data2)
    {
        $diff = [];
        $allKeys = array_unique(array_merge(array_keys($data1), array_keys($data2)));

        foreach ($allKeys as $key) {
            if (!array_key_exists($key, $data1)) {
                $diff[] = "+ $key: " . json_encode($data2[$key]);
            } elseif (!array_key_exists($key, $data2)) {
                $diff[] = "- $key: " . json_encode($data1[$key]);
            } else {
                if ($data1[$key] !== $data2[$key]) {
                    $diff[] = "~ $key: " . json_encode($data1[$key]) . " -> " . json_encode($data2[$key]);
                }
            }
        }

        return $diff;
    }
}