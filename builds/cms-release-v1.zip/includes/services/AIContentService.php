<?php

namespace Includes\Services;

require_once CMS_ROOT . '/includes/FileCache.php';

use Includes\Database\DatabaseConnection;
use Includes\Config\ConfigLoader;

/**
 * AIContentService provides AI-powered content generation and improvement
 */
class AIContentService {
    const CACHE_TTL = 3600; // 1 hour
    const RATE_LIMIT = 10; // Requests per minute
    
    /**
     * Generate content suggestions via AI
     *
     * @param string $contentType Type of content to generate
     * @param string $context Context for generation
     * @param array $options Generation options
     * @return array Generated suggestions
     */
    public static function generateSuggestions(string $contentType, string $context, array $options = []): array {
        $cacheKey = self::getCacheKey('suggestions', $contentType, $context, $options);
        
        // Check cache first
        if ($cached = FileCache::get($cacheKey)) {
            return $cached;
        }

        // Apply rate limiting
        if (self::isRateLimited()) {
            return self::getFallbackSuggestions($contentType, $context);
        }

        $config = ConfigLoader::get('ai');
        $apiResponse = self::callAIApi($config['endpoint'], [
            'content_type' => $contentType,
            'context' => $context,
            'options' => $options
        ]);

        // Store in cache
        FileCache::set($cacheKey, $apiResponse['suggestions'], self::CACHE_TTL);

        // Track usage
        self::trackUsage('suggestion_generated', [
            'content_type' => $contentType,
            'characters' => strlen($context)
        ]);

        return $apiResponse['suggestions'];
    }

    /**
     * Improve existing content via AI
     *
     * @param string $content Content to improve
     * @param string $improvementType Type of improvement
     * @return string Improved content
     */
    public static function improveContent(string $content, string $improvementType): string {
        $cacheKey = self::getCacheKey('improvement', $improvementType, md5($content));
        
        if ($cached = FileCache::get($cacheKey)) {
            return $cached;
        }

        if (self::isRateLimited()) {
            return $content; // Return original if rate limited
        }

        $config = ConfigLoader::get('ai');
        $apiResponse = self::callAIApi($config['endpoint'], [
            'action' => 'improve',
            'improvement_type' => $improvementType,
            'content' => $content
        ]);

        FileCache::set($cacheKey, $apiResponse['improved_content'], self::CACHE_TTL);

        self::trackUsage('content_improved', [
            'improvement_type' => $improvementType,
            'characters' => strlen($content)
        ]);

        return $apiResponse['improved_content'];
    }

    /**
     * Call AI API endpoint
     */
    private static function callAIApi(string $endpoint, array $data): array {
        $headers = [
            'Content-Type: application/json',
            'Authorization: Bearer ' . ConfigLoader::get('ai.api_key')
        ];

        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => implode("\r\n", $headers),
                'content' => json_encode($data),
                'timeout' => 30
            ]
        ]);

        $response = file_get_contents($endpoint, false, $context);
        return json_decode($response, true);
    }

    /**
     * Check if rate limit exceeded
     */
    private static function isRateLimited(): bool {
        $lastMinute = date('Y-m-d H:i:00', strtotime('-1 minute'));
        
        $query = "
            SELECT COUNT(*) as count 
            FROM ai_api_usage 
            WHERE created_at >= ?
        ";
        
        $result = DatabaseConnection::fetchOne($query, [$lastMinute]);
        return $result['count'] >= self::RATE_LIMIT;
    }

    /**
     * Track API usage
     */
    private static function trackUsage(string $action, array $data = []): bool {
        $query = "
            INSERT INTO ai_api_usage
            (action, data, created_at)
            VALUES (?, ?, NOW())
        ";
        
        return DatabaseConnection::execute($query, [
            $action,
            json_encode($data)
        ]);
    }

    /**
     * Get fallback suggestions when API unavailable
     */
    private static function getFallbackSuggestions(string $contentType, string $context): array {
        // Basic local fallback logic
        return [
            'Consider expanding on: ' . substr($context, 0, 50) . '...',
            'Review related content for inspiration'
        ];
    }

    /**
     * Generate consistent cache key
     */
    private static function getCacheKey(string $type, ...$parts): string {
        return 'ai_' . $type . '_' . md5(implode('|', $parts));
    }
}