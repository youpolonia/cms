<?php
// TEMPORARY PLACEHOLDER - CMS header file will be implemented here