<?php
declare(strict_types=1);

use Services\PathResolver;

function authenticate_user(): void {
    require_once PathResolver::core('session.php');
    
    if (empty($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit;
    }

    // Regenerate session ID periodically
    if (rand(1, 100) <= 10) { // 10% chance on each request
        session_regenerate_id(true);
    }

    // Set CSRF token if not already set
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}

function logout(): void {
    $_SESSION = [];
    session_destroy();
}

function get_current_user_id(): int {
    return $_SESSION['user_id'] ?? 0;
}