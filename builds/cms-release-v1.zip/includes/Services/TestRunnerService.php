<?php
declare(strict_types=1);

namespace Services;

class TestRunnerService
{
    private array $testResults = [];

    public function runTests(string $testDirectory): array
    {
        $this->testResults = [];
        $testFiles = $this->scanTestDirectory($testDirectory);
        
        foreach ($testFiles as $testFile) {
            $this->runTestFile($testFile);
        }

        return $this->testResults;
    }

    private function scanTestDirectory(string $directory): array
    {
        $files = [];
        if (is_dir($directory)) {
            foreach (scandir($directory) as $file) {
                if (str_ends_with($file, 'Test.php')) {
                    $files[] = $directory . '/' . $file;
                }
            }
        }
        return $files;
    }

    private function runTestFile(string $filePath): void
    {
        require_once $filePath;
        $className = basename($filePath, '.php');
        
        if (class_exists($className)) {
            $testClass = new $className();
            if (method_exists($testClass, 'run')) {
                $this->testResults[$className] = $testClass->run();
            }
        }
    }
}