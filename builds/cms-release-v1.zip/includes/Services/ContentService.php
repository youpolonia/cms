<?php
namespace Includes\Services;

use PDO;

class ContentService {
    private $db;

    public function __construct(PDO $db) {
        $this->db = $db;
    }

    public function getPublishedPosts(int $limit, int $offset): array {
        $stmt = $this->db->prepare("
            SELECT * FROM blog_posts 
            WHERE status = 'published' 
            ORDER BY published_at DESC
            LIMIT :limit OFFSET :offset
        ");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function countPublishedPosts(): int {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM blog_posts 
            WHERE status = 'published'
        ");
        $stmt->execute();
        return (int)$stmt->fetchColumn();
    }
}