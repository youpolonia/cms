<?php
declare(strict_types=1);

namespace Includes\Services;

// Placeholder for a potential WorkflowInstance or WorkflowDefinition model
// For now, we'll manage definitions and instances in memory within this service.

class WorkflowService
{
    private \PDO $pdo;

    public function __construct(\PDO $pdo = null)
    {
        if ($pdo === null) {
            // Ensure DatabaseConnection class is available
            // This path might need adjustment based on your autoloader or file structure
            require_once __DIR__ . '/../Core/DatabaseConnection.php';
            if (!class_exists('\Includes\Core\DatabaseConnection')) {
                throw new \RuntimeException("DatabaseConnection class not found. Cannot initialize WorkflowService.");
            }
            $this->pdo = \Includes\Core\DatabaseConnection::getInstance();
        } else {
            $this->pdo = $pdo;
        }
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->initializeDefaultWorkflows();
    }

    private function initializeDefaultWorkflows(): void
    {
        $defaultWorkflows = [
            [
                'id' => 'content_approval_v1',
                'name' => 'Content Approval Workflow',
                'description' => 'A simple workflow for content creation and approval.',
                'initial_state' => 'draft',
                'states' => [
                    'draft' => ['description' => 'Content is being written.'],
                    'review' => ['description' => 'Content is under review.'],
                    'approved' => ['description' => 'Content is approved and ready for publishing.'],
                    'rejected' => ['description' => 'Content has been rejected.'],
                    'published' => ['description' => 'Content is live.'],
                    'archived' => ['description' => 'Content is archived.'],
                ],
                'transitions' => [
                    'submit_for_review' => ['from' => 'draft', 'to' => 'review'],
                    'approve' => ['from' => 'review', 'to' => 'approved'],
                    'reject' => ['from' => 'review', 'to' => 'rejected'],
                    'request_changes' => ['from' => 'review', 'to' => 'draft'],
                    'publish' => ['from' => 'approved', 'to' => 'published'],
                    'archive' => ['from' => 'published', 'to' => 'archived'],
                    'rework' => ['from' => 'rejected', 'to' => 'draft'],
                ]
            ],
            [
                'id' => 'user_onboarding_v1',
                'name' => 'User Onboarding',
                'description' => 'Workflow for new user registration and activation.',
                'initial_state' => 'pending_verification',
                'states' => [
                    'pending_verification' => ['description' => 'User registered, email verification pending.'],
                    'active' => ['description' => 'User verified and active.'],
                    'suspended' => ['description' => 'User account suspended.'],
                ],
                'transitions' => [
                    'verify_email' => ['from' => 'pending_verification', 'to' => 'active'],
                    'suspend_account' => ['from' => 'active', 'to' => 'suspended'],
                    'reactivate_account' => ['from' => 'suspended', 'to' => 'active'],
                ]
            ]
        ];

        foreach ($defaultWorkflows as $workflowData) {
            try {
                $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM workflow_definitions WHERE id = :id");
                $stmt->execute([':id' => $workflowData['id']]);
                if ($stmt->fetchColumn() == 0) {
                    $insertStmt = $this->pdo->prepare(
                        "INSERT INTO workflow_definitions (id, name, description, initial_state, states, transitions)
                         VALUES (:id, :name, :description, :initial_state, :states, :transitions)"
                    );
                    $insertStmt->execute([
                        ':id' => $workflowData['id'],
                        ':name' => $workflowData['name'],
                        ':description' => $workflowData['description'],
                        ':initial_state' => $workflowData['initial_state'],
                        ':states' => json_encode($workflowData['states']),
                        ':transitions' => json_encode($workflowData['transitions'])
                    ]);
                }
            } catch (\PDOException $e) {
                // Log error or handle as appropriate for your application
                error_log("Error initializing default workflow {$workflowData['id']}: " . $e->getMessage());
            }
        }
    }

    public function getActiveWorkflows(): array
    {
        try {
            // Assuming 'active' means any definition present in the table.
            // Adjust query if there's an 'is_active' column or similar.
            $stmt = $this->pdo->query("SELECT id, name FROM workflow_definitions");
            $definitions = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            return array_map(function ($def) {
                return ['id' => $def['id'], 'name' => $def['name'], 'status' => 'active_definition'];
            }, $definitions);
        } catch (\PDOException $e) {
            error_log("Error fetching active workflows: " . $e->getMessage());
            return []; // Return empty array on error
        }
    }

    public function getWorkflowById(string $definitionId): ?array
    {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM workflow_definitions WHERE id = :id");
            $stmt->execute([':id' => $definitionId]);
            $definition = $stmt->fetch(\PDO::FETCH_ASSOC);

            if ($definition) {
                // JSON fields need to be decoded
                $definition['states'] = json_decode($definition['states'], true);
                $definition['transitions'] = json_decode($definition['transitions'], true);
                return $definition;
            }
            return null;
        } catch (\PDOException $e) {
            error_log("Error fetching workflow definition {$definitionId}: " . $e->getMessage());
            return null;
        }
    }
    
    // Method to get a specific instance - needed for status, pause, resume, cancel
    private function getWorkflowInstance(string $instanceId): ?array
    {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM workflow_instances WHERE id = :id");
            $stmt->execute([':id' => $instanceId]);
            $instance = $stmt->fetch(\PDO::FETCH_ASSOC);

            if ($instance) {
                // Decode JSON data if necessary, e.g., $instance['data']
                if (isset($instance['data']) && is_string($instance['data'])) {
                    $instance['data'] = json_decode($instance['data'], true);
                }
                // The 'history' was part of the in-memory instance,
                // it will now be fetched separately when needed or handled by transitionWorkflow.
                return $instance;
            }
            return null;
        } catch (\PDOException $e) {
            error_log("Error fetching workflow instance {$instanceId}: " . $e->getMessage());
            return null;
        }
    }


    public function getWorkflowStatus(string $instanceId): ?array
    {
        $instance = $this->getWorkflowInstance($instanceId); // Already fetches from DB
        if ($instance) {
            return [
                'id' => $instanceId,
                'current_state' => $instance['current_state'],
                'status' => $instance['status']
            ];
        }
        return null;
    }

    public function createWorkflow(
        string $name,
        string $description,
        string $initialState,
        array $states,
        array $transitions
    ): array {
        $definitionId = 'wf_def_' . uniqid('', true); // More unique ID

        try {
            $stmt = $this->pdo->prepare(
                "INSERT INTO workflow_definitions (id, name, description, initial_state, states, transitions)
                 VALUES (:id, :name, :description, :initial_state, :states, :transitions)"
            );
            $stmt->execute([
                ':id' => $definitionId,
                ':name' => $name,
                ':description' => $description,
                ':initial_state' => $initialState,
                ':states' => json_encode($states),
                ':transitions' => json_encode($transitions)
            ]);

            return ['definition_id' => $definitionId, 'name' => $name, 'message' => 'Workflow definition created successfully.'];
        } catch (\PDOException $e) {
            error_log("Error creating workflow definition: " . $e->getMessage());
            // It's important to throw an exception or return an error structure
            // that the controller can understand and respond with appropriately.
            // For now, rethrowing to indicate failure.
            throw new \RuntimeException("Failed to create workflow definition: " . $e->getMessage(), 0, $e);
        }
    }
    
    /**
     * Starts a new instance of a defined workflow.
     * @param string $definitionId The ID of the workflow definition.
     * @param string $subjectId An identifier for the item this workflow instance applies to (e.g., content_id, user_id).
     * @param string $subjectType The type of the subject (e.g., 'content', 'user').
     * @return array The created workflow instance data.
     * @throws \InvalidArgumentException If definition not found.
     * @throws \RuntimeException If database operation fails.
     */
    public function startWorkflowInstance(string $definitionId, string $subjectId, string $subjectType): array
    {
        $definition = $this->getWorkflowById($definitionId);
        if (!$definition) {
            throw new \InvalidArgumentException("Workflow definition with ID {$definitionId} not found.");
        }

        $instanceId = 'wf_inst_' . uniqid('', true); // More unique ID

        try {
            $this->pdo->beginTransaction();

            $stmtInstance = $this->pdo->prepare(
                "INSERT INTO workflow_instances (id, definition_id, subject_id, subject_type, current_state, status, data)
                 VALUES (:id, :definition_id, :subject_id, :subject_type, :current_state, :status, :data)"
            );
            
            $instanceData = [
                'id' => $instanceId,
                'definition_id' => $definitionId,
                'subject_id' => $subjectId,
                'subject_type' => $subjectType,
                'current_state' => $definition['initial_state'],
                'status' => 'running',
                'data' => null // Or some initial data if provided
            ];

            $stmtInstance->execute([
                ':id' => $instanceData['id'],
                ':definition_id' => $instanceData['definition_id'],
                ':subject_id' => $instanceData['subject_id'],
                ':subject_type' => $instanceData['subject_type'],
                ':current_state' => $instanceData['current_state'],
                ':status' => $instanceData['status'],
                ':data' => $instanceData['data'] ? json_encode($instanceData['data']) : null
            ]);

            // Add initial history entry
            $stmtHistory = $this->pdo->prepare(
                "INSERT INTO workflow_history (workflow_instance_id, state, transition, context)
                 VALUES (:workflow_instance_id, :state, :transition, :context)"
            );
            $stmtHistory->execute([
                ':workflow_instance_id' => $instanceId,
                ':state' => $definition['initial_state'],
                ':transition' => null, // No transition for initial state
                ':context' => json_encode(['message' => 'Instance started'])
            ]);

            $this->pdo->commit();

            // Return a representation of the instance, similar to how it was before
            // but without the full history array to keep it concise.
            // The full history can be fetched by a dedicated method if needed.
            return $instanceData;

        } catch (\PDOException $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            error_log("Error starting workflow instance: " . $e->getMessage());
            throw new \RuntimeException("Failed to start workflow instance: " . $e->getMessage(), 0, $e);
        }
    }


    public function transitionWorkflow(string $instanceId, string $transitionName, array $context = []): array
    {
        $instance = $this->getWorkflowInstance($instanceId);
        if (!$instance) {
            throw new \InvalidArgumentException("Workflow instance with ID {$instanceId} not found.");
        }
        if ($instance['status'] !== 'running') {
            throw new \InvalidArgumentException("Workflow instance {$instanceId} is not running. Current status: {$instance['status']}.");
        }

        $definition = $this->getWorkflowById($instance['definition_id']);
        if (!$definition) {
            // This case should ideally not happen if data integrity is maintained
            throw new \RuntimeException("Associated workflow definition {$instance['definition_id']} not found for instance {$instanceId}.");
        }

        $currentState = $instance['current_state'];
        $validTransition = null;
        foreach ($definition['transitions'] as $tName => $tDetails) {
            if ($tName === $transitionName && $tDetails['from'] === $currentState) {
                $validTransition = $tDetails;
                break;
            }
        }

        if (!$validTransition) {
            throw new \InvalidArgumentException("Transition '{$transitionName}' is not valid from state '{$currentState}'.");
        }

        $newState = $validTransition['to'];
        if (!isset($definition['states'][$newState])) {
            throw new \RuntimeException("Target state '{$newState}' is not defined in the workflow definition {$definition['id']}.");
        }
        
        try {
            $this->pdo->beginTransaction();

            // Determine if the new state is terminal
            $isTerminal = true;
            foreach ($definition['transitions'] as $tDefDetails) {
                if ($tDefDetails['from'] === $newState) {
                    $isTerminal = false;
                    break;
                }
            }
            $newInstanceStatus = $isTerminal ? 'completed' : $instance['status'];

            // Update workflow instance
            $stmtUpdateInstance = $this->pdo->prepare(
                "UPDATE workflow_instances SET current_state = :current_state, status = :status, updated_at = CURRENT_TIMESTAMP
                 WHERE id = :id"
            );
            $stmtUpdateInstance->execute([
                ':current_state' => $newState,
                ':status' => $newInstanceStatus,
                ':id' => $instanceId
            ]);

            // Add to workflow history
            $stmtHistory = $this->pdo->prepare(
                "INSERT INTO workflow_history (workflow_instance_id, state, transition, context)
                 VALUES (:workflow_instance_id, :state, :transition, :context)"
            );
            $stmtHistory->execute([
                ':workflow_instance_id' => $instanceId,
                ':state' => $newState,
                ':transition' => $transitionName,
                ':context' => json_encode($context)
            ]);

            $this->pdo->commit();

            return [
                'instance_id' => $instanceId,
                'previous_state' => $currentState,
                'new_state' => $newState,
                'status' => $newInstanceStatus,
                'transition' => $transitionName,
                'message' => "Workflow instance {$instanceId} transitioned to {$newState} via {$transitionName}."
            ];

        } catch (\PDOException $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            error_log("Error transitioning workflow instance {$instanceId}: " . $e->getMessage());
            throw new \RuntimeException("Failed to transition workflow instance: " . $e->getMessage(), 0, $e);
        }
    }

    public function pauseWorkflow(string $instanceId): array
    {
        $instance = $this->getWorkflowInstance($instanceId);
        if (!$instance) {
            throw new \InvalidArgumentException("Workflow instance with ID {$instanceId} not found.");
        }
        if ($instance['status'] !== 'running') {
            throw new \InvalidArgumentException("Workflow instance {$instanceId} cannot be paused. Current status: {$instance['status']}.");
        }

        try {
            $this->pdo->beginTransaction();
            $stmtUpdate = $this->pdo->prepare("UPDATE workflow_instances SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
            $stmtUpdate->execute([':status' => 'paused', ':id' => $instanceId]);

            $stmtHistory = $this->pdo->prepare(
                "INSERT INTO workflow_history (workflow_instance_id, state, transition, context)
                 VALUES (:workflow_instance_id, :state, :transition, :context)"
            );
            $stmtHistory->execute([
                ':workflow_instance_id' => $instanceId,
                ':state' => $instance['current_state'], // Keep current state, only status changes
                ':transition' => 'workflow_paused',
                ':context' => json_encode(['message' => 'Workflow paused'])
            ]);
            $this->pdo->commit();
            return ['id' => $instanceId, 'status' => 'paused', 'message' => "Workflow instance {$instanceId} paused."];
        } catch (\PDOException $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            error_log("Error pausing workflow instance {$instanceId}: " . $e->getMessage());
            throw new \RuntimeException("Failed to pause workflow instance: " . $e->getMessage(), 0, $e);
        }
    }

    public function resumeWorkflow(string $instanceId): array
    {
        $instance = $this->getWorkflowInstance($instanceId);
        if (!$instance) {
            throw new \InvalidArgumentException("Workflow instance with ID {$instanceId} not found.");
        }
        if ($instance['status'] !== 'paused') {
            throw new \InvalidArgumentException("Workflow instance {$instanceId} cannot be resumed. Current status: {$instance['status']}.");
        }
        
        try {
            $this->pdo->beginTransaction();
            $stmtUpdate = $this->pdo->prepare("UPDATE workflow_instances SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
            $stmtUpdate->execute([':status' => 'running', ':id' => $instanceId]);

            $stmtHistory = $this->pdo->prepare(
                "INSERT INTO workflow_history (workflow_instance_id, state, transition, context)
                 VALUES (:workflow_instance_id, :state, :transition, :context)"
            );
            $stmtHistory->execute([
                ':workflow_instance_id' => $instanceId,
                ':state' => $instance['current_state'], // Keep current state
                ':transition' => 'workflow_resumed',
                ':context' => json_encode(['message' => 'Workflow resumed'])
            ]);
            $this->pdo->commit();
            return ['id' => $instanceId, 'status' => 'running', 'message' => "Workflow instance {$instanceId} resumed."];
        } catch (\PDOException $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            error_log("Error resuming workflow instance {$instanceId}: " . $e->getMessage());
            throw new \RuntimeException("Failed to resume workflow instance: " . $e->getMessage(), 0, $e);
        }
    }

    /**
     * RESTful endpoint to handle workflow transitions
     * @param string $instanceId Workflow instance ID
     * @param string $transitionName Transition to execute
     * @param array $context Additional context data
     * @return array Response with status and details
     */
    public function handleTransitionRequest(string $instanceId, string $transitionName, array $context = []): array
    {
        try {
            $this->validateTransitionInput($instanceId, $transitionName, $context);
            return $this->transitionWorkflow($instanceId, $transitionName, $context);
        } catch (\InvalidArgumentException $e) {
            throw new \RuntimeException("Invalid transition request: " . $e->getMessage(), 400, $e);
        } catch (\RuntimeException $e) {
            throw new \RuntimeException("Workflow transition failed: " . $e->getMessage(), 500, $e);
        }
    }

    /**
     * RESTful endpoint to get workflow status
     * @param string $instanceId Workflow instance ID
     * @return array Response with current status
     */
    public function handleStatusRequest(string $instanceId): array
    {
        try {
            $status = $this->getWorkflowStatus($instanceId);
            if ($status === null) {
                throw new \RuntimeException("Workflow instance not found", 404);
            }
            return $status;
        } catch (\RuntimeException $e) {
            throw new \RuntimeException("Failed to get workflow status: " . $e->getMessage(), 500, $e);
        }
    }

    /**
     * Validates transition input parameters
     */
    private function validateTransitionInput(string $instanceId, string $transitionName, array $context): void
    {
        if (empty($instanceId)) {
            throw new \InvalidArgumentException("Instance ID cannot be empty");
        }
        if (empty($transitionName)) {
            throw new \InvalidArgumentException("Transition name cannot be empty");
        }
        if (!is_string($transitionName)) {
            throw new \InvalidArgumentException("Transition name must be a string");
        }
        if (isset($context['user_id']) && !is_int($context['user_id'])) {
            throw new \InvalidArgumentException("User ID must be an integer");
        }
    }

    public function cancelWorkflow(string $instanceId): array
    {
        $instance = $this->getWorkflowInstance($instanceId);
        if (!$instance) {
            throw new \InvalidArgumentException("Workflow instance with ID {$instanceId} not found.");
        }
        if ($instance['status'] === 'completed' || $instance['status'] === 'cancelled') {
             throw new \InvalidArgumentException("Workflow instance {$instanceId} is already {$instance['status']} and cannot be cancelled.");
        }

        try {
            $this->pdo->beginTransaction();
            $stmtUpdate = $this->pdo->prepare("UPDATE workflow_instances SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
            $stmtUpdate->execute([':status' => 'cancelled', ':id' => $instanceId]);

            $stmtHistory = $this->pdo->prepare(
                "INSERT INTO workflow_history (workflow_instance_id, state, transition, context)
                 VALUES (:workflow_instance_id, :state, :transition, :context)"
            );
            $stmtHistory->execute([
                ':workflow_instance_id' => $instanceId,
                ':state' => $instance['current_state'], // Keep current state
                ':transition' => 'workflow_cancelled',
                ':context' => json_encode(['message' => 'Workflow cancelled'])
            ]);
            $this->pdo->commit();
            return ['id' => $instanceId, 'status' => 'cancelled', 'message' => "Workflow instance {$instanceId} cancelled."];
        } catch (\PDOException $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            error_log("Error cancelling workflow instance {$instanceId}: " . $e->getMessage());
            throw new \RuntimeException("Failed to cancel workflow instance: " . $e->getMessage(), 0, $e);
        }
    }
}