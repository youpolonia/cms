<?php

class TenantManager {
    /**
     * Register a new tenant
     * @param string $name Tenant name
     * @param string $email Tenant admin email
     * @param array $quotas Array of quota values
     * @return string Tenant ID
     * @throws Exception If registration fails
     */
    public static function registerTenant(string $name, string $email, array $quotas = []): string {
        $pdo = DB::getConnection();
        
        try {
            $pdo->beginTransaction();

            // Insert tenant record
            $stmt = $pdo->prepare("
                INSERT INTO tenants (name, email, cpu_quota, memory_quota, storage_quota, request_quota)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $name,
                $email,
                $quotas['cpu'] ?? 100,
                $quotas['memory'] ?? 1024,
                $quotas['storage'] ?? 10000,
                $quotas['requests'] ?? 100000
            ]);
            
            $tenantId = $pdo->lastInsertId();

            // Initialize usage tracking
            $stmt = $pdo->prepare("
                INSERT INTO tenant_usage (tenant_id, resource_type, usage)
                VALUES (?, 'cpu', 0), (?, 'memory', 0), (?, 'storage', 0), (?, 'requests', 0)
            ");
            $stmt->execute([$tenantId, $tenantId, $tenantId, $tenantId]);

            $pdo->commit();
            return $tenantId;
        } catch (PDOException $e) {
            $pdo->rollBack();
            throw new Exception("Tenant registration failed: " . $e->getMessage());
        }
    }

    /**
     * Validate tenant credentials
     * @param string $tenantId Tenant ID
     * @return bool True if valid
     */
    public static function validateTenant(string $tenantId): bool {
        $pdo = DB::getConnection();
        $stmt = $pdo->prepare("SELECT id FROM tenants WHERE id = ?");
        $stmt->execute([$tenantId]);
        return (bool)$stmt->fetch();
    }

    /**
     * Get tenant details
     * @param string $tenantId Tenant ID
     * @return array Tenant data
     * @throws Exception If tenant not found
     */
    public static function getTenant(string $tenantId): array {
        $pdo = DB::getConnection();
        $stmt = $pdo->prepare("SELECT * FROM tenants WHERE id = ?");
        $stmt->execute([$tenantId]);
        $tenant = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$tenant) {
            throw new Exception("Tenant not found");
        }
        
        return $tenant;
    }

    /**
     * Check if tenant has available quota
     * @param string $tenantId Tenant ID
     * @param string $resourceType Resource type (cpu, memory, etc.)
     * @param float $amount Amount to check
     * @return bool True if quota available
     */
    public static function checkQuota(string $tenantId, string $resourceType, float $amount): bool {
        return TenantQuotaService::checkQuota($tenantId, $resourceType, $amount);
    }
}