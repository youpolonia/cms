<?php
declare(strict_types=1);

class NotificationService {
    private static array $templates = [
        'approval' => 'Your request #{id} has been approved',
        'rejection' => 'Your request #{id} has been rejected',
        'pending' => 'New action required for request #{id}'
    ];

    private static ?object $dbConnection = null;
    private static array $config = [
        'email_enabled' => false,
        'in_app_enabled' => true
    ];

    public static function init(object $dbConnection, array $config = []): void {
        self::$dbConnection = $dbConnection;
        self::$config = array_merge(self::$config, $config);
    }

    public static function send(string $type, array $data, string $recipient = null): bool {
        if (!isset(self::$templates[$type])) {
            return false;
        }

        $message = str_replace(
            array_map(fn($k) => '{'.$k.'}', array_keys($data)),
            array_values($data),
            self::$templates[$type]
        );

        $success = true;
        
        if (self::$config['email_enabled'] && $recipient) {
            $success = $success && self::sendEmail($recipient, $message);
        }
        
        if (self::$config['in_app_enabled']) {
            $success = $success && self::storeInAppNotification(
                $data['user_id'] ?? null,
                $message,
                $type
            );
        }

        return $success;
    }

    private static function sendEmail(string $to, string $message): bool {
        $headers = "From: notifications@cms.example.com\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        
        return mail($to, 'CMS Notification', $message, $headers);
    }

    private static function storeInAppNotification(
        ?int $userId,
        string $message,
        string $type
    ): bool {
        if (!self::$dbConnection) {
            error_log('Database connection not initialized');
            return false;
        }

        $query = "INSERT INTO notifications
                 (user_id, message, type, created_at, is_read)
                 VALUES (?, ?, ?, NOW(), 0)";
        
        $stmt = self::$dbConnection->prepare($query);
        $stmt->bind_param('iss', $userId, $message, $type);
        
        return $stmt->execute();
    }
}