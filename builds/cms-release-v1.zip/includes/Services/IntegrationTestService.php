<?php
declare(strict_types=1);

namespace Services;

class IntegrationTestService
{
    private array $testResults = [];
    private string $baseUrl;

    public function __construct(string $baseUrl = '')
    {
        $this->baseUrl = $baseUrl ?: ($_SERVER['HTTP_HOST'] ?? 'localhost');
    }

    public function runTests(array $testCases): array
    {
        $this->testResults = [];
        
        foreach ($testCases as $testName => $testCase) {
            $this->runTestCase($testName, $testCase);
        }

        return $this->testResults;
    }

    private function runTestCase(string $name, array $testCase): void
    {
        $url = $this->baseUrl . $testCase['endpoint'];
        $method = $testCase['method'] ?? 'GET';
        $data = $testCase['data'] ?? [];
        $expectedStatus = $testCase['expectedStatus'] ?? 200;

        $result = $this->callApi($url, $method, $data);
        
        $this->testResults[$name] = [
            'passed' => $result['status'] === $expectedStatus,
            'expected' => $expectedStatus,
            'actual' => $result['status'],
            'response' => $result['body']
        ];
    }

    private function callApi(string $url, string $method, array $data): array
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        
        if ($method !== 'GET') {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json'
            ]);
        }

        $response = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return [
            'status' => $status,
            'body' => json_decode($response, true) ?? $response
        ];
    }
}