<?php
// Session configuration for CMS
session_set_cookie_params([
    'lifetime'  => 0,
    'path'      => '/',
    'domain'    => '',
    'secure'    => false,   // localhost
    'httponly'  => true,
    'samesite'  => 'Strict'
]);