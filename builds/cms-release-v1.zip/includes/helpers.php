<?php
/**
 * Helper functions for the CMS
 */

require_once __DIR__ . '/FileCache.php'; // Assuming CMS\FileCache maps to includes/FileCache.php
require_once __DIR__ . '/Config/ConfigLoader.php'; // Assuming CMS\Config\ConfigLoader maps to includes/Config/ConfigLoader.php
require_once __DIR__ . '/ErrorHandler.php'; // For ErrorHandler::class usage

if (!function_exists('env')) {
    /**
     * Gets the value of an environment variable.
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    function env(string $key, $default = null)
    {
        // First check $_ENV superglobal
        $value = $_ENV[$key] ?? null;
        
        // Then check getenv() if not found
        if ($value === null) {
            $value = getenv($key);
        }
        
        // Return default if not found
        if ($value === false) {
            return $default;
        }

        // Convert string values to appropriate types
        switch (strtolower($value)) {
            case 'true':
            case '(true)':
                return true;
            case 'false':
            case '(false)':
                return false;
            case 'empty':
            case '(empty)':
                return '';
            case 'null':
            case '(null)':
                return null;
        }

        // Handle numeric values
        if (is_numeric($value)) {
            return strpos($value, '.') === false ? (int)$value : (float)$value;
        }

        return $value;
    }
}

if (!function_exists('config')) {
    /**
     * Get configuration value using dot notation (file.key)
     *
     * @param string $key Configuration key in format "file.key"
     * @param mixed $default Default value if key not found
     * @return mixed
     */
    /**
     * Get configuration value using dot notation (file.key.subkey)
     *
     * @param string $key Configuration key in format "file.key" or "file.key.subkey"
     * @param mixed $default Default value if key not found
     * @return mixed
     * @throws RuntimeException If config file cannot be loaded
     *
     * Example:
     * config('app.name') - Gets 'name' from app.php config
     * config('database.connections.mysql.host') - Nested access
     */
    function config(string $key, $default = null)
    {
        static $loader = null;
        
        if ($loader === null) {
            try {
                $fileCache = new CMS\FileCache(storage_path('cache/config'));
                $loader = new CMS\Config\ConfigLoader($fileCache, config_path());
                $loader->setErrorHandler([ErrorHandler::class, 'handleConfigError']);
            } catch (Exception $e) {
                throw new RuntimeException('Failed to initialize config loader: ' . $e->getMessage());
            }
        }
        
        try {
            return $loader->get($key, $default);
        } catch (InvalidArgumentException $e) {
            ErrorHandler::handleConfigError($e);
            return $default;
        }
    }
}

if (!function_exists('config_path')) {
    /**
     * Get the configuration path.
     *
     * @param string $path
     * @return string
     */
    function config_path(string $path = ''): string
    {
        return dirname(__DIR__) . '/config' . ($path ? '/' . ltrim($path, '/') : '');
    }
}

if (!function_exists('storage_path')) {
    /**
     * Get the storage path.
     *
     * @param string $path
     * @return string
     */
    function storage_path(string $path = ''): string
    {
        return dirname(__DIR__) . '/storage' . ($path ? '/' . ltrim($path, '/') : '');
    }
}

/**
 * Simple debug helper
 */
if (!function_exists('dd')) {
    function dd(...$vars) {
        foreach ($vars as $var) {
            var_dump($var);
        }
        die(1);
    }
}

if (!function_exists('generate_schema_summary')) {
    /**
     * Creates compact representation of migration schemas
     *
     * @param array $migrationContent Full migration file content
     * @return string Compact schema summary
     */
    function generate_schema_summary(array $migrationContent): string {
        $summary = [];
        foreach ($migrationContent as $table => $columns) {
            $columnTypes = [];
            foreach ($columns as $column => $def) {
                $columnTypes[] = $column . ':' . $def['type'];
            }
            $summary[] = $table . '[' . implode(',', $columnTypes) . ']';
        }
        return implode(';', $summary);
    }
}

if (!function_exists('estimate_token_usage')) {
    /**
     * Estimates token count for analysis tasks
     *
     * @param string $content Content to analyze
     * @return int Approximate token count (4 chars ≈ 1 token)
     */
    function estimate_token_usage(string $content): int {
        return ceil(strlen($content) / 4);
    }
}

if (!function_exists('chunk_migrations')) {
    /**
     * Groups related migrations into chunks (max 3-4 per chunk)
     *
     * @param array $migrations List of migration file paths
     * @return array Chunked migrations
     */
    function chunk_migrations(array $migrations): array {
        $chunks = [];
        $currentChunk = [];
        $currentSize = 0;
        
        foreach ($migrations as $migration) {
            $content = file_get_contents($migration);
            $size = estimate_token_usage($content);
            
            if ($currentSize + $size > 50000 || count($currentChunk) >= 4) {
                $chunks[] = $currentChunk;
                $currentChunk = [];
                $currentSize = 0;
            }
            
            $currentChunk[] = $migration;
            $currentSize += $size;
        }
        
        if (!empty($currentChunk)) {
            $chunks[] = $currentChunk;
        }
        
        return $chunks;
    }
}