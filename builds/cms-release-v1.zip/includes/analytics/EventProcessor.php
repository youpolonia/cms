<?php
declare(strict_types=1);

namespace Includes\Analytics;

use Includes\Database\DatabaseConnection;
use DateTime;
use App\WebSockets\AnalyticsHandler;

require_once __DIR__ . '/../Database/DatabaseConnection.php';
class EventProcessor
{
    private DatabaseConnection $db;

    public function __construct()
    {
        $this->db = new DatabaseConnection();
    }

    /**
     * Process daily analytics events and generate summaries
     */
    public function processDaily(): void
    {
        $yesterday = (new DateTime())->modify('-1 day');
        $start = $yesterday->format('Y-m-d 00:00:00');
        $end = $yesterday->format('Y-m-d 23:59:59');

        try {
            $this->db->beginTransaction();
            
            // 1. Generate daily event summaries
            $this->generateDailySummaries($start, $end);

            // 2. Archive processed events
            $this->archiveProcessedEvents($start, $end);

            $this->db->commit();
            
            echo "Processed analytics for {$yesterday->format('Y-m-d')}\n";
            $this->broadcastDailyUpdate($yesterday);
            
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Failed to process daily analytics: " . $e->getMessage());
            throw $e;
        }
echo "Processed analytics for {$yesterday->format('Y-m-d')}\n";

// Broadcast update to WebSocket clients
$this->broadcastDailyUpdate($yesterday);
}

private function broadcastDailyUpdate(DateTime $date): void
{
$summary = $this->getDailySummary($date->format('Y-m-d'));
AnalyticsHandler::broadcastUpdate([
    'date' => $date->format('Y-m-d'),
    'summary' => $summary
]);
}

public function getDailySummary(string $date): array
{
return $this->db->query(
    "SELECT event_type, count, unique_users
    FROM analytics_daily_summaries
    WHERE date = ?",
    [$date]
)->fetchAll();
}


    private function generateDailySummaries(string $start, string $end): void
    {
        // Generate summary by event type
        $this->db->query(
            "INSERT INTO analytics_daily_summaries
            (date, event_type, count, unique_users, unique_sessions)
            SELECT 
                DATE(created_at) as date,
                event_type,
                COUNT(*) as count,
                COUNT(DISTINCT user_id) as unique_users,
                COUNT(DISTINCT session_id) as unique_sessions
            FROM analytics_events
            WHERE created_at BETWEEN ? AND ?
            GROUP BY DATE(created_at), event_type",
            [$start, $end]
        );

        // Generate content view summaries
        $this->db->query(
            "INSERT INTO analytics_content_views
            (date, content_id, view_count, unique_users)
            SELECT 
                DATE(created_at) as date,
                content_id,
                COUNT(*) as view_count,
                COUNT(DISTINCT user_id) as unique_users
            FROM analytics_events
            WHERE event_type = 'content_view'
            AND created_at BETWEEN ? AND ?
            GROUP BY DATE(created_at), content_id",
            [$start, $end]
        );
    }

    private function archiveProcessedEvents(string $start, string $end): void
    {
        // Move processed events to archive table
        $this->db->query(
            "INSERT INTO analytics_events_archive
            SELECT * FROM analytics_events
            WHERE created_at BETWEEN ? AND ?",
            [$start, $end]
        );

        // Delete processed events
        $this->db->query(
            "DELETE FROM analytics_events
            WHERE created_at BETWEEN ? AND ?",
            [$start, $end]
        );
    }
}