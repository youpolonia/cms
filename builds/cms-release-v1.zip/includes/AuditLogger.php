<?php
require_once CMS_ROOT . '/includes/Database/Connection.php';

class AuditLogger {
    public static function logAccess(?int $userId, string $resourceType, string $action, string $resourceId): void {
        $db = new DatabaseConnection();
        $pdo = $db->getPdo();
        
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        
        $stmt = $pdo->prepare("
            INSERT INTO data_access_audit_log
            (user_id, access_time, resource_type, action, resource_id, ip_address)
            VALUES (:user_id, NOW(), :resource_type, :action, :resource_id, :ip_address)
        ");
        
        $stmt->execute([
            ':user_id' => $userId,
            ':resource_type' => $resourceType,
            ':action' => $action,
            ':resource_id' => $resourceId,
            ':ip_address' => $ip
        ]);
    }
}