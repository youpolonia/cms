<?php
namespace Includes\Cache;

class FileCache implements CacheInterface {
    private string $cachePath;

    public function __construct(array $config) {
        if (empty($config['path'])) {
            throw new \InvalidArgumentException('File cache path not configured');
        }

        $this->cachePath = rtrim($config['path'], '/');
        if (!is_dir($this->cachePath)) {
            if (!mkdir($this->cachePath, 0755, true)) {
                throw new \RuntimeException("Failed to create cache directory: {$this->cachePath}");
            }
        }
    }

    public function get(string $key, $default = null) {
        $file = $this->getFilePath($key);
        if (!file_exists($file)) {
            return $default;
        }

        $data = unserialize(file_get_contents($file));
        if ($data['expires'] > 0 && $data['expires'] < time()) {
            $this->delete($key);
            return $default;
        }

        return $data['value'];
    }

    public function set(string $key, $value, int $ttl = 0): bool {
        $file = $this->getFilePath($key);
        $data = [
            'value' => $value,
            'expires' => $ttl > 0 ? time() + $ttl : 0
        ];

        return file_put_contents($file, serialize($data)) !== false;
    }

    public function delete(string $key): bool {
        $file = $this->getFilePath($key);
        return file_exists($file) ? unlink($file) : true;
    }

    private function getFilePath(string $key): string {
        $hash = md5($key);
        return "{$this->cachePath}/{$hash}.cache";
    }
}