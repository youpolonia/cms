<?php
require_once __DIR__ . '/../core/Logger.php';

class MigrationHandler {
    public static function handleRequest() {
        $logger = new Logger();
        
        if (!isset($_GET['action']) || !isset($_GET['migration'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing parameters']);
            return;
        }

        $migrationFile = "database/migrations/{$_GET['migration']}.php";
        if (!file_exists($migrationFile)) {
            http_response_code(404);
            echo json_encode(['error' => 'Migration not found']);
            return;
        }

        require_once $migrationFile;
        $className = str_replace('.php', '', $_GET['migration']);

        try {
            if ($_GET['action'] === 'apply') {
                $result = call_user_func([$className, 'applyChanges']);
                $logger->log("Migration {$className} applied successfully");
                echo json_encode(['success' => true]);
            } elseif ($_GET['action'] === 'revert') {
                $result = call_user_func([$className, 'revertChanges']);
                $logger->log("Migration {$className} reverted successfully");
                echo json_encode(['success' => true]);
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Invalid action']);
            }
        } catch (Exception $e) {
            $logger->log("Migration error: " . $e->getMessage(), 'ERROR');
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
    }
}

// Handle request if accessed directly
if (php_sapi_name() !== 'cli') {
    MigrationHandler::handleRequest();
}