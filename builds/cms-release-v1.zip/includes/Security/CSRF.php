<?php
/**
 * Unified CSRF Protection Service
 * Replaces multiple implementations across codebase
 */
namespace Includes\Security;

class CSRF {
    const SESSION_KEY = 'csrf_token';
    const DEFAULT_LIFETIME = 3600; // 1 hour

    /**
     * Generate and store a new CSRF token
     * @param int|null $lifetime Optional lifetime in seconds
     * @return string Generated token
     */
    public static function generate(?int $lifetime = null): string {
        $token = bin2hex(random_bytes(32));
        $_SESSION[self::SESSION_KEY] = $token;
        
        if ($lifetime !== null) {
            $_SESSION[self::SESSION_KEY.'_expires'] = time() + $lifetime;
        }
        
        return $token;
    }

    /**
     * Validate a submitted CSRF token
     * @param string $token Token to validate
     * @param bool $consume Whether to consume/clear the token after validation
     * @return bool True if valid
     */
    public static function validate(string $token, bool $consume = false): bool {
        if (!isset($_SESSION[self::SESSION_KEY])) {
            return false;
        }

        // Check expiration if set
        if (isset($_SESSION[self::SESSION_KEY.'_expires']) && 
            time() > $_SESSION[self::SESSION_KEY.'_expires']) {
            self::clear();
            return false;
        }

        $isValid = hash_equals($_SESSION[self::SESSION_KEY], $token);
        
        if ($consume && $isValid) {
            self::clear();
        }
        
        return $isValid;
    }

    /**
     * Get current token without generating new one
     * @return string|null Token if exists
     */
    public static function get(): ?string {
        return $_SESSION[self::SESSION_KEY] ?? null;
    }

    /**
     * Clear current token
     */
    public static function clear(): void {
        unset($_SESSION[self::SESSION_KEY]);
        unset($_SESSION[self::SESSION_KEY.'_expires']);
    }

    /**
     * Middleware for CSRF protection
     * @param array $except Routes to exclude
     * @return \Closure Middleware function
     */
    public static function middleware(array $except = []): \Closure {
        return function($request, $next) use ($except) {
            if (in_array($request->getPath(), $except)) {
                return $next($request);
            }

            $token = $request->input('_token') ?: 
                    $request->header('X-CSRF-TOKEN');

            if (!self::validate($token, true)) {
                throw new \RuntimeException('CSRF token validation failed', 419);
            }

            return $next($request);
        };
    }
}