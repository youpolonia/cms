<?php
namespace Includes\Security;

class SecurityMiddleware {
    /**
     * @deprecated Use \Includes\Security\CSRF::generate() instead
     */
    public static function csrfToken() {
        return \Includes\Security\CSRF::generate();
    }

    /**
     * @deprecated Use \Includes\Security\CSRF::validate() instead
     */
    public static function validateCsrf($token) {
        return \Includes\Security\CSRF::validate($token);
    }

    public static function validateSession() {
        session_start();
        if (empty($_SESSION['user_id'])) {
            header('HTTP/1.1 401 Unauthorized');
            exit('Unauthorized access');
        }
    }

    public static function hasPermission($requiredRole) {
        return isset($_SESSION['role']) && 
               $_SESSION['role'] === $requiredRole;
    }

    public static function sanitizeInput($input) {
        return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    }
}