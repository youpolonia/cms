<?php
/**
 * Tenant Manager - Handles tenant identification and configuration
 */
class TenantManager {
    private static $currentTenant = null;
    private static $tenantConfigs = [];

    /**
     * Get current tenant ID
     * @return string|null
     */
    public static function getCurrentTenant() {
        return self::$currentTenant;
    }

    /**
     * Validate tenant ID exists
     * @param PDO $pdo Database connection
     * @param string $tenantId
     * @return bool
     */
    public static function validateTenant(PDO $pdo, $tenantId) {
        $stmt = $pdo->prepare("
            SELECT 1 FROM tenants 
            WHERE id = :tenant_id
            LIMIT 1
        ");
        $stmt->execute([':tenant_id' => $tenantId]);
        return (bool)$stmt->fetchColumn();
    }

    /**
     * Get merged config for tenant
     * @param string $tenantId
     * @return array
     */
    public static function getTenantConfig($tenantId) {
        if (!isset(self::$tenantConfigs[$tenantId])) {
            $globalConfig = require __DIR__ . '/../config/global.php';
            $tenantConfig = require __DIR__ . "/../config/tenants/{$tenantId}.php";
            $siteConfig = [];

            if (file_exists(__DIR__ . "/../config/sites/{$tenantId}.php")) {
                $siteConfig = require __DIR__ . "/../config/sites/{$tenantId}.php";
            }

            self::$tenantConfigs[$tenantId] = array_merge(
                $globalConfig,
                $tenantConfig,
                $siteConfig
            );
        }

        return self::$tenantConfigs[$tenantId];
    }

    /**
     * Initialize tenant context from request
     * @param PDO $pdo Database connection
     * @param array $headers HTTP headers
     * @return bool True if tenant is valid
     */
    public static function initializeFromRequest(PDO $pdo, $headers) {
        $tenantId = $headers['X-Tenant-ID'] ?? null;
        
        if ($tenantId && self::validateTenant($pdo, $tenantId)) {
            self::$currentTenant = $tenantId;
            return true;
        }

        return false;
    }
}