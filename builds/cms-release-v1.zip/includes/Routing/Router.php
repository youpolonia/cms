<?php
class Router {
    protected $routes = [];
    protected $middlewares = [];

    public function addRoute($method, $path, $handler, $middlewares = []) {
        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'handler' => $handler,
            'middlewares' => $middlewares
        ];
    }

    public function addMiddleware($middleware) {
        $this->middlewares[] = $middleware;
    }

    public function match($method, $path) {
        foreach ($this->routes as $route) {
            if ($route['method'] === $method && $route['path'] === $path) {
                return $route;
            }
        }
        return null;
    }

    public function dispatch($method, $path) {
        $route = $this->match($method, $path);
        if ($route) {
            // Run global middlewares
            foreach ($this->middlewares as $middleware) {
                call_user_func($middleware);
            }

            // Run route-specific middlewares
            foreach ($route['middlewares'] as $middleware) {
                call_user_func($middleware);
            }

            $handler = $route['handler'];
            if (is_array($handler) && method_exists($handler[0], $handler[1])) {
                return call_user_func($handler);
            }
            return $handler();
        }
        return null;
    }
}