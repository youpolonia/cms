<?php
/**
 * Environment Configuration Manager
 * Handles environment-specific settings for deployments
 */
namespace CMS\Deployment;

class EnvironmentManager {
    private $envFile = '.env';
    private $envExampleFile = '.env.example';
    private $backupDir = 'backups/env/';
    private $currentEnv = [];

    public function __construct() {
        $this->ensureBackupDirExists();
        $this->loadCurrentEnv();
    }

    /**
     * Create backup directory if it doesn't exist
     */
    private function ensureBackupDirExists(): void {
        if (!is_dir($this->backupDir)) {
            mkdir($this->backupDir, 0755, true);
        }
    }

    /**
     * Load current environment variables
     */
    private function loadCurrentEnv(): void {
        if (file_exists($this->envFile)) {
            $this->currentEnv = $this->parseEnvFile($this->envFile);
        }
    }

    /**
     * Parse .env file into associative array
     */
    public function parseEnvFile(string $filePath): array {
        $env = [];
        $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        foreach ($lines as $line) {
            if (strpos(trim($line), '#') === 0 || strpos($line, '=') === false) {
                continue;
            }

            list($key, $value) = explode('=', $line, 2);
            $env[trim($key)] = trim($value);
        }

        return $env;
    }

    /**
     * Backup current environment file
     */
    public function backupCurrentEnv(string $backupName): bool {
        if (!file_exists($this->envFile)) {
            return false;
        }

        $backupPath = $this->backupDir . date('Y-m-d_His') . '_' . $backupName . '.env';
        return copy($this->envFile, $backupPath);
    }

    /**
     * Create new environment file from example
     */
    public function createFromExample(): bool {
        if (!file_exists($this->envExampleFile)) {
            throw new \RuntimeException("Example environment file not found");
        }

        return copy($this->envExampleFile, $this->envFile);
    }

    /**
     * Update environment variable
     */
    public function updateVariable(string $key, string $value): void {
        $this->currentEnv[$key] = $value;
    }

    /**
     * Remove environment variable
     */
    public function removeVariable(string $key): void {
        unset($this->currentEnv[$key]);
    }

    /**
     * Save environment changes to file
     */
    public function save(): bool {
        $content = '';
        foreach ($this->currentEnv as $key => $value) {
            $content .= "$key=$value\n";
        }

        return file_put_contents($this->envFile, $content) !== false;
    }

    /**
     * Get environment variable
     */
    public function getVariable(string $key): ?string {
        return $this->currentEnv[$key] ?? null;
    }

    /**
     * Get all environment variables
     */
    public function getAllVariables(): array {
        return $this->currentEnv;
    }

    /**
     * Apply environment template
     */
    public function applyTemplate(string $templatePath): bool {
        if (!file_exists($templatePath)) {
            throw new \RuntimeException("Template file not found");
        }

        $template = $this->parseEnvFile($templatePath);
        $this->currentEnv = array_merge($this->currentEnv, $template);
        return $this->save();
    }

    /**
     * Validate required environment variables
     */
    public function validateRequired(array $requiredKeys): array {
        $missing = [];
        foreach ($requiredKeys as $key) {
            if (!isset($this->currentEnv[$key])) {
                $missing[] = $key;
            }
        }
        return $missing;
    }
}