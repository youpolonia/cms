<?php
class DatabaseConnection {
    private static $instance = null;
    private $connection;

    private function __construct() {
        $app = \Includes\Core\Application::getInstance();
        $this->connection = $app->get('db');
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->connection;
    }

    public function prepare($statement) {
        return $this->connection->prepare($statement);
    }

    public function exec($statement) {
        return $this->connection->exec($statement);
    }
}