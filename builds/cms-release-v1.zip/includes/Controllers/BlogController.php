<?php

namespace Includes\Controllers;

use Includes\Database\DatabaseConnection;

use Includes\RoutingV2\Router;
use Includes\RoutingV2\Request;
use Includes\RoutingV2\Response;

class BlogController
{
    public function listPosts(Request $request): Response
    {
        // Pagination parameters
        $page = max(1, (int)($request->getQueryParams()['page'] ?? 1));
        $perPage = 10;
        
        // Get published posts from database
        $posts = $this->getPublishedPosts($page, $perPage);
        $totalPosts = $this->getTotalPublishedPosts();
        
        return new Response(200, [
            'Content-Type' => 'text/html'
        ], $this->renderTemplate('blog/list', [
            'posts' => $posts,
            'currentPage' => $page,
            'totalPages' => ceil($totalPosts / $perPage)
        ]));
    }

    private function getPublishedPosts(int $page, int $perPage): array
    {
        $offset = ($page - 1) * $perPage;
        
        $sql = "SELECT
            id, title, slug, excerpt,
            published_at, author_id,
            DATE_FORMAT(published_at, '%Y-%m-%d') as published_date
        FROM blog_posts
        WHERE status = 'published'
        AND published_at <= NOW()
        ORDER BY published_at DESC
        LIMIT :limit OFFSET :offset";

        $stmt = DatabaseConnection::getInstance()
            ->prepare($sql);
            
        $stmt->bindValue(':limit', $perPage, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    private function getTotalPublishedPosts(): int
    {
        $sql = "SELECT COUNT(*)
                FROM blog_posts
                WHERE status = 'published'
                AND published_at <= NOW()";
                
        $stmt = DatabaseConnection::getInstance()
            ->query($sql);
            
        return (int)$stmt->fetchColumn();
    }

    private function renderTemplate(string $template, array $data = []): string
    {
        // TODO: Implement template rendering with fallback
        return '';
    }
}