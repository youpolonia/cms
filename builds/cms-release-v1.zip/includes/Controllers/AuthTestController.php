<?php

class AuthTestController {
    public static function test(): array {
        return [
            'status' => 'success',
            'message' => 'Auth system is working',
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
}