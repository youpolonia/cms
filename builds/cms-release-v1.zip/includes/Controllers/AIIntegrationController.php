<?php
declare(strict_types=1);

use Core\TenantManager;
use InvalidArgumentException;
use RuntimeException;

class AIIntegrationController {
    private array $providers = [];
    private string $activeProvider;
    private string $tenantId;

    public function __construct() {
        $this->tenantId = TenantManager::getCurrentTenant()['tenant_id'];
        $this->loadProviders();
    }

    private function loadProviders(): void {
        // Load from config/providers.json
        $providersConfig = json_decode(
            file_get_contents(__DIR__ . '/../../config/providers.json'),
            true
        )['ai_providers'] ?? [];

        foreach ($providersConfig as $name => $config) {
            $this->providers[$name] = [
                'class' => $config['class'],
                'config' => $config
            ];
        }

        $this->activeProvider = $providersConfig['default'] ?? array_key_first($this->providers);
    }

    public function processRequest(array $input): array {
        if (!TenantManager::checkQuota($this->tenantId)) {
            throw new RuntimeException('Tenant quota exceeded');
        }

        $provider = $this->getProviderInstance($this->activeProvider);
        $result = $provider->process($input);

        // Store results in tenant-specific storage
        $storagePath = TenantManager::getStoragePath($this->tenantId) . '/ai_results/';
        if (!is_dir($storagePath)) {
            mkdir($storagePath, 0755, true);
        }
        file_put_contents(
            $storagePath . uniqid('ai_') . '.json',
            json_encode($result)
        );

        return $result;
    }

    private function getProviderInstance(string $providerName): AIIntegrationProvider {
        if (!isset($this->providers[$providerName])) {
            throw new InvalidArgumentException("Invalid provider: $providerName");
        }

        require_once __DIR__ . '/../Providers/' . $this->providers[$providerName]['class'] . '.php';
        return new $this->providers[$providerName]['class']($this->providers[$providerName]['config']);
    }

    public function setActiveProvider(string $providerName): void {
        if (!isset($this->providers[$providerName])) {
            throw new InvalidArgumentException("Invalid provider: $providerName");
        }
        $this->activeProvider = $providerName;
    }

    public function getTenantId(): string
    {
        return $this->tenantId;
    }
}

interface AIIntegrationProvider {
    public function process(array $input): array;
}