<?php
/**
 * Company Controller - Handles company operations
 */
class CompanyController {
    /**
     * Get company by ID
     * @param int $id Company ID
     * @return array|null Company data or null if not found
     */
    public static function getById(int $id): ?array {
        $company = new CompanyModel();
        return $company->load($id) ? $company->toArray() : null;
    }

    /**
     * Get company by slug
     * @param string $slug Company slug
     * @return array|null Company data or null if not found
     */
    public static function getBySlug(string $slug): ?array {
        $db = Database::getInstance();
        $stmt = $db->prepare("SELECT * FROM companies WHERE slug = ?");
        $stmt->execute([$slug]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * Get all companies
     * @return array List of companies
     */
    public static function getAll(): array {
        $db = Database::getInstance();
        return $db->query("SELECT * FROM companies")->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Create new company
     * @param array $data Company data
     * @return bool|int Company ID on success, false on failure
     */
    public static function create(array $data) {
        $company = new CompanyModel();
        foreach ($data as $key => $value) {
            if (property_exists($company, $key)) {
                $company->$key = $value;
            }
        }
        return $company->save() ? $company->id : false;
    }

    /**
     * Update company
     * @param int $id Company ID
     * @param array $data Company data
     * @return bool True on success
     */
    public static function update(int $id, array $data): bool {
        $company = new CompanyModel();
        if (!$company->load($id)) {
            return false;
        }
        foreach ($data as $key => $value) {
            if (property_exists($company, $key)) {
                $company->$key = $value;
            }
        }
        return $company->save();
    }
}