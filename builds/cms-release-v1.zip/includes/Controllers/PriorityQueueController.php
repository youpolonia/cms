<?php
class PriorityQueueController {
    // ... existing methods ...

    public function edit() {
        $id = $_GET['id'] ?? null;
        if (!$id) {
            header('Location: /admin/priority_queue/index.php');
            exit;
        }

        $queue = PriorityQueue::find($id);
        if (!$queue) {
            Flash::add('Queue not found', 'error');
            header('Location: /admin/priority_queue/index.php');
            exit;
        }

        View::render('admin/priority_queue/views/edit.php', [
            'queue' => $queue
        ]);
    }
}