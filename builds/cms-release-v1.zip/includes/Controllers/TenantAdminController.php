<?php
declare(strict_types=1);

/**
 * Tenant Administration Controller
 * Handles tenant management in admin panel
 */
class TenantAdminController {
    public static function list(): string {
        $tenants = DB::queryAll("SELECT * FROM tenants ORDER BY created_at DESC");
        return View::render('admin/tenants/list', ['tenants' => $tenants]);
    }

    public static function create(array $request): string {
        if ($request['method'] === 'POST') {
            $data = self::validateTenantData($request['post']);
            DB::insert('tenants', $data);
            return Response::redirect('/admin/tenants');
        }
        return View::render('admin/tenants/create');
    }

    public static function edit(string $id, array $request): string {
        $tenant = DB::queryOne("SELECT * FROM tenants WHERE id = ?", [$id]);
        
        if ($request['method'] === 'POST') {
            $data = self::validateTenantData($request['post']);
            DB::update('tenants', $data, ['id' => $id]);
            return Response::redirect('/admin/tenants');
        }

        return View::render('admin/tenants/edit', ['tenant' => $tenant]);
    }

    private static function validateTenantData(array $data): array {
        $validated = [
            'name' => filter_var($data['name'], FILTER_SANITIZE_STRING),
            'status' => in_array($data['status'], ['active', 'suspended']) ? $data['status'] : 'active',
            'cpu_quota' => (int)$data['cpu_quota'],
            'request_quota' => (int)$data['request_quota']
        ];

        if (isset($data['api_key'])) {
            $validated['api_key'] = hash('sha256', $data['api_key']);
        }

        return $validated;
    }
}