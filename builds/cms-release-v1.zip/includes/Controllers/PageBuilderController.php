<?php
namespace Includes\Controllers;

require_once __DIR__ . '/../Services/VersionService.php'; // For Includes\Services\VersionService
require_once __DIR__ . '/../Services/ContentService.php'; // For Includes\Services\ContentService
require_once __DIR__ . '/../View.php';                   // For Includes\View

use Includes\Services\VersionService;
use Includes\Services\ContentService;

class PageBuilderController {
    private VersionService $versionService;
    private ContentService $contentService;

    public function __construct(VersionService $versionService, ContentService $contentService) {
        $this->versionService = $versionService;
        $this->contentService = $contentService;
    }
    public function showEditor($contentId) {
        // Load editor view with content
        return \Includes\View::render('admin/page-builder/editor', [
            'contentId' => $contentId
        ]);
    }

    public function showVersions($contentId) {
        $versions = $this->versionService->getVersions($contentId);
        
        return \Includes\View::render('admin/page-builder/versions', [
            'contentId' => $contentId,
            'versions' => $versions
        ]);
    }

    public function bulkDeleteVersions($contentId) {
        if (!empty($_POST['version_ids'])) {
            $versionIds = array_map('intval', $_POST['version_ids']);
            $this->versionService->deleteVersions($versionIds);
        }
        header('Location: /admin/page-builder/'.$contentId.'/versions');
        exit;
    }

    public function compareVersions($contentId, $versionId) {
        // Compare version with latest
        return \Includes\View::render('admin/page-builder/compare', [
            'contentId' => $contentId,
            'versionId' => $versionId
        ]);
    }

    public function restoreVersion($contentId, $versionId) {
        $version = $this->versionService->getVersion($versionId);
        if ($version && $version['content_id'] == $contentId) {
            $this->contentService->updateContent($contentId, $version['content']);
        }
        header('Location: /admin/page-builder/'.$contentId);
        exit;
    }
}