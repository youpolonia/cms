<?php
/**
 * Deployment Controller
 * 
 * Handles HTTP requests for deployment operations
 */

class DeploymentController {
    private $deploymentService;
    
    public function __construct() {
        require_once __DIR__ . '/../Services/DeploymentService.php';
        $this->deploymentService = new DeploymentService();
    }
    
    /**
     * Run database migrations
     */
    public function runMigrations() {
        try {
            $result = $this->deploymentService->runMigrations();
            return [
                'status' => 'success',
                'data' => $result
            ];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Synchronize files between environments
     */
    public function syncFiles($source, $target) {
        try {
            $result = $this->deploymentService->syncFiles($source, $target);
            return [
                'status' => 'success',
                'data' => $result
            ];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Verify system versions
     */
    public function verifyVersions() {
        try {
            $result = $this->deploymentService->verifyVersions();
            return [
                'status' => 'success',
                'data' => $result
            ];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Execute full deployment
     */
    public function deploy() {
        try {
            $result = $this->deploymentService->deploy();
            return [
                'status' => 'success',
                'data' => $result
            ];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }
}