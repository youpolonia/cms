<?php

declare(strict_types=1);

namespace Controllers;

use Core\Auth;
use Core\Logger;
use Includes\Auth\AuthService;

class AuthController
{
    private static AuthService $authService;

    public static function init(): void
    {
        self::$authService = new AuthService();
    }

    /**
     * Handle user login
     */
    public static function login(string $username, string $password): bool
    {
        if (!self::validatePasswordPolicy($password)) {
            Logger::log('auth', 'Password policy violation', [
                'username' => $username,
                'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ]);
            return false;
        }

        $user = self::$authService->authenticate($username, $password);
        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_role'] = $user['role'];
            session_regenerate_id(true);
            
            Logger::log('auth', 'User logged in', [
                'user_id' => $user['id'],
                'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ]);
            
            return true;
        }

        Logger::log('auth', 'Failed login attempt', [
            'username' => $username,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ]);

        return false;
    }

    private static function validatePasswordPolicy(string $password): bool
    {
        // Minimum 8 characters
        if (strlen($password) < 8) {
            return false;
        }

        // At least one uppercase letter
        if (!preg_match('/[A-Z]/', $password)) {
            return false;
        }

        // At least one lowercase letter
        if (!preg_match('/[a-z]/', $password)) {
            return false;
        }

        // At least one number
        if (!preg_match('/[0-9]/', $password)) {
            return false;
        }

        // At least one special character
        if (!preg_match('/[^A-Za-z0-9]/', $password)) {
            return false;
        }

        return true;
    }

    /**
     * Handle user logout
     */
    public static function logout(): void
    {
        $userId = $_SESSION['user_id'] ?? null;
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        
        Logger::log('auth', 'User logged out', [
            'user_id' => $userId,
            'ip' => $ip
        ]);
        
        // Clear all session data
        $_SESSION = [];

        // Destroy the session
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }

        // Start new session with fresh ID
        session_start();
        session_regenerate_id(true);
    }

    /**
     * Check if current user is admin
     */
    public static function isAdmin(): bool
    {
        return Auth::hasRole('admin');
    }

    /**
     * Validate current session
     */
    public static function validateSession(): bool
    {
        return Auth::check();
    }
}