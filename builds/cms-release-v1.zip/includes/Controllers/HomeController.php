<?php
namespace Includes\Controllers;

require_once __DIR__ . '/../../models/ContentPageModel.php';
require_once __DIR__ . '/../../config/content.php';
require_once __DIR__ . '/MarkdownProcessor.php';

use Models\ContentPageModel;
use Includes\MarkdownProcessor;

class HomeController {
    protected $contentModel;
    protected $markdownProcessor;
    protected $config;
    protected $basePath;

    public function __construct() {
        $this->contentModel = new ContentPageModel();
        $this->config = require __DIR__ . '/../../config/content.php';
        $this->markdownProcessor = new MarkdownProcessor($this->config['markdown'] ?? []);
        $this->basePath = defined('CMS_ROOT') ? CMS_ROOT : dirname(__DIR__, 3);
    }

    public function index() {
        try {
            // Get content based on config
            $content = $this->getContent();

            // Render the template with processed content
            $this->renderTemplate($content);
        } catch (\Exception $e) {
            error_log("HomeController error: " . $e->getMessage());
            $this->handleError();
        }
    }

    protected function getContent() {
        if ($this->config['home_page']['source'] === 'database') {
            $pageId = $this->config['home_page']['page_id'] ?? 'home';
            $page = $this->contentModel->getById($pageId);

            if (!$page || $page['current_status'] !== 'published') {
                throw new \Exception("Published home page content not found");
            }

            // Process markdown if content exists
            if (!empty($page['content'])) {
                $page['processed_content'] = $this->markdownProcessor->process($page['content']);
            }

            return $page;
        }

        // Fallback to static content
        return [
            'title' => 'CMS Home',
            'content' => 'Welcome to our CMS',
            'processed_content' => '<p>Welcome to our CMS</p>'
        ];
    }

    protected function renderTemplate(array $content) {
        extract($content);
        require $this->basePath . '/templates/home.php';
    }

    protected function handleError() {
        if ($this->config['home_page']['fallback_enabled'] ?? false) {
            $fallbackTemplate = $this->config['home_page']['fallback_template'] ?? 'home/fallback';
            require $this->basePath . "/templates/{$fallbackTemplate}.php";
        } else {
            header("HTTP/1.0 500 Internal Server Error");
            echo "An error occurred loading the home page";
        }
    }
}