<?php

declare(strict_types=1);

namespace Includes\Controllers;

use Includes\Content\VersionCleaner;
use PDO;

class VersionCleanupController
{
    private PDO $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
        VersionCleaner::initialize($db);
    }

    public function cleanContentVersions(int $contentId): array
    {
        $deleted = VersionCleaner::cleanVersions($contentId);
        return [
            'status' => 'success',
            'deleted' => $deleted,
            'content_id' => $contentId
        ];
    }

    public function getCleanupStats(): array
    {
        try {
            $stmt = $this->db->query(
                "SELECT
                    COUNT(*) as total_versions,
                    COUNT(DISTINCT content_id) as unique_content,
                    SUM(size_bytes) as total_size
                FROM content_versions"
            );
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException $e) {
            Logger::log(
                "VersionCleanupController",
                "Failed to fetch cleanup stats: " . $e->getMessage(),
                'error'
            );
            return ['error' => 'Failed to fetch stats'];
        }
    }

    public function cleanAllVersions(): array
    {
        try {
            $contentIds = $this->getAllContentIds();
            $results = [];
            
            foreach ($contentIds as $contentId) {
                $results[$contentId] = VersionCleaner::cleanVersions($contentId);
            }

            return [
                'status' => 'completed',
                'results' => $results,
                'total_cleaned' => array_sum($results)
            ];
        } catch (Exception $e) {
            Logger::log(
                "VersionCleanupController",
                "Batch cleanup failed: " . $e->getMessage(),
                'error'
            );
            return ['error' => 'Batch cleanup failed'];
        }
    }

    private function getAllContentIds(): array
    {
        $stmt = $this->db->query("SELECT DISTINCT content_id FROM content_versions");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
}