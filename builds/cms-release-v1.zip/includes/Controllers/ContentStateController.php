<?php
declare(strict_types=1);

class ContentStateController {
    public static function changeState(array $request): array {
        try {
            $contentId = (int)($request['content_id'] ?? 0);
            $newState = (string)($request['new_state'] ?? '');
            $userId = (int)($request['user_id'] ?? 0);
            $notes = (string)($request['notes'] ?? '');

            if (!$contentId || !$newState || !$userId) {
                throw new InvalidArgumentException('Missing required parameters');
            }

            $newStateId = ContentStateManager::getStateId($newState);
            if ($newStateId === null) {
                throw new InvalidArgumentException('Invalid state');
            }

            $currentStateId = self::getCurrentStateId($contentId);
            if (!ContentStateManager::isValidTransition($currentStateId, $newStateId)) {
                throw new InvalidArgumentException('Invalid state transition');
            }

            if (!ContentStateHistory::logTransition($contentId, $currentStateId, $newStateId, $userId, $notes)) {
                throw new RuntimeException('Failed to log state transition');
            }

            return [
                'success' => true,
                'message' => 'State changed successfully',
                'new_state' => ContentStateManager::getStateName($newStateId)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    private static function getCurrentStateId(int $contentId): int {
        // Implementation to get current state from database
        return 1; // Default to draft state
    }
}