<?php
declare(strict_types=1);

class ContentVersionController {
    /**
     * Creates new content version
     * @param int $contentId Original content ID
     * @param array $data Version data (JSON)
     * @return array Created version data
     */
    public static function create(int $contentId, array $data): array {
        try {
            $version = self::getNextVersion($contentId);
            $createdAt = date('Y-m-d H:i:s');
            
            $stmt = db()->prepare(
                "INSERT INTO content_versions 
                (content_id, version, data, created_at) 
                VALUES (?, ?, ?, ?)"
            );
            $stmt->execute([
                $contentId, 
                $version,
                json_encode($data),
                $createdAt
            ]);

            return [
                'id' => db()->lastInsertId(),
                'content_id' => $contentId,
                'version' => $version,
                'created_at' => $createdAt
            ];
        } catch (Exception $e) {
            error_log("Version creation failed: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Gets next version number for content
     */
    private static function getNextVersion(int $contentId): int {
        $stmt = db()->prepare(
            "SELECT MAX(version) FROM content_versions 
            WHERE content_id = ?"
        );
        $stmt->execute([$contentId]);
        return (int)$stmt->fetchColumn() + 1;
    }

    /**
     * Gets all versions for content
     */
    public static function list(int $contentId): array {
        $stmt = db()->prepare(
            "SELECT * FROM content_versions 
            WHERE content_id = ? 
            ORDER BY version DESC"
        );
        $stmt->execute([$contentId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Gets specific version data
     */
    public static function get(int $contentId, int $version): ?array {
        $stmt = db()->prepare(
            "SELECT * FROM content_versions 
            WHERE content_id = ? AND version = ?"
        );
        $stmt->execute([$contentId, $version]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }
}