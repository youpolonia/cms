<?php

class StatusController {
    /**
     * Create a new status transition record
     */
    public static function create(array $data): array {
        try {
            // Validate input
            self::validateTransitionData($data);
            
            // Get tenant ID from session
            $tenantId = self::getTenantId();
            
            // Insert into database
            $sql = "INSERT INTO status_transitions
                    (entity_type, entity_id, from_status, to_status, reason, tenant_id)
                    VALUES (:entity_type, :entity_id, :from_status, :to_status, :reason, :tenant_id)";
            
            $stmt = self::getDb()->prepare($sql);
            $stmt->execute([
                'entity_type' => $data['entity_type'],
                'entity_id' => $data['entity_id'],
                'from_status' => $data['from_status'],
                'to_status' => $data['to_status'],
                'reason' => $data['reason'] ?? null,
                'tenant_id' => $tenantId
            ]);
            
            $newId = self::getDb()->lastInsertId();
            
            // Log version control change
            self::logVersionControlChange(
                $data['entity_type'],
                $data['entity_id'],
                "Status changed from {$data['from_status']} to {$data['to_status']}",
                $data['reason'] ?? null
            );
            
            return [
                'status' => 'success',
                'id' => $newId
            ];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Get status transition by ID
     */
    public static function read(int $id): array {
        try {
            $tenantId = self::getTenantId();
            
            $sql = "SELECT * FROM status_transitions 
                    WHERE id = :id AND tenant_id = :tenant_id";
            
            $stmt = self::getDb()->prepare($sql);
            $stmt->execute(['id' => $id, 'tenant_id' => $tenantId]);
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$result) {
                throw new Exception("Status transition not found");
            }
            
            return $result;
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Update status transition record
     */
    public static function update(int $id, array $data): array {
        try {
            self::validateTransitionData($data);
            $tenantId = self::getTenantId();
            
            $sql = "UPDATE status_transitions SET
                    entity_type = :entity_type,
                    entity_id = :entity_id,
                    from_status = :from_status,
                    to_status = :to_status,
                    reason = :reason
                    WHERE id = :id AND tenant_id = :tenant_id";
            
            $stmt = self::getDb()->prepare($sql);
            $stmt->execute([
                'entity_type' => $data['entity_type'],
                'entity_id' => $data['entity_id'],
                'from_status' => $data['from_status'],
                'to_status' => $data['to_status'],
                'reason' => $data['reason'] ?? null,
                'id' => $id,
                'tenant_id' => $tenantId
            ]);
            
            if ($stmt->rowCount() === 0) {
                throw new Exception("No records updated");
            }
            
            return ['status' => 'success'];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Delete status transition record
     */
    public static function delete(int $id): array {
        try {
            $tenantId = self::getTenantId();
            
            $sql = "DELETE FROM status_transitions 
                    WHERE id = :id AND tenant_id = :tenant_id";
            
            $stmt = self::getDb()->prepare($sql);
            $stmt->execute(['id' => $id, 'tenant_id' => $tenantId]);
            
            if ($stmt->rowCount() === 0) {
                throw new Exception("No records deleted");
            }
            
            return ['status' => 'success'];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Validate transition data
     */
    private static function validateTransitionData(array $data): void {
        $required = ['entity_type', 'entity_id', 'from_status', 'to_status'];
        
        foreach ($required as $field) {
            if (empty($data[$field])) {
                throw new InvalidArgumentException("Missing required field: $field");
            }
        }
        
        if (!is_numeric($data['entity_id'])) {
            throw new InvalidArgumentException("Entity ID must be numeric");
        }
    }

    /**
     * Get tenant ID from session
     */
    private static function getTenantId(): int {
        if (empty($_SESSION['tenant_id'])) {
            throw new RuntimeException("Tenant ID not found in session");
        }
        return (int)$_SESSION['tenant_id'];
    }

    /**
     * Get database connection
     */
    private static function getDb(): PDO {
        global $pdo;
        if (!$pdo instanceof PDO) {
            throw new RuntimeException("Database connection not available");
        }
        return $pdo;
    }

    /**
     * Log version control change
     */
    private static function logVersionControlChange(
        string $entityType,
        int $entityId,
        string $changeDescription,
        ?string $reason = null
    ): void {
        try {
            // Check if version control is enabled
            if (!self::isVersionControlEnabled()) {
                return;
            }

            // Get version control service
            $versionControl = self::getVersionControlService();
            
            // Create version control entry
            $versionControl->logChange(
                $entityType,
                $entityId,
                'status_change',
                $changeDescription,
                $reason
            );
        } catch (Exception $e) {
            Logger::error("Failed to log version control change: " . $e->getMessage());
        }
    }

    /**
     * Check if version control is enabled
     */
    private static function isVersionControlEnabled(): bool {
        try {
            return ConfigurationService::get('version_control.enabled', false);
        } catch (Exception $e) {
            Logger::error("Failed to check version control status: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get version control service
     */
    private static function getVersionControlService() {
        try {
            return DependencyContainer::getInstance()->resolve('version_control');
        } catch (Exception $e) {
            throw new RuntimeException("Version control service not available");
        }
    }
}