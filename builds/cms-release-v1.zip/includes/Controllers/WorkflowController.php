<?php
declare(strict_types=1);

namespace Includes\Controllers;

require_once __DIR__ . '/../Services/WorkflowService.php';

use Includes\Services\WorkflowService;

class WorkflowController
{
    private WorkflowService $workflowService;

    public function __construct()
    {
        $this->workflowService = new WorkflowService();
    }

    /**
     * Handle workflow transition request
     * @param string $instanceId Workflow instance ID
     * @param string $transitionName Transition to execute
     * @param array $context Additional context data
     * @return array Response with status and details
     */
    public function handleTransition(string $instanceId, string $transitionName, array $context = []): array
    {
        try {
            return $this->workflowService->handleTransitionRequest($instanceId, $transitionName, $context);
        } catch (\RuntimeException $e) {
            return [
                'status' => 'error',
                'code' => $e->getCode(),
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Get workflow status
     * @param string $instanceId Workflow instance ID
     * @return array Response with current status
     */
    public function getStatus(string $instanceId): array
    {
        try {
            return $this->workflowService->handleStatusRequest($instanceId);
        } catch (\RuntimeException $e) {
            return [
                'status' => 'error',
                'code' => $e->getCode(),
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Cancel a workflow
     * @param string $instanceId Workflow instance ID
     * @return array Response with cancellation status
     */
    public function cancel(string $instanceId): array
    {
        try {
            return $this->workflowService->cancelWorkflow($instanceId);
        } catch (\RuntimeException $e) {
            return [
                'status' => 'error',
                'code' => $e->getCode(),
                'message' => $e->getMessage()
            ];
        }
    }
}