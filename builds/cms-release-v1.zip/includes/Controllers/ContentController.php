<?php
declare(strict_types=1);

class ContentController {
    /**
     * Display content by slug
     * @param string $slug Content slug
     * @return array Response with content data
     */
    public function show(string $slug): array {
        $content = (new ContentModel())->getBySlug($slug);
        
        if (!$content) {
            return ['error' => 'Content not found', 'code' => 404];
        }

        if (!(new ContentModel())->isPublished($content['id'])) {
            return ['error' => 'Content not published', 'code' => 403];
        }

        return [
            'content' => $content,
            'template' => $content['template'] ?? 'default'
        ];
    }
    /**
     * Update content by ID
     * @param int $id Content ID
     * @param array $data Update data
     * @return array Response
     */
    public function update(int $id, array $data): array {
        // 1. Validate input
        if (empty($data)) {
            return ['error' => 'No data provided'];
        }

        // 2. Verify content exists
        $content = $this->getContentById($id);
        if (!$content) {
            return ['error' => 'Content not found'];
        }

        // 3. Create version before update
        $versionId = $this->createContentVersion($id, $content);

        // 4. Apply updates
        try {
            $this->updateContent($id, $data);
            return [
                'success' => true,
                'id' => $id,
                'version_id' => $versionId
            ];
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }

    private function getContentById(int $id): ?array {
        // TODO: Implement database lookup
        return null;
    }

    private function updateContent(int $id, array $data): bool {
        // TODO: Implement database update
        return false;
    }

    private function createContentVersion(int $contentId, array $contentData): int {
        // TODO: Implement version creation
        return 1;
    }
}