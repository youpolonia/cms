<?php
namespace Controllers;

class CommunicationsController {
    public function index() {
        require_once __DIR__ . '/../views/communications/index.php';
    }
}