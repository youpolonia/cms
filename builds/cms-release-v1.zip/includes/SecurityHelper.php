<?php
// Security Helper v1.0
// Provides centralized security checks for API endpoints

class SecurityHelper {
    public static function checkRole($requiredRole) {
        $userRole = $_SESSION['user_role'] ?? 'guest';
        if ($userRole !== $requiredRole) {
            throw new Exception("Unauthorized: Requires $requiredRole role");
        }
    }

    public static function validateContentOwnership($tenantId, $contentId) {
        if (!DBSupport::contentBelongsToTenant($tenantId, $contentId)) {
            throw new Exception("Invalid content reference for tenant");
        }
    }

    public static function validateVersionOwnership($tenantId, $versionId) {
        if (!DBSupport::versionBelongsToTenant($tenantId, $versionId)) {
            throw new Exception("Invalid version reference for tenant");
        }
    }

    public static function validateTenantBoundary($tenantId, $targetTenants) {
        foreach ($targetTenants as $target) {
            if (!DBSupport::isAllowedTenantPair($tenantId, $target)) {
                throw new Exception("Invalid cross-tenant operation");
            }
        }
    }
}