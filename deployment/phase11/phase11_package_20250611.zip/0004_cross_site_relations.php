<?php
/**
 * Cross Site Relations Migration
 * 
 * This migration creates tables for managing relationships between sites and content sharing permissions.
 * It establishes the foundation for multi-site functionality in the CMS.
 * 
 * @version 1.0.0
 * @since 2025-05-30
 */

declare(strict_types=1);

class Migration_0004_CrossSiteRelations {
    
    /**
     * Execute the migration
     * 
     * Creates tables for site relationships and content sharing permissions
     * 
     * @param PDO $pdo Database connection
     * @return array Result status and message
     */
    public static function migrate(PDO $pdo): array {
        try {
            // Start transaction for atomic operation
            $pdo->beginTransaction();
            
            // Create site_relations table
            $pdo->exec("CREATE TABLE site_relations (
                id SERIAL PRIMARY KEY,
                parent_site_id INTEGER NOT NULL,
                child_site_id INTEGER NOT NULL,
                relation_type VARCHAR(50) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_parent_site FOREIGN KEY (parent_site_id) REFERENCES sites(id),
                CONSTRAINT fk_child_site FOREIGN KEY (child_site_id) REFERENCES sites(id),
                CONSTRAINT unique_site_relation UNIQUE (parent_site_id, child_site_id)
            )");
            
            // Create site_content_sharing table
            $pdo->exec("CREATE TABLE site_content_sharing (
                id SERIAL PRIMARY KEY,
                source_site_id INTEGER NOT NULL,
                target_site_id INTEGER NOT NULL,
                content_type VARCHAR(50) NOT NULL,
                permission_level VARCHAR(50) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_source_site FOREIGN KEY (source_site_id) REFERENCES sites(id),
                CONSTRAINT fk_target_site FOREIGN KEY (target_site_id) REFERENCES sites(id),
                CONSTRAINT unique_content_sharing UNIQUE (source_site_id, target_site_id, content_type)
            )");
            
            // Create indexes for performance optimization
            $pdo->exec("CREATE INDEX idx_site_relations_parent ON site_relations(parent_site_id)");
            $pdo->exec("CREATE INDEX idx_site_relations_child ON site_relations(child_site_id)");
            $pdo->exec("CREATE INDEX idx_content_sharing_source ON site_content_sharing(source_site_id)");
            $pdo->exec("CREATE INDEX idx_content_sharing_target ON site_content_sharing(target_site_id)");
            
            // Commit transaction
            $pdo->commit();
            
            return [
                'status' => 'success',
                'message' => 'Cross-site relations migration completed successfully'
            ];
        } catch (PDOException $e) {
            // Rollback transaction on error
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            
            return [
                'status' => 'error',
                'message' => 'Migration failed: ' . $e->getMessage(),
                'error_code' => $e->getCode()
            ];
        }
    }
    
    /**
     * Rollback the migration
     * 
     * Drops the tables created by this migration in the correct order to respect foreign key constraints
     * 
     * @param PDO $pdo Database connection
     * @return array Result status and message
     */
    public static function rollback(PDO $pdo): array {
        try {
            // Start transaction for atomic operation
            $pdo->beginTransaction();
            
            // Drop tables in reverse order of creation to respect foreign key constraints
            $pdo->exec("DROP TABLE IF EXISTS site_content_sharing");
            $pdo->exec("DROP TABLE IF EXISTS site_relations");
            
            // Commit transaction
            $pdo->commit();
            
            return [
                'status' => 'success',
                'message' => 'Cross-site relations rollback completed successfully'
            ];
        } catch (PDOException $e) {
            // Rollback transaction on error
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            
            return [
                'status' => 'error',
                'message' => 'Rollback failed: ' . $e->getMessage(),
                'error_code' => $e->getCode()
            ];
        }
    }
    
    /**
     * Test the migration
     * 
     * Verifies that the tables and constraints were created correctly
     * 
     * @param PDO $pdo Database connection
     * @return array Test results with status and details
     */
    public static function test(PDO $pdo): array {
        try {
            // Check if tables exist
            $tables = [];
            
            $stmt = $pdo->query("SELECT to_regclass('public.site_relations')");
            if ($stmt->fetchColumn() !== null) {
                $tables[] = 'site_relations';
            }
            
            $stmt = $pdo->query("SELECT to_regclass('public.site_content_sharing')");
            if ($stmt->fetchColumn() !== null) {
                $tables[] = 'site_content_sharing';
            }
            
            // Check if indexes exist
            $indexes = [];
            
            $stmt = $pdo->query("SELECT indexname FROM pg_indexes WHERE tablename = 'site_relations' AND indexname = 'idx_site_relations_parent'");
            if ($stmt->fetchColumn() !== false) {
                $indexes[] = 'idx_site_relations_parent';
            }
            
            $stmt = $pdo->query("SELECT indexname FROM pg_indexes WHERE tablename = 'site_relations' AND indexname = 'idx_site_relations_child'");
            if ($stmt->fetchColumn() !== false) {
                $indexes[] = 'idx_site_relations_child';
            }
            
            $stmt = $pdo->query("SELECT indexname FROM pg_indexes WHERE tablename = 'site_content_sharing' AND indexname = 'idx_content_sharing_source'");
            if ($stmt->fetchColumn() !== false) {
                $indexes[] = 'idx_content_sharing_source';
            }
            
            $stmt = $pdo->query("SELECT indexname FROM pg_indexes WHERE tablename = 'site_content_sharing' AND indexname = 'idx_content_sharing_target'");
            if ($stmt->fetchColumn() !== false) {
                $indexes[] = 'idx_content_sharing_target';
            }
            
            // Determine test status
            $expectedTables = ['site_relations', 'site_content_sharing'];
            $expectedIndexes = [
                'idx_site_relations_parent', 
                'idx_site_relations_child', 
                'idx_content_sharing_source', 
                'idx_content_sharing_target'
            ];
            
            $tablesStatus = count(array_diff($expectedTables, $tables)) === 0;
            $indexesStatus = count(array_diff($expectedIndexes, $indexes)) === 0;
            
            if ($tablesStatus && $indexesStatus) {
                return [
                    'status' => 'success',
                    'tables' => $tables,
                    'indexes' => $indexes,
                    'message' => 'Cross-site relations migration test successful'
                ];
            } else {
                return [
                    'status' => 'error',
                    'tables' => $tables,
                    'indexes' => $indexes,
                    'missing_tables' => array_diff($expectedTables, $tables),
                    'missing_indexes' => array_diff($expectedIndexes, $indexes),
                    'message' => 'Cross-site relations migration test failed - missing tables or indexes'
                ];
            }
        } catch (PDOException $e) {
            return [
                'status' => 'error',
                'message' => 'Test failed: ' . $e->getMessage(),
                'error_code' => $e->getCode()
            ];
        }
    }
    
    /**
     * Clean up test data
     * 
     * Removes any test data inserted during testing
     * 
     * @param PDO $pdo Database connection
     * @return array Result status and message
     */
    public static function cleanupTest(PDO $pdo): array {
        try {
            // Start transaction for atomic operation
            $pdo->beginTransaction();
            
            // Delete test data if any was inserted during testing
            $pdo->exec("DELETE FROM site_content_sharing WHERE content_type = 'test'");
            $pdo->exec("DELETE FROM site_relations WHERE relation_type = 'test'");
            
            // Commit transaction
            $pdo->commit();
            
            return [
                'status' => 'success',
                'message' => 'Test cleanup completed successfully'
            ];
        } catch (PDOException $e) {
            // Rollback transaction on error
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            
            return [
                'status' => 'error',
                'message' => 'Test cleanup failed: ' . $e->getMessage(),
                'error_code' => $e->getCode()
            ];
        }
    }
}