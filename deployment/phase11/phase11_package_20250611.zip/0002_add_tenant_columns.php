<?php
/**
 * Migration to add tenant_id columns to auth_users and auth_roles tables
 * 
 * This migration adds tenant_id columns to auth_users and auth_roles tables
 * and creates foreign key constraints to the tenants table.
 * 
 * @version 1.0.0
 * @since 2025-05-30
 */
declare(strict_types=1);

class Migration_0002_AddTenantColumns {
    /**
     * Execute the migration
     * 
     * @param PDO $pdo Database connection
     * @return bool True on success, false on failure
     */
    public static function migrate(PDO $pdo): bool {
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        try {
            // Start transaction for atomic operation
            $pdo->beginTransaction();
            
            $sql = <<<'SQL'
                ALTER TABLE auth_users
                ADD COLUMN tenant_id INTEGER NOT NULL,
                ADD CONSTRAINT fk_auth_users_tenant
                FOREIGN KEY (tenant_id) REFERENCES tenants(id);
                
                ALTER TABLE auth_roles
                ADD COLUMN tenant_id INTEGER NOT NULL,
                ADD CONSTRAINT fk_auth_roles_tenant
                FOREIGN KEY (tenant_id) REFERENCES tenants(id);
            SQL;
            
            $pdo->exec($sql);
            $pdo->commit();
            
            error_log("[Migration_0002] Successfully added tenant_id columns to auth_users and auth_roles tables");
            return true;
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("[Migration_0002] Migration failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Rollback the migration
     * 
     * @param PDO $pdo Database connection
     * @return bool True on success, false on failure
     */
    public static function rollback(PDO $pdo): bool {
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        try {
            // Start transaction for atomic operation
            $pdo->beginTransaction();
            
            $sql = <<<'SQL'
                ALTER TABLE auth_users
                DROP CONSTRAINT IF EXISTS fk_auth_users_tenant,
                DROP COLUMN IF EXISTS tenant_id;
                
                ALTER TABLE auth_roles
                DROP CONSTRAINT IF EXISTS fk_auth_roles_tenant,
                DROP COLUMN IF EXISTS tenant_id;
            SQL;
            
            $pdo->exec($sql);
            $pdo->commit();
            
            error_log("[Migration_0002] Successfully rolled back tenant_id columns from auth_users and auth_roles tables");
            return true;
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("[Migration_0002] Rollback failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Test the migration
     * 
     * @param PDO $pdo Database connection
     * @return bool True if test passes, false otherwise
     */
    public static function test(PDO $pdo): bool {
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        try {
            // Verify tenant_id columns exist
            $stmt = $pdo->query("PRAGMA table_info(auth_users)");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN, 1);
            if (!in_array('tenant_id', $columns)) {
                throw new Exception('Missing tenant_id in auth_users');
            }
    
            $stmt = $pdo->query("PRAGMA table_info(auth_roles)");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN, 1);
            if (!in_array('tenant_id', $columns)) {
                throw new Exception('Missing tenant_id in auth_roles');
            }
    
            // Verify foreign key constraints
            $stmt = $pdo->query("PRAGMA foreign_key_list(auth_users)");
            $fks = $stmt->fetchAll();
            $valid = false;
            foreach ($fks as $fk) {
                if ($fk['from'] === 'tenant_id' && $fk['table'] === 'tenants') {
                    $valid = true;
                    break;
                }
            }
            if (!$valid) {
                throw new Exception('Invalid foreign key in auth_users');
            }
    
            $stmt = $pdo->query("PRAGMA foreign_key_list(auth_roles)");
            $fks = $stmt->fetchAll();
            $valid = false;
            foreach ($fks as $fk) {
                if ($fk['from'] === 'tenant_id' && $fk['table'] === 'tenants') {
                    $valid = true;
                    break;
                }
            }
            if (!$valid) {
                throw new Exception('Invalid foreign key in auth_roles');
            }
    
            error_log("[Migration_0002] Test passed successfully");
            return true;
        } catch (Exception $e) {
            error_log("[Migration_0002] Test failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Clean up after testing
     * 
     * @param PDO $pdo Database connection
     * @return bool True on success, false on failure
     */
    public static function cleanupTest(PDO $pdo): bool {
        // No specific cleanup needed for this migration
        // The rollback method can be used for cleanup if needed
        return true;
    }
}