<?php
/**
 * Tenant Isolation Migration
 * 
 * Purpose: Implement tenant isolation using tenant_id column pattern across all tenant-specific tables
 * 
 * Schema Changes:
 * - Add `tenant_id` VARCHAR(36) NOT NULL column to all tenant-specific tables
 * - Create indexes on `tenant_id` column for all tables
 * - Add foreign key constraints where appropriate
 * 
 * Rollback Procedure:
 * - Remove indexes on `tenant_id` column from all tables
 * - Drop `tenant_id` column from all tables
 * 
 * Testing Methodology:
 * - Apply migration
 * - Insert test data for multiple tenants
 * - Verify data is isolated by tenant_id
 * - Rollback migration
 * - Verify `tenant_id` column is dropped
 */

class Migration_0001_TenantIsolation {
    // Tables requiring tenant isolation
    const TABLES = [
        'users',
        'posts',
        'comments',
        'settings',
        'content_pages',
        'content_blocks',
        'audit_log'
    ];

    /**
     * Apply the migration
     * 
     * @param PDO $pdo Database connection
     * @return bool Success status
     */
    public static function migrate(PDO $pdo) {
        try {
            // Start transaction for atomic operations
            $pdo->beginTransaction();
            
            foreach (self::TABLES as $table) {
                // Add tenant_id column to each table using prepared statement
                $addColumnStmt = $pdo->prepare("
                    ALTER TABLE {$table}
                    ADD COLUMN tenant_id VARCHAR(36) NOT NULL AFTER id
                ");
                $addColumnStmt->execute();
                
                // Create index on tenant_id
                $createIndexStmt = $pdo->prepare("
                    CREATE INDEX idx_{$table}_tenant_id ON {$table} (tenant_id)
                ");
                $createIndexStmt->execute();
            }
            
            // Commit transaction
            $pdo->commit();
            
            return true;
        } catch (PDOException $e) {
            // Rollback transaction on error
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            
            // Log error
            error_log("Migration error: " . $e->getMessage());
            
            return false;
        }
    }
    
    /**
     * Rollback the migration
     * 
     * @param PDO $pdo Database connection
     * @return bool Success status
     */
    public static function rollback(PDO $pdo) {
        try {
            // Start transaction for atomic operations
            $pdo->beginTransaction();
            
            foreach (self::TABLES as $table) {
                // Drop index on tenant_id
                $dropIndexStmt = $pdo->prepare("
                    DROP INDEX IF EXISTS idx_{$table}_tenant_id ON {$table}
                ");
                $dropIndexStmt->execute();
                
                // Drop tenant_id column
                $dropColumnStmt = $pdo->prepare("
                    ALTER TABLE {$table}
                    DROP COLUMN IF EXISTS tenant_id
                ");
                $dropColumnStmt->execute();
            }
            
            // Commit transaction
            $pdo->commit();
            
            return true;
        } catch (PDOException $e) {
            // Rollback transaction on error
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            
            // Log error
            error_log("Rollback error: " . $e->getMessage());
            
            return false;
        }
    }
    
    /**
     * Test the migration
     * 
     * @param PDO $pdo Database connection
     * @return bool Test result
     */
    public static function test(PDO $pdo) {
        try {
            // Start transaction for test data
            $pdo->beginTransaction();
            
            // Clean up any existing test data
            $cleanupStmt = $pdo->prepare("
                DELETE FROM users 
                WHERE email LIKE 'test%@example.com'
            ");
            $cleanupStmt->execute();
            
            // Insert test data for tenant 1
            $insertTenant1Stmt = $pdo->prepare("
                INSERT INTO users (id, tenant_id, name, email) 
                VALUES (1001, 'tenant1', 'Tenant 1 User', 'test1@example.com')
            ");
            $insertTenant1Stmt->execute();
            
            // Insert test data for tenant 2
            $insertTenant2Stmt = $pdo->prepare("
                INSERT INTO users (id, tenant_id, name, email) 
                VALUES (1002, 'tenant2', 'Tenant 2 User', 'test2@example.com')
            ");
            $insertTenant2Stmt->execute();
            
            // Query data for tenant 1 only
            $queryTenant1Stmt = $pdo->prepare("
                SELECT * FROM users 
                WHERE tenant_id = 'tenant1' AND id >= 1000
            ");
            $queryTenant1Stmt->execute();
            $tenant1Users = $queryTenant1Stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Query data for tenant 2 only
            $queryTenant2Stmt = $pdo->prepare("
                SELECT * FROM users 
                WHERE tenant_id = 'tenant2' AND id >= 1000
            ");
            $queryTenant2Stmt->execute();
            $tenant2Users = $queryTenant2Stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Verify isolation
            $isolationVerified = (
                count($tenant1Users) === 1 && 
                count($tenant2Users) === 1 && 
                $tenant1Users[0]['email'] === 'test1@example.com' && 
                $tenant2Users[0]['email'] === 'test2@example.com'
            );
            
            // Clean up test data
            $cleanupStmt->execute();
            
            // Commit transaction
            $pdo->commit();
            
            return $isolationVerified;
        } catch (PDOException $e) {
            // Rollback transaction on error
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            
            // Log error
            error_log("Test error: " . $e->getMessage());
            
            return false;
        }
    }
}