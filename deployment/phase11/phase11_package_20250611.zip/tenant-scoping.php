<?php
require_once __DIR__.'/../../../database/connection.php';
require_once __DIR__.'/../../../api/includes/tenant_identification.php';
require_once __DIR__.'/../../../database/migrations/Migration_0003_CompleteTenantScope.php';

header('Content-Type: application/json');

try {
    $pdo = getDatabaseConnection();
    
    // Create a simple test implementation since getMigration() doesn't exist
    $migration = [
        'test' => function($pdo) {
            return Migration_0003_CompleteTenantScope::test($pdo);
        }
    ];
    
    // Basic tenant scoping validation
    $basicTests = $migration['test']($pdo);
    
    // Edge case tests
    $edgeCases = [
        'invalid_tenant_id' => testInvalidTenantId($pdo),
        'empty_tenant_id' => testEmptyTenantId($pdo),
        'cross_tenant_access' => testCrossTenantAccess($pdo),
        'tenant_id_format_variations' => testTenantIdFormats($pdo)
    ];
    
    if ($basicTests && !in_array(false, $edgeCases, true)) {
        echo json_encode([
            'status' => 'success',
            'message' => 'Tenant scoping tests passed',
            'data' => [
                'tables_tested' => ['content_pages', 'content_blocks', 'audit_log'],
                'basic_tests' => [
                    'tenant_id_column_exists',
                    'foreign_key_constraint_valid'
                ],
                'edge_cases_tested' => array_keys($edgeCases)
            ]
        ]);
    } else {
        throw new Exception('Tenant scoping tests failed');
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage(),
        'error_details' => error_get_last(),
        'failed_tests' => $edgeCases ?? []
    ]);
}

function validateTenantId($tenantId) {
    // Simple validation function
    if (empty($tenantId)) return false;
    if (strlen($tenantId) > 50) return false;
    if (preg_match('/[^a-zA-Z0-9_-]/', $tenantId)) return false;
    return true;
}

function testInvalidTenantId(PDO $pdo): bool {
    // Test with malformed tenant IDs
    $invalidIds = ['', 'invalid!', 'tenant_123@', '123!@#'];
    foreach ($invalidIds as $id) {
        if (validateTenantId($id)) return false;
    }
    return true;
}

function testEmptyTenantId(PDO $pdo): bool {
    // Test empty tenant ID handling
    try {
        $stmt = $pdo->prepare("SELECT * FROM content_pages WHERE tenant_id = ?");
        $stmt->execute(['']);
        return $stmt->rowCount() === 0;
    } catch (PDOException $e) {
        return false;
    }
}

function testCrossTenantAccess(PDO $pdo): bool {
    // Verify data from one tenant cannot be accessed by another
    $tenant1 = 'tenant_' . bin2hex(random_bytes(4));
    $tenant2 = 'tenant_' . bin2hex(random_bytes(4));
    
    // Insert test data
    $pdo->exec("INSERT INTO content_pages (tenant_id, title) VALUES ('$tenant1', 'Test1')");
    $pdo->exec("INSERT INTO content_pages (tenant_id, title) VALUES ('$tenant2', 'Test2')");
    
    // Attempt cross-tenant access
    $stmt = $pdo->prepare("SELECT * FROM content_pages WHERE tenant_id = ?");
    $stmt->execute([$tenant1]);
    $results = $stmt->fetchAll();
    
    return count($results) === 1 && $results[0]['title'] === 'Test1';
}

function testTenantIdFormats(PDO $pdo): bool {
    // Test various valid tenant ID formats
    $formats = [
        'tenant_123',
        'tenant-123',
        '123',
        't123',
        'tenant123'
    ];
    
    foreach ($formats as $format) {
        if (!validateTenantId($format)) return false;
    }
    return true;
}