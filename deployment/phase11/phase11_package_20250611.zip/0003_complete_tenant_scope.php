<?php
/**
 * Migration to complete tenant scope by adding tenant_id columns to content tables
 * 
 * This migration adds tenant_id columns and foreign key constraints to:
 * - content_pages
 * - content_blocks
 * - audit_log
 */
class Migration_0003_CompleteTenantScope {
    
    /**
     * Execute the migration
     * 
     * @param PDO $pdo Database connection
     * @return bool Success status
     */
    public static function migrate(PDO $pdo): bool {
        try {
            $pdo->beginTransaction();
            
            $sql = <<<'SQL'
                ALTER TABLE content_pages
                ADD COLUMN tenant_id INTEGER NOT NULL,
                ADD CONSTRAINT fk_content_pages_tenant
                FOREIGN KEY (tenant_id) REFERENCES tenants(id);
                
                ALTER TABLE content_blocks
                ADD COLUMN tenant_id INTEGER NOT NULL,
                ADD CONSTRAINT fk_content_blocks_tenant
                FOREIGN KEY (tenant_id) REFERENCES tenants(id);
                
                ALTER TABLE audit_log
                ADD COLUMN tenant_id INTEGER NOT NULL,
                ADD CONSTRAINT fk_audit_log_tenant
                FOREIGN KEY (tenant_id) REFERENCES tenants(id);
            SQL;
            
            $pdo->exec($sql);
            $pdo->commit();
            
            return true;
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            self::logError("Migration failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Rollback the migration
     * 
     * @param PDO $pdo Database connection
     * @return bool Success status
     */
    public static function rollback(PDO $pdo): bool {
        try {
            $pdo->beginTransaction();
            
            $sql = <<<'SQL'
                ALTER TABLE content_pages
                DROP CONSTRAINT IF EXISTS fk_content_pages_tenant,
                DROP COLUMN IF EXISTS tenant_id;
                
                ALTER TABLE content_blocks
                DROP CONSTRAINT IF EXISTS fk_content_blocks_tenant,
                DROP COLUMN IF EXISTS tenant_id;
                
                ALTER TABLE audit_log
                DROP CONSTRAINT IF EXISTS fk_audit_log_tenant,
                DROP COLUMN IF EXISTS tenant_id;
            SQL;
            
            $pdo->exec($sql);
            $pdo->commit();
            
            return true;
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            self::logError("Rollback failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Test the migration
     * 
     * @param PDO $pdo Database connection
     * @return bool Success status
     */
    public static function test(PDO $pdo): bool {
        try {
            $tables = ['content_pages', 'content_blocks', 'audit_log'];
            foreach ($tables as $table) {
                // Check if tenant_id column exists (MySQL version)
                $stmt = $pdo->query("SHOW COLUMNS FROM $table LIKE 'tenant_id'");
                if (!$stmt || $stmt->rowCount() === 0) {
                    throw new Exception("Missing tenant_id in $table");
                }
                
                // Check if foreign key exists (MySQL version)
                $stmt = $pdo->query("
                    SELECT * FROM information_schema.KEY_COLUMN_USAGE
                    WHERE TABLE_NAME = '$table'
                    AND COLUMN_NAME = 'tenant_id'
                    AND REFERENCED_TABLE_NAME = 'tenants'
                ");
                
                if (!$stmt || $stmt->rowCount() === 0) {
                    throw new Exception("Invalid foreign key in $table");
                }
            }
            return true;
        } catch (Exception $e) {
            self::logError("Test failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Clean up test data
     * 
     * @param PDO $pdo Database connection
     * @return bool Success status
     */
    public static function cleanupTest(PDO $pdo): bool {
        try {
            // No test data to clean up for this migration
            return true;
        } catch (Exception $e) {
            self::logError("Cleanup failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Web endpoint for migration execution
     * 
     * @param PDO $pdo Database connection
     * @return array Result with status and message
     */
    public static function webMigrate(PDO $pdo): array {
        try {
            $result = self::migrate($pdo);
            if ($result) {
                return [
                    'status' => 'success',
                    'message' => 'Migration 0003_CompleteTenantScope executed successfully'
                ];
            } else {
                return [
                    'status' => 'error',
                    'message' => 'Migration failed'
                ];
            }
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Migration error: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Web endpoint for rollback execution
     * 
     * @param PDO $pdo Database connection
     * @return array Result with status and message
     */
    public static function webRollback(PDO $pdo): array {
        try {
            $result = self::rollback($pdo);
            if ($result) {
                return [
                    'status' => 'success',
                    'message' => 'Rollback of 0003_CompleteTenantScope executed successfully'
                ];
            } else {
                return [
                    'status' => 'error',
                    'message' => 'Rollback failed'
                ];
            }
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => 'Rollback error: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Log error message
     * 
     * @param string $message Error message
     * @return void
     */
    private static function logError(string $message): void {
        error_log($message);
        
        // Also log to a migration-specific log file if needed
        $logDir = dirname(__DIR__) . '/logs';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $logFile = $logDir . '/migration_errors.log';
        file_put_contents(
            $logFile,
            date('[Y-m-d H:i:s]') . ' ' . $message . PHP_EOL,
            FILE_APPEND
        );
    }
}