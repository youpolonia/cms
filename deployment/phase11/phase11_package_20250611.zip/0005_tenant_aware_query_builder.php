<?php
/**
 * Migration 0005: Tenant-Aware Query Builder
 *
 * Creates PostgreSQL functions for tenant-aware query building to ensure
 * proper tenant data isolation in multi-tenant environments.
 *
 * @package CMS
 * @subpackage Database\Migrations
 * @version 1.0
 */

declare(strict_types=1);

class Migration_0005_TenantAwareQueryBuilder {
    /**
     * Executes the migration to create tenant-aware query builder functions
     *
     * @param PDO $pdo Database connection
     * @return array Status information about the migration
     */
    public static function migrate(PDO $pdo): array {
        try {
            // Start transaction for atomic operation
            $pdo->beginTransaction();
            
            $sql = <<<'SQL'
-- Creates tenant-aware query builder functions
CREATE OR REPLACE FUNCTION tenant_where(tenant_id BIGINT, base_query TEXT, params JSONB)
RETURNS TEXT AS $$
DECLARE
    where_clause TEXT;
    param_value TEXT;
    param_key TEXT;
BEGIN
    -- Start with tenant_id filter
    where_clause := format(' WHERE tenant_id = %L', tenant_id);
    
    -- Add additional conditions if provided
    IF base_query IS NOT NULL AND base_query != '' THEN
        where_clause := where_clause || ' AND ' || base_query;
    END IF;
    
    RETURN where_clause;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION tenant_query(tenant_id BIGINT, base_query TEXT, params JSONB)
RETURNS SETOF RECORD AS $$
DECLARE
    full_query TEXT;
BEGIN
    full_query := base_query || tenant_where(tenant_id,
        CASE WHEN params->>'where' IS NULL THEN '' ELSE params->>'where' END,
        params);
    
    RETURN QUERY EXECUTE full_query
    USING (SELECT jsonb_array_elements_text(params->'values'));
END;
$$ LANGUAGE plpgsql;
SQL;

            // Execute the SQL
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            
            // Commit the transaction
            $pdo->commit();
            
            return [
                'status' => 'success',
                'message' => 'Tenant-aware query builder functions created successfully'
            ];
        } catch (PDOException $e) {
            // Rollback on error
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            
            return [
                'status' => 'error',
                'message' => 'Migration failed: ' . $e->getMessage(),
                'error_code' => $e->getCode()
            ];
        }
    }
    
    /**
     * Rolls back the migration by dropping the tenant-aware query builder functions
     *
     * @param PDO $pdo Database connection
     * @return array Status information about the rollback
     */
    public static function rollback(PDO $pdo): array {
        try {
            // Start transaction for atomic operation
            $pdo->beginTransaction();
            
            $sql = <<<'SQL'
DROP FUNCTION IF EXISTS tenant_where(BIGINT, TEXT, JSONB);
DROP FUNCTION IF EXISTS tenant_query(BIGINT, TEXT, JSONB);
SQL;

            // Execute the SQL
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            
            // Commit the transaction
            $pdo->commit();
            
            return [
                'status' => 'success',
                'message' => 'Tenant-aware query builder functions dropped successfully'
            ];
        } catch (PDOException $e) {
            // Rollback on error
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            
            return [
                'status' => 'error',
                'message' => 'Rollback failed: ' . $e->getMessage(),
                'error_code' => $e->getCode()
            ];
        }
    }
    
    /**
     * Tests if the tenant-aware query builder functions exist and work correctly
     *
     * @param PDO $pdo Database connection
     * @return array Test results
     */
    public static function test(PDO $pdo): array {
        try {
            // Check if functions exist
            $sql = "SELECT routine_name FROM information_schema.routines
                    WHERE routine_type = 'FUNCTION'
                    AND routine_schema = 'public'
                    AND routine_name IN ('tenant_where', 'tenant_query')";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $functions = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            if (count($functions) !== 2) {
                return [
                    'status' => 'error',
                    'message' => 'Not all tenant-aware query builder functions were created',
                    'found_functions' => $functions
                ];
            }
            
            // Test tenant_where function with a simple query
            $testSql = "SELECT tenant_where(:tenant_id, :base_query, :params::jsonb)";
            $stmt = $pdo->prepare($testSql);
            $stmt->execute([
                ':tenant_id' => 1,
                ':base_query' => 'status = true',
                ':params' => json_encode(['values' => [true]])
            ]);
            
            $result = $stmt->fetchColumn();
            $expected = " WHERE tenant_id = '1' AND status = true";
            
            if ($result !== $expected) {
                return [
                    'status' => 'error',
                    'message' => 'tenant_where function returned unexpected result',
                    'expected' => $expected,
                    'actual' => $result
                ];
            }
            
            return [
                'status' => 'success',
                'functions' => [
                    'tenant_where',
                    'tenant_query'
                ],
                'message' => 'Tenant-aware query builder functions created and tested successfully'
            ];
        } catch (PDOException $e) {
            return [
                'status' => 'error',
                'message' => 'Test failed: ' . $e->getMessage(),
                'error_code' => $e->getCode()
            ];
        }
    }
    
    /**
     * Cleans up any test data created during testing
     *
     * For this migration, no cleanup is needed as we're only creating functions
     *
     * @param PDO $pdo Database connection
     * @return array Status information about the cleanup
     */
    public static function cleanupTest(PDO $pdo): array {
        // No test data to clean up for this migration
        return [
            'status' => 'success',
            'message' => 'No test data cleanup needed for this migration'
        ];
    }
}