<?php
require_once __DIR__.'/../../../api/includes/api_error_handler.php';
require_once __DIR__.'/../../../database/connection.php';

header('Content-Type: application/json');

try {
    $pdo = getDatabaseConnection();
    
    // Create tables if they don't exist
    createTablesIfNotExist($pdo);
    
    // Extended relationship tests
    $relationshipTests = [
        'valid_relationships' => testValidRelationships($pdo),
        'invalid_relationships' => testInvalidRelationships($pdo),
        'circular_references' => testCircularReferences($pdo),
        'orphaned_relationships' => testOrphanedRelationships($pdo)
    ];
    
    if (!in_array(false, $relationshipTests, true)) {
        echo json_encode([
            'status' => 'success',
            'message' => 'Cross-site relationship tests passed',
            'data' => [
                'relationship_tests' => array_keys(array_filter($relationshipTests))
            ]
        ], JSON_PRETTY_PRINT);
    } else {
        throw new Exception('Cross-site relationship tests failed');
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage(),
        'failed_tests' => $relationshipTests ?? []
    ], JSON_PRETTY_PRINT);
}

function testValidRelationships(PDO $pdo): bool {
    // Test valid relationship creation and retrieval
    $pdo->exec("INSERT INTO test_sites (id, name) VALUES (1, 'Site A'), (2, 'Site B')");
    $pdo->exec("INSERT INTO test_site_relationships (source_site_id, target_site_id, relation_type)
                VALUES (1, 2, 'mirror'), (2, 1, 'backlink')");
                
    $stmt = $pdo->query("SELECT * FROM test_site_relationships");
    $results = $stmt->fetchAll();
    
    return count($results) === 2 &&
           $results[0]['relation_type'] === 'mirror' &&
           $results[1]['relation_type'] === 'backlink';
}

function testInvalidRelationships(PDO $pdo): bool {
    // Test invalid relationship prevention
    try {
        $pdo->exec("INSERT INTO test_site_relationships (source_site_id, target_site_id, relation_type)
                    VALUES (999, 999, 'invalid')");
        return false;
    } catch (PDOException $e) {
        return str_contains($e->getMessage(), 'constraint');
    }
}

function testCircularReferences(PDO $pdo): bool {
    // Test circular reference prevention
    try {
        $pdo->exec("INSERT INTO test_site_relationships (source_site_id, target_site_id, relation_type)
                    VALUES (1, 1, 'self')");
        return false;
    } catch (PDOException $e) {
        return str_contains($e->getMessage(), 'circular');
    }
}

function testOrphanedRelationships(PDO $pdo): bool {
    // Test orphaned relationship cleanup
    $pdo->exec("DELETE FROM test_sites WHERE id IN (1, 2)");
    $stmt = $pdo->query("SELECT COUNT(*) FROM test_site_relationships");
    return $stmt->fetchColumn() === 0;
}

function createTablesIfNotExist(PDO $pdo): void {
    try {
        // Drop tables if they exist to ensure clean state
        $pdo->exec("DROP TABLE IF EXISTS test_site_relationships");
        $pdo->exec("DROP TABLE IF EXISTS test_sites");
        
        // Create test_sites table
        $pdo->exec("CREATE TABLE test_sites (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            tenant_id INT NOT NULL DEFAULT 1
        )");
        
        // Create test_site_relationships table
        $pdo->exec("CREATE TABLE test_site_relationships (
            id INT AUTO_INCREMENT PRIMARY KEY,
            source_site_id INT NOT NULL,
            target_site_id INT NOT NULL,
            relation_type VARCHAR(50) NOT NULL,
            FOREIGN KEY (source_site_id) REFERENCES test_sites(id) ON DELETE CASCADE,
            FOREIGN KEY (target_site_id) REFERENCES test_sites(id) ON DELETE CASCADE,
            CONSTRAINT check_circular CHECK (source_site_id != target_site_id)
        )");
    } catch (PDOException $e) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Table creation failed: ' . $e->getMessage()
        ], JSON_PRETTY_PRINT);
        exit;
    }
    
    // Clean up any existing data
    $pdo->exec("DELETE FROM test_site_relationships");
    $pdo->exec("DELETE FROM test_sites");
}