<?php

class Migration_0006_AnalyticsTestEndpoints {
    public static function up($pdo) {
        try {
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS analytics_test_endpoints (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    endpoint VARCHAR(255) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ");

            // Register test endpoints
            $endpoints = [
                '/analytics/log-test-event',
                '/analytics/get-test-events'
            ];

            $stmt = $pdo->prepare("INSERT INTO analytics_test_endpoints (endpoint) VALUES (:endpoint)");
            foreach ($endpoints as $endpoint) {
                $stmt->execute([':endpoint' => $endpoint]);
            }

            return true;
        } catch (PDOException $e) {
            error_log("Migration_2025_phase11_analytics_test_endpoints error: " . $e->getMessage());
            return false;
        }
    }

    public static function down($pdo) {
        try {
            $pdo->exec("DROP TABLE IF EXISTS analytics_test_endpoints");
            return true;
        } catch (PDOException $e) {
            error_log("Migration_2025_phase11_analytics_test_endpoints error: " . $e->getMessage());
            return false;
        }
    }

    public static function test($pdo) {
        try {
            // Test logging an event
            $collector = AnalyticsCollector::getInstance();
            $logResult = $collector->logEvent('test-tenant', 'test_event', ['test' => 'data'], 'test-user');
            
            // Test retrieving events
            $events = $collector->getEvents('test-tenant');
            
            return [
                'status' => 'success',
                'log_result' => $logResult,
                'events_count' => count($events),
                'first_event' => $events[0] ?? null
            ];
        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }
}